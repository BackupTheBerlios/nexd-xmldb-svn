package org.sixdml.transform;
import org.sixdml.dbmanagement.SixdmlResource;
import org.xmldb.api.base.Collection;
import org.xmldb.api.base.Service;
import org.xmldb.api.base.XMLDBException;
import java.net.URL;
import org.w3c.dom.Node;
import java.io.InputStream;
import java.io.IOException;
import org.sixdml.exceptions.InvalidTransformException;
import org.sixdml.exceptions.NonWellFormedXMLException;

/**
 * <PRE>
 * SixdmlTransformService.java
 * 
 * This is a Service that enables the execution of transformations within the context of a 
 * Collection, against the documents stored in the Collection or XML nodes.
 *
 * Created: Fri Jan 11 11:55:20 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 */


public interface SixdmlTransformService extends Service {
  
    
    /**
     * Gets the types of transforms that are supported by the this database. 
     * @return an array of SixdmlTransformTypes which the database supports.
     * @exception XMLDBException if an error occurs. 
     */
    SixdmlTransformType[] getSupportedTransformTypes() throws XMLDBException; 

    /**
     * Get the type of this object as a SixdmlTransformType.
     * @return the type of this object. 
     */
    SixdmlTransformType getType(); 

    /**
     * Transforms a SixdmlResource from one XML document to another and returns the 
     * results in a string. 
     * @param source the URL to the location of the file containing the transform. 
     * @param resource the resource to transform
     * @return the results of the transform in a string. 
     * @exception IOException if an error occurs while trying to retrieve the file.
     * @exception InvalidTransformException if the transform specified is an invalid or non-well formed
     * query or document. 
     */
    String transformAndReturnString(URL source, SixdmlResource resource)
	throws IOException, InvalidTransformException;  

    /**
     * Transforms a SixdmlResource from one XML document to another and returns the 
     * results in a string.
     * @param transformCode the actual code for the stylesheet or query.
     * @param resource the resource to transform
     * @return the results of the transform in a string. 
     * @exception InvalidTransformException if the transform specified is an invalid or non-well formed
     * query or document. 
     */
    String transformAndReturnString(String transformCode, SixdmlResource resource)
	throws InvalidTransformException;
	

    /**
     * Transforms a string representation of a wellformed XML document to another and returns the 
     * results in a string.
     * @param transformCode the actual code for the stylesheet or query.
     * @param sourceXML the XML to transform
     * @return the results of the transform in a string. 
     * @exception InvalidTransformException if the transform specified is an invalid or 
     * non-well formed query or document. 
     * @exception NonWellFormedXMLException if the data to transform is not a wellformed 
     * XML document. 
     */
    String transformAndReturnString(String transformCode, String sourceXML)
	throws InvalidTransformException, NonWellFormedXMLException;

     /**
     * Transforms a SixdmlResource from one XML document to another and returns the 
     * results in a string. 
     * @param source the URL to the location of the file containing the transform. 
     * @param sourceXML the XML to transform
     * @return the results of the transform in a string. 
     * @exception IOException if an error occurs while trying to retrieve the file.
     * @exception InvalidTransformException if the transform specified is an invalid or non-well formed
     * query or document. 
     * @exception NonWellFormedXMLException if the data to transform is not a wellformed 
     * XML document. 
     */
    String transformAndReturnString(URL source, String sourceXML)
	throws IOException, InvalidTransformException, NonWellFormedXMLException;

 
   

} // SixdmlTransformService

