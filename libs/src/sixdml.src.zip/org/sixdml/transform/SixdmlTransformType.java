package org.sixdml.transform;


/**
 * <PRE>
 * SixdmlTransformService.java
 * 
 * Class is used by SixdmlTransformService to represent different types of transforms. 
 *
 * Created: Fri Jan 11 11:55:20 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 * 
 */

public final class SixdmlTransformType{

     /*=================================================================*/
    /*                             C O N S T A N T S                   */
    /*=================================================================*/
     
    /**
     * Represents a service that uses XSLT to perform transforms. 
     */
    public static SixdmlTransformType XSLT = new SixdmlTransformType("XSLT"); 

      
    /**
     * Represents a service that uses XPath 2.0 to perform transforms. 
     */
    public static SixdmlTransformType XPATH2 = new SixdmlTransformType("XPath 2.0"); 

      
    /**
     * Represents  a service that uses XQuery to perform transforms.
     */
    public static SixdmlTransformType XQUERY = new SixdmlTransformType("XQUERY"); 

      
    /*=================================================================*/
    /*                I N S T A N C E    V A R I A B L E S             */
    /*=================================================================*/
    
    /**
     * This is the collection that holds the Resources.
     */
    private String type;
    
    
    /*=================================================================*/
    /*                        C O N S T U C T O R S                    */
    /*=================================================================*/


    /**
     * Constructor at package scope so cannot be instantiated by objects outside 
     * the package. 
     * @param type the type of index. 
     */
    SixdmlTransformType(String type){this.type = type;} 

    
    /*=================================================================*/
    /*                I N S T A N C E       M E T H O D S              */
    /*=================================================================*/

    /**
     * Returns the type of the index as a string.
     * @return the type of the index as a string.
     */
    public String toString(){ return type;}
 

}
