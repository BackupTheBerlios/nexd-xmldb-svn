package org.sixdml.exceptions;
import  org.sixdml.dbmanagement.SixdmlCollection;

/**
 * <PRE>
 * UnsupportedIndexTypeException.java
 * 
 * Thrown when an attempt is made to add an index to a collection in a database 
 * that does not support that type of index. 
 *
 * Created: Fri Jan 11 00:40:46 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 * 
 * @see SixdmlCollection#addIndex(SixdmlIndex) 
 */


public class UnsupportedIndexTypeException extends SixdmlException {
    
    
    /**
     * Constructs a UnsupportedIndexTypeException with no detail message.
     */
    public UnsupportedIndexTypeException() {
	
    }
    
    /**
     * Constructs a UnsupportedIndexTypeException with the specified detail message.
     */
    public UnsupportedIndexTypeException(String message) {
	super(message); 
    }
    
    /**
     * Constructs a UnsupportedIndexTypeException with the specified detail message and cause.
     */
    public UnsupportedIndexTypeException(String message, Throwable cause) {
	super(message, cause); 
    }
    
    /**
     * Constructs a UnsupportedIndexTypeException with the specified cause.
     */
    public UnsupportedIndexTypeException(Throwable cause) {
	super(cause); 
    }
    
    
} // UnsupportedIndexTypeException
