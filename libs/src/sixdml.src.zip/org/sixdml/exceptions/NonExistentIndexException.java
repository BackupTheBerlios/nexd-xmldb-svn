package org.sixdml.exceptions;
import org.sixdml.dbmanagement.SixdmlCollection;

/**
 * <PRE>
 * NonExistentIndexException.java
 *
 * Thrown when an attempt is made to delete an index that does not exist. 
 *
 * Created: Thu Jan 10 07:01:26 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0
 * 
 * @see SixdmlCollection#removeIndex(String)
 */


public class NonExistentIndexException extends SixdmlException {
    
    
    /**
     * Constructs a NonExistentIndexException with no detail message.
     */
    public NonExistentIndexException() {
	
    }
    
    /**
     * Constructs a NonExistentIndexException with the specified detail message.
     */
    public NonExistentIndexException(String message) {
	super(message); 
    }
    
         
    /**
     * Constructs a NonExistentIndexException with the specified detail message and cause.
     */
    public NonExistentIndexException(Throwable cause) {
	super(cause); 
    }
    
    /**
     * Constructs a NonExistentIndexException with the specified cause.
     */
    public NonExistentIndexException(String message, Throwable cause) {
	super(message, cause); 
    }

    
} // NonExistentIndexException
