package org.sixdml.exceptions;
import org.sixdml.transform.SixdmlTransformService; 
import java.net.URL; 

/**
 * <PRE>  
 * InvalidTransformException.java
 *
 * Thrown when an invalid transform document or query is used in a transformation attempt.
 * 
 * Created: Tue Jan 15 18:04:23 2002
 * 
 * </PRE>  
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 * 
 * @see SixdmlTransformService#transformAndReturnString(String, SixdmlResource) 
 * @see SixdmlTransformService#transformAndReturnString(String, String) 
 * @see SixdmlTransformService#transformAndReturnString(URL, SixdmlResource) 
 * @see SixdmlTransformService#transformAndReturnString(URL, String) 
 *
 */

public class InvalidTransformException extends SixdmlException {
    
    
    /**
     * Constructs a InvalidTransformException with no detail message.
     */
    public InvalidTransformException() {
	
    }
    
    /**
     * Constructs a InvalidTransformException with the specified detail message.
     */
    public InvalidTransformException(String message) {
	super(message); 
    }
    
    /**
     * Constructs a InvalidTransformException with the specified detail message and cause.
     */
    public InvalidTransformException(String message, Throwable cause) {
	super(message, cause); 
    }
    
    /**
     * Constructs a InvalidTransformException with the specified cause.
     */
    public InvalidTransformException(Throwable cause) {
	super(cause); 
    }    
    
} // InvalidTransformException
