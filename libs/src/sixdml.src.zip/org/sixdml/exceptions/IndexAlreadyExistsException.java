package org.sixdml.exceptions;
import org.sixdml.dbmanagement.SixdmlCollection;

/**
 * <PRE>
 * IndexAlreadyExistsException.java
 *
 * Thrown when an attempt is made to add an index to a collection when one with the 
 * same name already exists in that collection. 
 *
 * Created: Fri Jan 11 00:44:31 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 * 
 * @see SixdmlCollection#addIndex(SixdmlIndex)
 */


public class IndexAlreadyExistsException extends SixdmlException {
    
    
    /**
     * Constructs a IndexAlreadyExistsException with no detail message.
     */
    public IndexAlreadyExistsException() {
	
    }
    
    /**
     * Constructs a IndexAlreadyExistsException with the specified detail message.
     */
    public IndexAlreadyExistsException(String message) {
	super(message); 
    }
    
    /**
     * Constructs a IndexAlreadyExistsException with the specified detail message and cause.
     */
    public IndexAlreadyExistsException(String message, Throwable cause) {
	super(message, cause); 
    }
    
    /**
     * Constructs a IndexAlreadyExistsException with the specified cause.
     */
    public IndexAlreadyExistsException(Throwable cause) {
	super(cause); 
    }
    
    
} // IndexAlreadyExistsException
