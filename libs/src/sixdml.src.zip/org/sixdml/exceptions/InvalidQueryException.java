package org.sixdml.exceptions;
import org.sixdml.dbmanagement.SixdmlCollection;
import org.sixdml.dbmanagement.SixdmlResource;
import org.sixdml.query.SixdmlQueryService;

/**
 * <PRE>  
 * InvalidQueryException.java
 *
 * This is thrown when an attempt is made to query a collection or document with an invalid query. 
 *
 * Created: Fri Jan 11 17:57:33 2002
 *
 * </PRE>  
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 * 
 * @see SixdmlQueryService#executeQuery(String, SixdmlCollection)
 * @see SixdmlQueryService#executeQuery(String, SixdmlResource)
 */

public class InvalidQueryException extends SixdmlException {
    
   
    
    /**
     * Constructs a InvalidQueryException with the query and validation error
     * exception.
     * @param document the name of the document that failed to validate. 
     */
    public InvalidQueryException(String document, Throwable cause) {
	super(document, cause); 
    }
    
    /**
     * Constructs a InvalidQueryException with the specified cause and validation error
     * exception..
     */
    public InvalidQueryException(Throwable cause) {
	super(cause); 
    }
    
    
} // InvalidQueryException
