package org.sixdml.exceptions;

/**
 * <PRE>
 * SixdmlException.java
 *
 * Base class of all Exceptions in the org.sixdml hierarchy.
 *
 * Created: Thu Jan 10 07:02:40 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0
 */

public class SixdmlException  extends Exception{
    

   /**
    * The cause of this exception which is set via one 
    * of the constructors that accepts a Throwable. 
    */
    private Throwable sixmlExceptionCause; 
 
    
    /**
     * Constructs a SixdmlException with no detail message.
     */
    public SixdmlException() {
	
    }
    

    /**
     * Constructs a SixdmlException with the specified detail message.
     */
    public SixdmlException(String message) {
	super(message); 
    }
    
        
    /**
     * Constructs a SixdmlException with the specified detail message and cause.
     */
    public SixdmlException(Throwable cause) {
	this.sixmlExceptionCause = cause; 
    }
    
    /**
     * Constructs a SixdmlException with the specified cause.
     */
    public SixdmlException(String message, Throwable cause) {
	super(message); 
	this.sixmlExceptionCause = cause; 
    }

    /**
     * Returns the cause of this throwable or null if the cause is nonexistent or 
     * unknown. (The cause is the throwable that caused this throwable to get thrown.)
     * This implementation returns the cause that was supplied via one of the constructors 
     * requiring a Throwable, or that was set after creation with the initCause(Throwable) method. 
     * <br><br>
     * <b>NOTE</b>: Implemented to provide Java 1.4 functionality in 1.3 and lesser. 
     * @return the cause of this throwable or null if the cause is nonexistent or unknown.
     */
     public Throwable getCause(){ return this.sixmlExceptionCause; }


    
    
} // SixdmlException
