package org.sixdml.exceptions;
import org.sixdml.update.SixdmlUpdateService; 

/**
 * <PRE>  
 * UpdateTypeMismatchException.java
 *
 * Thrown when an update is done against a type that does not allow such updates. For example, trying
 * to insert a comment into an attribute node. 
 *
 * Created: Fri Jan 11 18:36:31 2002
 *
 * </PRE>  
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 * 
 * @see SixdmlUpdateService
 */

public class UpdateTypeMismatchException extends SixdmlException {
    
    
    /**
     * Constructs a UpdateTypeMismatchException with no detail message.
     */
    public UpdateTypeMismatchException() {
	
    }
    
    /**
     * Constructs a UpdateTypeMismatchException with the specified detail message.
     */
    public UpdateTypeMismatchException(String message) {
	super(message); 
    }
    
    /**
     * Constructs a UpdateTypeMismatchException with the specified detail message and cause.
     */
    public UpdateTypeMismatchException(String message, Throwable cause) {
	super(message, cause); 
    }
    
    /**
     * Constructs a UpdateTypeMismatchException with the specified cause.
     */
    public UpdateTypeMismatchException(Throwable cause) {
	super(cause); 
    }
    
    
} // UpdateTypeMismatchException
