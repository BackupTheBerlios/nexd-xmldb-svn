package org.sixdml.exceptions;
import org.sixdml.dbmanagement.SixdmlCollection;

/**
 * <PRE>  
 * NonWellFormedXMLException.java
 *
 * Thrown when an attempt is made to store a non-well formed XML fragment in the database. 
 * 
 * Created: Sun Jan 13 13:46:18 2002
 *
 * </PRE>  
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 * 
 * @see SixdmlCollection#insertDocument(String, String) 
 */

public class NonWellFormedXMLException extends SixdmlException {
    
   
    
    /**
     * Constructs a NonWellFormedXMLException with the specified detail message.
     */
    public NonWellFormedXMLException(String message) {
	super(message); 
    }
    
    /**
     * Constructs a NonWellFormedXMLException with the specified detail message and cause.
     */
    public NonWellFormedXMLException(String message, Throwable cause) {
	super(message, cause); 
    }
    
    /**
     * Constructs a NonWellFormedXMLException with the specified cause.
     */
    public NonWellFormedXMLException(Throwable cause) {
	super(cause); 
    }
    
    
} // NonWellFormedXMLException
