package org.sixdml.exceptions;
import org.sixdml.dbmanagement.SixdmlCollection;

/**
 * <PRE>
 * NonExistentDocumentException.java
 *
 * Thrown when an attempt is made to delete a document that does not exist. 
 *
 * Created: Thu Jan 10 07:01:26 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 * 
 * @see  SixdmlCollection#removeDocument(String) 
 */


public class NonExistentDocumentException extends SixdmlException {
    
    
    /**
     * Constructs a NonExistentDocumentException with no detail message.
     */
    public NonExistentDocumentException() {
	
    }
    
    /**
     * Constructs a NonExistentDocumentException with the specified detail message.
     */
    public NonExistentDocumentException(String message) {
	super(message); 
    }
    
         
    /**
     * Constructs a NonExistentDocumentException with the specified detail message and cause.
     */
    public NonExistentDocumentException(Throwable cause) {
	super(cause); 
    }
    
    /**
     * Constructs a NonExistentDocumentException with the specified cause.
     */
    public NonExistentDocumentException(String message, Throwable cause) {
	super(message, cause); 
    }

    
} // NonExistentDocumentException
