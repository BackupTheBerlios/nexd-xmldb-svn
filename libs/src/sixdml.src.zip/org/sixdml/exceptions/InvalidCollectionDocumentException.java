package org.sixdml.exceptions;
import org.sixdml.dbmanagement.SixdmlCollection; 

/**
 * <PRE>
 * InvalidCollectionDocumentException.java
 *
 * Thrown when an XML document in a SixdmlCollection fails to be validate against 
 * a given schema that is being applied to the collection. 
 *
 * Created: Thu Jan 10 05:01:41 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0
 * 
 * @see SixdmlCollection#setSchema(java.net.URL)
 */


public class InvalidCollectionDocumentException extends SixdmlException {
                 
    
    /*=================================================================*/
    /*                        C O N S T R U C T O R S                  */
    /*=================================================================*/
    
    /**
     * No instance of this class should be created without specifying the 
     * offending document and the error message. 
     */
    private InvalidCollectionDocumentException(){;}

    /**
     * Constructs a InvalidCollectionDocumentException with the specified detail message.
     * @param document the name of the document that failed to validate. 
     * @param cause the Exception that was thrown when validation failed. 
     */
    public InvalidCollectionDocumentException(String document, Exception cause) {
	super(document, cause); 
    }        
     


} // InvalidCollectionDocumentException






