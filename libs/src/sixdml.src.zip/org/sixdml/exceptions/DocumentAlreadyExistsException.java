package org.sixdml.exceptions;

import org.sixdml.dbmanagement.SixdmlCollection;

/**
 * <PRE>
 * DocumentAlreadyExistsException.java
 *
 * Thrown when an attempt is made to add a document to a collection that has the 
 * same name as one that already exists in the collection. 
 *
 * Created: Thu Jan 10 05:35:48 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0
 *
 * @see SixdmlCollection#insertDocument(String, String)
 * @see SixdmlCollection#insertDocument(String, java.net.URL)
 */


public class DocumentAlreadyExistsException extends SixdmlException {
    
    
    /**
     * Constructs a DocumentAlreadyExistsException with no detail message.
     */
    public DocumentAlreadyExistsException() {
	
    }
    
    /**
     * Constructs a DocumentAlreadyExistsException with the specified detail message.
     */
    public DocumentAlreadyExistsException(String message) {
	super(message); 
    }
    
         
    /**
     * Constructs a DocumentAlreadyExistsException with the specified detail message and cause.
     */
    public DocumentAlreadyExistsException(Throwable cause) {
	super(cause); 
    }
    
    /**
     * Constructs a DocumentAlreadyExistsException with the specified cause.
     */
    public DocumentAlreadyExistsException(String message, Throwable cause) {
	super(message, cause); 
    }


} // DocumentAlreadyExistsException
