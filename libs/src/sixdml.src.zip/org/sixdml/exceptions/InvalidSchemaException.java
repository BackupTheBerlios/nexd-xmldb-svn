package org.sixdml.exceptions;
import org.sixdml.dbmanagement.SixdmlCollection;

/**
 * <PRE>  
 * InvalidSchemaException.java
 *
 * This is thrown when an attempt is made to perform constrain a collection with an invalid schema. 
 * 
 * Created: Fri Jan 11 17:57:33 2002
 *
 * </PRE>  
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 * 
 * @see SixdmlCollection#setSchema(java.net.URL)
 */

public class InvalidSchemaException extends SixdmlException {
    
   
    
    /**
     * Constructs a InvalidSchemaException with the document name and validation error
     * exception.
     * @param document the name of the document that failed to validate. 
     */
    public InvalidSchemaException(String document, Throwable cause) {
	super(document, cause); 
    }
    
    /**
     * Constructs a InvalidSchemaException with the specified cause and validation error
     * exception..
     */
    public InvalidSchemaException(Throwable cause) {
	super(cause); 
    }
    
    
} // InvalidSchemaException
