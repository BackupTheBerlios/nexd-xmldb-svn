package org.sixdml.query;
import org.w3c.dom.NodeList;


/**
 * <PRE>
 * SixdmlXpathObject.java
 *
 * This class represents the results of an XPath query on a document or collection. 
 * Later implemntations may want to use this as a base type for a hierarchy of 
 * types based on the XPath type system. 
 *
 * Created: Fri Jan 11 10:56:12 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 */


public interface SixdmlXpathObject  {
   
    /**
     * Get the type of this object as a SixdmlXpathObjectType.
     * @return the type of this object. 
     */
    SixdmlXpathObjectType getType(); 


    /**
     * Returns the contents of the object as a n XML string if it is a nodeset or 
     * null otherwise. 
     * @return the entire contents of the object as a string if it is a nodeset or null otherwise. 
     */
    String getNodeSetAsXML(); 

    /**
     * Returns the object as a boolean. 
     * @return the object as a boolean.
     */
    boolean getObjectAsBoolean(); 

    /**
     * Returns the object as a string.  For a nodeset, this method returns the text form of the 
     * first element in the list. To retrieve the XML for the entire node list, call the 
     * getNodeSetAsXML() method.     
     * @return the object as a string.
     * @see #getNodeSetAsXML()
     */
    String getObjectAsString(); 

    /**
     * Returns the object as a double. 
     * @return the object as a double.
     */
    double getObjectAsNumber(); 

    
    /**
     * Returns the object as a DOM node list. If the actual result is not a node list, null is returned.
     * @return the object as a DOM node list.
     */
    NodeList getObjectAsNodeSet(); 

  
    /*=================================================================*/
    /*                             C O N S T A N T S                   */
    /*=================================================================*/
     
    /**
     * Represents a list of DOM nodes.  
     */
    public static SixdmlXpathObjectType NODESET = new SixdmlXpathObjectType("NODESET");

    /**
     * Represents a DOM tree fragment. 
     */
    public static SixdmlXpathObjectType TREE_FRAGMENT = new SixdmlXpathObjectType("TREE_FRAGMENT");
    
    /**
     * Represents a boolean. 
     */
    public static SixdmlXpathObjectType BOOLEAN = new SixdmlXpathObjectType("BOOLEAN");
    
    /**
     * Represents a string. 
     */
    public static SixdmlXpathObjectType STRING = new SixdmlXpathObjectType("STRING");
    
    /**
     * Represents a number.
     */
    public static SixdmlXpathObjectType NUMBER = new SixdmlXpathObjectType("NUMBER");
    
    /**
     * Represents an unknown result. 
     */
    public static SixdmlXpathObjectType UNKNOWN = new SixdmlXpathObjectType("UNKNOWN");
    

    
} // SixdmlXpathObject
