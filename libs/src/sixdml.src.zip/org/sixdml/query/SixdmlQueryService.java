package org.sixdml.query;
import org.xmldb.api.base.Collection;
import org.xmldb.api.base.Service;
import org.sixdml.dbmanagement.SixdmlCollection;
import org.sixdml.dbmanagement.SixdmlResource;
import org.sixdml.exceptions.InvalidQueryException;
import java.util.HashMap; 
import org.xmldb.api.base.XMLDBException;
import org.sixdml.SixdmlNamespaceMap;
//import java.net.URI; Java 1.4

/**
 * <PRE>
 * SixdmlQueryService.java
 * 
 * This is a Service that enables the execution of XPath queries within the context of a 
 * Collection or against the documents stored in the Collection.
 * 
 * Created: Fri Jan 11 11:55:20 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 */


public interface SixdmlQueryService extends Service {


    /**
     * Set the SixdmlNamespaceMap used by this class to map prefixes to namespace URIs used 
     * in XPath queries. 
     * @param nsMap the new namespace map to use. 
     * @exception XMLDBException if anything goes wrong. 
     */
    void setNamespaceMap(SixdmlNamespaceMap nsMap) throws XMLDBException; 

    /**
     * Add a mapping between a given prefix and a namespace to the service's internal namespace 
     * map. 
     * @param prefix key with which the specified namespace URI is associated.
     * @param namespaceURI value to be associated with the specified prefix. 
     * @exception XMLDBException if anything goes wrong. 
     */
    //void addNamespaceMapping(String prefix, URI namespaceURI) throws XMLDBException; Java 1.4
    void addNamespaceMapping(String prefix, String namespaceURI) throws XMLDBException; 
  
    /**
     * Remove a mapping between a given prefix and a namespace to the service's internal namespace 
     * map. 
     * @param prefix key with which the specified namespace URI is associated.    
     * @exception XMLDBException if anything goes wrong. 
     */
    void removeNamespaceMapping(String prefix) throws XMLDBException; 

    /**
     * Clear all namespace mappings in the service's internal namespace map. 
     * @exception XMLDBException if anything goes wrong. 
     */
    void clearNamespaceMappings() throws XMLDBException;

    /**
     * Obtain the namespace URI mapped to a particular prefix. 
     * @param prefix the prefix whose namespace is being sought. 
     * @return the namespace URI mapped to the prefix or null if the map contains 
     * no mapping for this prefix.
     */
    //URI getNamespaceMapping(String prefix) throws XMLDBException; Java 1.4
    String getNamespaceMapping(String prefix) throws XMLDBException;

    /**
     * Executes an XPath query against the specified collection. 
     * @param query the XPath query. 
     * @param collection the collection to execute the query against. 
     * @return the results of the query as a pairing of SixdmlResources and 
     * SixdmlXpathObjects.
     * @see SixdmlXpathObject
     * @exception InvalidQueryException if the query is not valid XPath. 
     * @exception XMLDBException if a database error occurs 
     */
    SixdmlQueryResultsMap executeQuery(String query, SixdmlCollection collection)
	throws InvalidQueryException, XMLDBException;


    /**
     * Executes an XPath query against the specified collection only returning results from
     * documents that satisfy the given predicate.  
     * @param query the XPath query. 
     * @param collection the collection to execute the query against. 
     * @param predicate an XPath query used to filter which documents the main query is run against. 
     * @return the results of the query as a pairing of SixdmlResources and 
     * SixdmlXpathObjects.
     * @see SixdmlXpathObject
     * @exception InvalidQueryException if the query is not valid XPath. 
     * @exception XMLDBException if a database error occurs 
     */
    SixdmlQueryResultsMap executeQuery(String query, SixdmlCollection collection, String predicate)
	throws InvalidQueryException, XMLDBException;

    /**
     * Executes an XPath query against the specified collection. 
     * @param query the XPath query. 
     * @param collection the collection to execute the query against. 
     * @return the results of the query as a SixdmlXpathObject.
     * @see SixdmlXpathObject
     * @exception InvalidQueryException if the query is not valid XPath. 
     * @exception XMLDBException if a database error occurs 
     */
    SixdmlXpathObject executeQuery(String query, SixdmlResource resource)
	throws InvalidQueryException, XMLDBException;
    
} // SixdmlQueryService
