package org.sixdml.query;


/**
 * <PRE>
 * Represents the type of object that can be returned by an XPath query. 
 * </PRE>
 * @see SixdmlXpathObject#BOOLEAN
 * @see SixdmlXpathObject#NUMBER
 * @see SixdmlXpathObject#NODESET
 * @see SixdmlXpathObject#STRING
 * @see SixdmlXpathObject#TREE_FRAGMENT
 * @see SixdmlXpathObject#UNKNOWN
 */


public final class SixdmlXpathObjectType{

    
      
    /*=================================================================*/
    /*                I N S T A N C E    V A R I A B L E S             */
    /*=================================================================*/
    
    /**
     * This is the collection that holds the Resources.
     */
    private String type;
    
    
    /*=================================================================*/
    /*                        C O N S T U C T O R S                    */
    /*=================================================================*/


    /**
     * Constructor at package scope so cannot be instantiated by objects outside 
     * the package. 
     * @param type the type of XPath object. 
     */
    SixdmlXpathObjectType(String type){this.type = type;} 

    
    /*=================================================================*/
    /*                I N S T A N C E       M E T H O D S              */
    /*=================================================================*/

    /**
     * Returns the type of the index as a string.
     * @return the type of the index as a string.
     */
    public String toString(){ return type;}


}
