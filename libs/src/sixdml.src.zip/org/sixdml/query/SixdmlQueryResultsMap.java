package org.sixdml.query;
import org.sixdml.SixdmlConstants;
import java.util.HashMap; 
import java.util.Set; 
import java.util.Iterator; 
import java.util.Map;
import java.util.Map.Entry;
import org.sixdml.dbmanagement.SixdmlResource;
import java.io.*;

/**
 * <PRE>  
 * SixdmlQueryResultsMap.java
 *
 * A hashtable containing mappings between the results of an XPath query 
 * over a collection and the resources the query results came from. The 
 * primary benefit of this class is its ability to convert itself to 
 * XML if it conatins nodes or nodesets. 
 * <BR>This class is <B>not</B> thread-safe. 
 *
 * Created: Wed Jan 16 00:39:15 2002
 *
 * </PRE>  
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 */

public class SixdmlQueryResultsMap implements SixdmlConstants{
    
    
    /*=================================================================*/
    /*                I N S T A N C E    V A R I A B L E S             */
    /*=================================================================*/
       

    /**
     * This is the table of containing mappings of resource names to query results. 
     */
    private HashMap resultsTable = new HashMap(); 

    
    /**
     * The query whose results are being used to populate this collection 
     */
    private String query;
    
    
    /**
     * The name or path to the collection that was queried to obtain this data. 
     */
    private String colName;
    
  

    /*=================================================================*/
    /*                        C O N S T R U C T O R S                  */
    /*=================================================================*/

    /**
     * Default constructor initializes class.
     * @param colName the name of the collection that this query result object 
     * holds data for. 
     * @param query the query string that generated the results. 
     */
    public SixdmlQueryResultsMap(String colName, String query) {
	
	this.colName = colName;
	this.query   = query;
    }


    /*=================================================================*/
    /*                I N S T A N C E       M E T H O D S              */
    /*=================================================================*/   


    /**
     * Get the value of name of the collection that was queried to create 
     * this object. 
     * @return the name or path to the collection. .
     */
    public String getCollectionName() {return colName;}
    
    
    /**
     * Get the value of query.
     * @return Value of query.
     */
    public String getQuery() {return query;}
     
    
    /**
     * Removes all mappings from this map. 
     */
    public void clear(){

	resultsTable.clear(); 
    }

    /**
     * Returns true if this map contains a mapping for the specified key. 
     * @param key The key whose presence in this map is to be tested. The key should 
     * be the name or path to a resource in the collection that was queried to populate
     * this object. 
     * @return true if this map contains a mapping for the specified key.
     */
    public boolean containsKey(String key){

	return resultsTable.containsKey(key); 
    }


    /**
     * Returns true if this map contains a mapping for the specified value. 
     * @param value The value whose presence in this map is to be tested. The value should 
     * be a String. 
     * @return true if this map contains a mapping for the specified value.
     */
    public boolean containsValue(String value){

	return resultsTable.containsValue(value); 
    }
    
    /**
     * Returns true if this map contains no key-value mappings. 
     * @return true if this map contains no key-value mappings
     */
    public boolean isEmpty(){

	return resultsTable.isEmpty(); 
    }

    /**
     * Returns the number of key-value mappings in this map. 
     * @return the number of key-value mappings in this map.
     */
    public int size(){

	return resultsTable.size(); 
    }

    /**
     * Returns a collection view of the mappings contained in this map. Each element in 
     * the returned collection is a Map.Entry. The collection is backed by the map, so 
     * changes to the map are reflected in the collection, and vice-versa. 
     * @return  collection view of the mappings contained in this map.
     * @see java.util.Map.Entry
     */
    public Set entrySet(){

	return resultsTable.entrySet(); 
    }

    /**
     * Returns the value to which the specified key is mapped in this identity hash map, 
     * or null if the map contains no mapping for this key. A return value of null does not 
     * necessarily indicate that the map contains no mapping for the key; it is also possible 
     * that the map explicitly maps the key to null. The containsKey method may be used to 
     * distinguish these two cases. 
     * @param key  the key whose associated value is to be returned. The key should 
     * be the name or path to a resource in the collection that was queried to populate
     * this object. 
     * @return the value to which this map maps the specified key, or null if the map 
     * contains no mapping for this key.
     */
    public String get(String key){

	return (String) resultsTable.get(key); 
    }

    /**
     * Associates the specified value with the specified key in this map. If the map 
     * previously contained a mapping for this key, the old value is replaced. 
     * @param resource key with which the specified value is to be associated.
     * @param queryResults value to be associated with the specified key. 
     * @return previous value associated with specified key, or null if there was no mapping for key. 
     * A null return can also indicate that the Map previously associated null with the 
     * specified key.
     */
    public String put(String resource, String queryResults){

	return (String) resultsTable.put(resource, queryResults); 
    }


    /**
     * Removes the mapping for this key from this map if present. 
     * @param resource key whose mapping is to be removed from the map. 
     * @return previous value associated with specified key, or null if there 
     * was no mapping for key. A null return can also indicate that the map 
     * previously associated null with the specified key.
     */
    public String remove(String resource){

	return (String) resultsTable.remove(resource); 
    }


    /**
     * Returns an XML representation of the data in this object as a string. The XML 
     * returned by the node conforms to the following DTD. 
     * <PRE>
     * &lt;!ELEMENT query-results (query)+ &gt; 
     * &lt;!ATTLIST query-results collection-name CDATA #REQUIRED &gt;
     * &lt;!ATTLIST query-results query CDATA #REQUIRED &gt;
     * &lt;!ELEMENT query-result (#PCDATA)&gt;   
     * &lt;!ATTLIST query-result resource-name CDATA #REQUIRED &gt;
     * </PRE>
     * @return an XML representation of the data in the map. 
     */
    public String getXML(){	
	
	//build beginning of XML to return 
	StringBuffer toReturn = 
	    new StringBuffer("<?xml version=\"1.0\"?>\n<sixdml:query-results xmlns:sixdml=\""); 
	toReturn.append(SIXDML_NS); 
	toReturn.append("\" collection-name=\""); 
	toReturn.append(this.colName); 
	toReturn.append("\" query=\""); 
	toReturn.append(this.query); 
	toReturn.append("\">\n");  
	
	/* iterate over Map and build XML  */
	Set entries = resultsTable.entrySet(); 
	Iterator it = entries.iterator(); 
	
	while(it.hasNext()){

	    Map.Entry entry = (Map.Entry) it.next();
	    toReturn.append("<sixdml:query-result resource-name=\""); 
	    toReturn.append(entry.getKey().toString()); 
	    toReturn.append("\">\n"); 
	    toReturn.append(entry.getValue().toString()); 
	    toReturn.append("\n</sixdml:query-result>\n"); 
	 
	}//while
	
	
	toReturn.append("</sixdml:query-results>\n"); 
	return toReturn.toString(); 

    }/* getXML() */
    

} // SixdmlQueryResultsMap



