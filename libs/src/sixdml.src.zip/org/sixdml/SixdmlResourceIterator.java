package org.sixdml;
import org.xmldb.api.base.Resource; 
import org.xmldb.api.base.ResourceIterator; 
import java.util.Iterator; 


/**
 *<PRE>
 * SixdmlResourceIterator.java
 * 
 * This class is used to iterate over a set of resources.
 *
 * Created: Thu Jan 10 22:06:18 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 */


public class SixdmlResourceIterator implements ResourceIterator {
    

    /*=================================================================*/
    /*                I N S T A N C E    V A R I A B L E S             */
    /*=================================================================*/
    
    /**
     * The Iterator object that actually holds the Resources. 
     */
    private Iterator it; 

    /*=================================================================*/
    /*                        C O N S T U C T O R S                    */
    /*=================================================================*/

    /**
     * Default constructor private to prevent creation of a SixdmlResourceIterator that 
     * has no underlying Iterator. 
     */
    private SixdmlResourceIterator() {
	
    }
    
    /**
     * Initializes the class using the Iterator passed in as an argument. 
     * @param it an iterator that will be used to initialize this class. 
     */
    SixdmlResourceIterator(Iterator it) {
	this.it = it; 
    }
    

    
    /*=================================================================*/
    /*                I N S T A N C E       M E T H O D S              */
    /*=================================================================*/

    /**
     * Returns true as long as there are still more resources to be iterated. 
     * @return true as long as there are still more resources to be iterated.
     */ 
    public boolean hasMoreResources(){
	return it.hasNext(); 
    }
       
    /**
     * Returns the next Resource instance in the iterator. 
     * @return the next Resource instance in the iterator.
     */
    public Resource nextResource() {
	 return (Resource) it.next();	
    }
       


    /*=================================================================*/
    /*                 S T A T I C        M E T H O D S                */
    /*=================================================================*/

    /**
     * Main used for testing class. 
     * @param args IGNORED
     */
    public static void main(String[] args) {
	
    }
    
} // SixdmlResourceIterator
