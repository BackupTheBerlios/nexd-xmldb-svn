package org.sixdml.xindice; 

import org.sixdml.command.*; 
import org.sixdml.parser.*;

import org.xml.sax.helpers.DefaultHandler;
import org.w3c.dom.*;
import org.xml.sax.*;
import java.io.*; 

import org.xmldb.api.base.XMLDBException;
import org.sixdml.exceptions.*;

import org.apache.xerces.parsers.*;

/**
 * <PRE>
 * SixdmlStatement.java
 *
 * This class is used to execute SiXDML statements over the database.  
 *
 * Created: Sun Feb 24 01:03:24 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 * 
 * @see SixdmlStatementService#createStatement()
 */


class xiSixdmlStatement implements SixdmlStatement{

  
    /*=================================================================*/
    /*                S T A T I C        V A R I A B L E S             */
    /*=================================================================*/

    /**
     * The database driver. 
     */
    private final static String driver = "org.sixdml.xindice.xiSixdmlDatabase"; 

  
    /*=================================================================*/
    /*                        C O N S T R U C T O R S                  */
    /*=================================================================*/

    /**
     * Default constructor initializes service.
     */
    xiSixdmlStatement() {;}


    /*=================================================================*/
    /*                I N S T A N C E       M E T H O D S              */
    /*=================================================================*/   


    /**
     * Executes a SiXDML statement against the database and returns the results as an XML DOM object. 
     * This method is best used if the results of the statement is XML which is not large. 
     * 
     * @param statement the statement to execute 
     * @return the results of the statement as a DOM object. 
     * 
     * @exception SixdmlException if the statement is invalid.
     * @exception XMLDBException  if a database error occurs
     * @exception NonWellFormedXMLException if the results of the SiXDML statement is not well-formed XML   
     */ 
    public Document execute(String statement) throws XMLDBException, SixdmlException, 
						     NonWellFormedXMLException{

	StringBuffer strBuf = new StringBuffer(""); 		
	SixdmlLexer lexer  = new SixdmlLexer(new StringReader(statement)); 
	SixdmlParser parser = new SixdmlParser(lexer);
	
	try{ 
	    parser.sixdmlStatements(strBuf, driver);
	}catch(Exception e){ throw new SixdmlException(e.getMessage(), e); }
	    

	DOMParser xmlParser = new DOMParser();

	try{
	     xmlParser.parse(new InputSource(new StringReader(strBuf.toString())));

	 } catch (SAXException saxe) {
	     throw new NonWellFormedXMLException(saxe.getMessage(), saxe); 
	 } catch (IOException ioe) {
	     throw new NonWellFormedXMLException(ioe.getMessage(), ioe); 
	 }

	 return xmlParser.getDocument(); 

    }/* execute(String) */

    
     /**
     * Executes a SiXDML statement against the database and feeds the results to a SAX handler. 
     * This method is best used if the results of the statement is XML which may be large and the database 
     * supports streaming of the results. 
     * 
     * @param statement the statement to execute 
     * @param handler a SAX handler which operates on the results of the statement. 
     * 
     * @exception SixdmlException if the statement is invalid.
     * @exception XMLDBException  if a database error occurs
     * @exception NonWellFormedXMLException if the results of the SiXDML statement is not well-formed XML     
     */ 
    public void execute(String statement, DefaultHandler handler) throws XMLDBException, SixdmlException,
									 NonWellFormedXMLException{

	StringBuffer strBuf = new StringBuffer(""); 		
	SixdmlLexer lexer  = new SixdmlLexer(new StringReader(statement)); 
	SixdmlParser parser = new SixdmlParser(lexer);

	try{ 
	    parser.sixdmlStatements(strBuf, driver);
	}catch(Exception e){ throw new SixdmlException(e.getMessage(), e); }
	    

	SAXParser xmlParser = new SAXParser();        
        xmlParser.setContentHandler(handler);       

        try {
            xmlParser.parse(new InputSource(new StringReader(strBuf.toString())));
         } catch (SAXException saxe) {
	     throw new NonWellFormedXMLException(saxe.getMessage(), saxe); 
	 } catch (IOException ioe) {
	     throw new NonWellFormedXMLException(ioe.getMessage(), ioe); 
	 }

    }/* execute(String, DefaultHandler) */ 


    /**
     * Executes a SiXDML statement against the database and writes the results to the specified OutputStream. 
     * This method is best used when the results of the statement are not XML. 
     * 
     * @param statement the statement to execute 
     * @param outputStream the stream to write the results to 
     * 
     * @exception SixdmlException if the statement is invalid.
     * @exception XMLDBException  if a database error occurs
     */ 
    public void execute(String statement, OutputStream outputStream) throws XMLDBException, SixdmlException{

	StringBuffer strBuf = new StringBuffer(""); 		
	SixdmlLexer lexer  = new SixdmlLexer(new StringReader(statement)); 
	SixdmlParser parser = new SixdmlParser(lexer);
	
	try{ 
	    parser.sixdmlStatements(strBuf, driver);
	}catch(Exception e){ throw new SixdmlException(e.getMessage(), e); }	

	try {
	    outputStream.write(strBuf.toString().getBytes()); 
	} catch (IOException ioe) {
	    throw new NonWellFormedXMLException(ioe.getMessage(), ioe); 
	}
	
    } /* execute(String, OutputStream) */ 

     /**
     * Executes a SiXDML statement against the database and writes the results using the specified writer. 
     * This method is best used when the results of the statement are not XML. 
     * 
     * @param statement the statement to execute 
     * @param writer the writer to send results to  
     * 
     * @exception SixdmlException if the statement is invalid.
     * @exception XMLDBException  if a database error occurs
     */ 
    public void execute(String statement, Writer writer) throws XMLDBException, SixdmlException{

	StringBuffer strBuf = new StringBuffer(""); 		
	SixdmlLexer lexer  = new SixdmlLexer(new StringReader(statement)); 
	SixdmlParser parser = new SixdmlParser(lexer);

	try{ 
	    parser.sixdmlStatements(strBuf, driver);
	}catch(Exception e){ throw new SixdmlException(e.getMessage(), e); }
	  	
	try{
	    writer.write(strBuf.toString()); 
	} catch (IOException ioe) {
	    throw new NonWellFormedXMLException(ioe.getMessage(), ioe); 
	}
	
    }  /* execute(String, Writer) */ 

}
