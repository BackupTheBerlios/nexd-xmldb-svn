package org.sixdml.xindice;

import org.xmldb.api.base.Configurable;
import org.xmldb.api.base.XMLDBException;
import java.util.HashMap;

/**
 * @author administrator
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class xiConfigurableImpl implements Configurable {

	HashMap hm = new HashMap(0);
	/**
	 * @see org.xmldb.api.base.Configurable#getProperty(String)
	 */
	public String getProperty(String name) throws XMLDBException {
		
		return (String)(hm.get(name));
	}

	/**
	 * @see org.xmldb.api.base.Configurable#setProperty(String, String)
	 */
	public void setProperty(String name, String value) throws XMLDBException {
		hm.put(name, value);
	}

}
