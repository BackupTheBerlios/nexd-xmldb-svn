

package org.sixdml.xindice;
import org.sixdml.*;
import org.xmldb.api.base.*;
import org.sixdml.dbmanagement.SixdmlTransactionService;


/**
 * <PRE>
 * xiSixdmlTransactionService.java
 *
 * This class is a place holder since Xindice does not support transactions.
 * 
 * Created on April 27, 2002, 9:10 PM
 * </PRE>
 */

class xiSixdmlTransactionService extends xiServiceBase implements SixdmlTransactionService{
    
    boolean active = false;
    /** Creates a new instance of xiSixdmlTransactionService */
    public xiSixdmlTransactionService() {
    }
    
    public void begin() throws org.xmldb.api.base.XMLDBException {
        if(isActive()) throw new XMLDBException(ErrorCodes.UNKNOWN_ERROR,"Transaction Aready Active");
        active = true;
    }    
    
    public void commit() throws org.xmldb.api.base.XMLDBException {
        if(!isActive()) throw new XMLDBException(ErrorCodes.UNKNOWN_ERROR,"Transaction Not Yet Active");
        active = false;
    }
    
    public String getName() {
        return "SixdmlTransactionService";
    }
      
    
    /**
     * Returns true if there is currently a transaction open that is neither
     * committed nor aborted; returns false otherwise.
     * @return true if there is currently a transaction open that is neither
     * committed nor aborted; returns false otherwise.
     */
    public boolean isActive() {
            return active;
    }
    
    public void rollback() throws org.xmldb.api.base.XMLDBException {
        throw new XMLDBException(ErrorCodes.UNKNOWN_ERROR,"Not supported");
    }      
   
    
}
