package org.sixdml.xindice;
import java.util.HashMap;
import org.sixdml.SixdmlConstants; 
import org.xmldb.api.base.Service;
import org.xmldb.api.base.Collection;


/**
 * Base class of all services in the org.sixdml.xindice hierarchy. 
 * 
 * @author administrator
 */

abstract class xiServiceBase implements Service, SixdmlConstants {
    
    /*=================================================================*/
    /*                I N S T A N C E    V A R I A B L E S             */
    /*=================================================================*/    
    
    /**
     * The underlying collection object that provides the context for this service, <i>if any</i>. 
     */
    protected Collection collection = null; 

    /**
     * This is the table of properties for the needed by the <code>Configurable</code> interface.
     * @see org.xmldb.api.base.Configurable
     */
    protected HashMap properties = new HashMap(); 


    /*=================================================================*/
    /*                I N S T A N C E       M E T H O D S              */
    /*=================================================================*/


    /**
     * Sets the Collection attribute of the Service object. Does nothing because transactions 
     * exist across sessions and are not specific to collections.
     */
    public void setCollection(Collection col){
	this.collection = null; 
	this.collection = col; 	
    }



    /**
     * Gets the name of the service. 
     * @return the name of the service. 
     */
    abstract public String getName();

     /**
     * Gets the version of the service. 
     * @return the version of the service. 
     */
    public String getVersion(){

	return SIXDML_VERSION; 
    }

 
    /**
     * Returns the value of the property identified by name. 
     * @return the value of the property or null if there is no matching value 
     * for the key in hash table.
     */
    public String getProperty(java.lang.String name){
	return (String) properties.get(name);
    }
    
    /**
     * Sets the property name to have the value provided in value. 
     * @param name the name of the property to set.
     * @param value the value to set for the property.
     */
    public void setProperty(String name, String value){
	properties.put(name, value); 
    } 

} // xlnServiceBase
