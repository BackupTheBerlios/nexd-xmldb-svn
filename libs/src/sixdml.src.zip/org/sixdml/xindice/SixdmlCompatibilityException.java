package org.sixdml.xindice;

import org.sixdml.*;
import org.xmldb.api.base.*;
import org.sixdml.dbmanagement.SixdmlTransactionService;

/**
 * @author administrator
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */



class SixdmlCompatiblityException {
    SixdmlCompatiblityException(String description) throws XMLDBException{
        
        throw new XMLDBException(ErrorCodes.VENDOR_ERROR, description);
        //TODO:Do Vendor stuff
    }
}