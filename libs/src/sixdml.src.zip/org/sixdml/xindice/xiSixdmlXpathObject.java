package org.sixdml.xindice; 

import org.apache.xpath.objects.XObject; 
import java.io.*;
import org.apache.xml.serialize.XMLSerializer;
import org.w3c.dom.*;
import org.sixdml.query.SixdmlXpathObject;
import org.w3c.dom.traversal.NodeIterator;
import org.sixdml.query.SixdmlXpathObjectType;

// Imported Serializer classes
import javax.xml.transform.*;
import javax.xml.transform.stream.*;
import javax.xml.transform.dom.*;


/**
 * <PRE>  
 * xiSixdmlXpathObject.java
 *
 * Represents an object returned from an XPath query. 
 * </PRE>  
 * @version 1.0 
 */

public class xiSixdmlXpathObject implements SixdmlXpathObject {
    
    
    /*=================================================================*/
    /*                I N S T A N C E    V A R I A B L E S             */
    /*=================================================================*/
    
    /**
     * The Xalan XObject instance that this object acts as a wrapper for. 
     */
    private XObject xpathObj = null; 



    /*=================================================================*/
    /*                        C O N S T R U C T O R S                  */
    /*=================================================================*/

    /**
     * Default constructor private because an instance of this class must always 
     * be instantiated with an underlying eXcelon DXE XPathValue object.
     */
    private xiSixdmlXpathObject() {;}


    /**
     * Initializes this class with an XObject instance.
     * @param xpathVal the XObject instance.
     */
    xiSixdmlXpathObject(XObject xpathVal){

	this.xpathObj = xpathVal; 
    }
    


    
    /*=================================================================*/
    /*                I N S T A N C E       M E T H O D S              */
    /*=================================================================*/

    /**
     * Get the type of this object as a SixdmlXpathObjectType.
     * @return the type of this object. 
     */
    public SixdmlXpathObjectType getType(){

	switch(xpathObj.getType()){
	    
	case XObject.CLASS_BOOLEAN: return SixdmlXpathObject.BOOLEAN; 
	    
	case XObject.CLASS_STRING: return SixdmlXpathObject.STRING; 
	    
	case XObject.CLASS_NUMBER: return SixdmlXpathObject.NUMBER; 
	    
	case XObject.CLASS_NODESET: return SixdmlXpathObject.NODESET; 
		
	case XObject.CLASS_RTREEFRAG: return SixdmlXpathObject.TREE_FRAGMENT; 

	}

	return SixdmlXpathObject.UNKNOWN; 

    }/* getType() */ 


    /**
     * Returns the object as a boolean. 
     * @return the object as a boolean.
     */
    public boolean getObjectAsBoolean(){

	boolean b = false; 

	try{
	    b = xpathObj.bool(); 
	}catch(javax.xml.transform.TransformerException te){
	    new RuntimeException(te.getMessage()); 
	}

	return b;
    } 

    /**
     * Returns the object as a string. For a nodeset the text form of the first element in the set
     * is returned to be compatible with the XPath spec. For retrieval of the entire XML from 
     * a nodeset the <code>getNodeSetAsXML()</code> method should be used. 
     * @see #getNodeSetAsXML
     * @return the object as a string. 
     */
    public String getObjectAsString(){
		
	return  xpathObj.str(); 
    }

    /**
     * Returns the object as a double. 
     * @return the object as a double.
     */
    public double getObjectAsNumber(){
	
	double d = 0; 
	
	try{
	    d = xpathObj.num(); 	
	}catch(javax.xml.transform.TransformerException te){
	    new RuntimeException(te.getMessage()); 
	}
	
	return d; 
    }

    
    /**
     * Returns the object as a DOM node list. 
     * @return the object as a DOM node list.
     */
    public NodeList getObjectAsNodeSet(){

	NodeList n = null; 

	try{
	    n = new org.apache.xpath.NodeSet(xpathObj.nodeset()); 
	}catch(javax.xml.transform.TransformerException te){
	    new RuntimeException(te.getMessage()); 
	}	

	return n;
    }


    /**
     * Returns the contents of the object as an XML string if it is a nodeset or 
     * null otherwise. 
     * @return the entire contents of the object as a string if it is a nodeset or null otherwise. 
     */
    public String getNodeSetAsXML(){
   
	if(xpathObj.getType()!= XObject.CLASS_NODESET)
	    return null; 	

	StringBuffer toReturn = new StringBuffer();

	try{
	    
	NodeIterator results = xpathObj.nodeset(); 
	Node result; 	


	/* TODO: Fix the fact that too many objects created and discarded in the following loop. */
	while((result = results.nextNode())!= null){
	    
	    //System.out.println("XPath Results: Name (" + result.getNodeName() + ") Value (" + result.getNodeValue() + ")");
	    DocumentFragment frag = result.getOwnerDocument().createDocumentFragment(); 	    
	    frag.appendChild(result.cloneNode(true)); 
	    
	    ByteArrayOutputStream baos = new ByteArrayOutputStream(); 

	    // Set up an identity transformer to use as serializer
	    Transformer serializer = TransformerFactory.newInstance().newTransformer();
	    serializer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
	    serializer.transform(new DOMSource(result), new StreamResult(baos));

	    String fragment = baos.toString();		    	   

	    toReturn.append(fragment + "\n"); 	    
	}

	}catch(Exception e){
	    throw new RuntimeException(e.getMessage()); 
	}

	return toReturn.toString(); 
    }
    
} // xiSixdmlXpathObject
