package org.sixdml.xindice;
import org.sixdml.dbmanagement.*;
import java.util.HashMap;
import org.sixdml.SixdmlConstants;
import org.w3c.dom.*;
import java.io.IOException;
import java.io.StringReader;
import org.sixdml.exceptions.*;
import org.apache.xerces.parsers.DOMParser;
import org.xml.sax.*;

/**
 * <PRE>  
 * xiSixdmlIndex.java
 *
 * A database index. 
 * </PRE>  
 * @version 1.0 
 */
 

public class xiSixdmlIndex implements SixdmlIndex , SixdmlConstants{
    
    /*=================================================================*/
    /*                I N S T A N C E    V A R I A B L E S             */
    /*=================================================================*/
 
     /**
     * The name of the index.  
     */
    private String name; 

    /**
     * The fields of this index. 
     * @see xiSixdmlIndex#getIndexFields()
     */
    private HashMap indexFields = new HashMap();

    /*=================================================================*/
    /*                        C O N S T R U C T O R S                  */
    /*=================================================================*/

    /**
     * Default constructor private because one must always create an xiSixdmlIndex
     * with an indexFields table. 
     */
    private xiSixdmlIndex() {;}

    /**
     * Creates an index with a name and  an indexFields table. <BR>
     * <B>NOTE</b>: Runtime error may occur if table not properly populated. 
     * @param name the name of the index. 
     * @param indexFields the index fields for the class. 
     */
    xiSixdmlIndex(String name, HashMap indexFields){
	
	this.name = name; 
	this.indexFields = indexFields; 		
    }

   

    /*=================================================================*/
    /*                S T A T I C       M E T H O D S                  */
    /*=================================================================*/


    
    /**
     * Creates a xiSixdmlIndex object from an XML serialization of the class. <BR>
     * <b>NOTE</b>: This code assumes that the XML node contains XML that conforms to the 
     * following DTD <BR>
     * <PRE>
     * &lt;!ELEMENT index(name, type, key, pagesize?, maxkeysize?)&gt; 
     * &lt;!ELEMENT name (#PCDATA)&gt; 
     * &lt;!ELEMENT type (#PCDATA)&gt; 
     * &lt;!ELEMENT key (#PCDATA)&gt; 
     * &lt;!ELEMENT pagesize (#PCDATA)&gt; 
     * &lt;!ELEMENT maxkeysize (#PCDATA)&gt; 
     * </PRE>
     * @param xmlNode the XML representation of the object to create
     * @return the newly created index. 
     */
    static xiSixdmlIndex  createIndex(Element xmlNode){
	
	HashMap indexFields = new HashMap(); 

	//get the name of our index
	String name =  xmlNode.getElementsByTagNameNS(SIXDML_NS, "name").item(0).getFirstChild().getNodeValue();
	
	//get the index key of our index
	String key = xmlNode.getElementsByTagNameNS(SIXDML_NS, "key").item(0).getFirstChild().getNodeValue();
	indexFields.put("pattern", key); 
       

	 //get the maximum key size
	NodeList nodelist = null; 
	nodelist =  xmlNode.getElementsByTagNameNS(SIXDML_NS, "maxkeysize"); 
	
	
	if(nodelist.getLength() > 0)
	    indexFields.put("maxkeysize", nodelist.item(0).getFirstChild().getNodeValue()); 

	//get the page size 
	nodelist =  xmlNode.getElementsByTagNameNS(SIXDML_NS, "pagesize"); 

	if(nodelist.getLength() > 0)
	    indexFields.put("pagesize", nodelist.item(0).getFirstChild().getNodeValue()); 


	return new xiSixdmlIndex(name, indexFields); 
	       
    }/* createIndex(Element) */


    /*=================================================================*/
    /*                I N S T A N C E       M E T H O D S              */
    /*=================================================================*/
   

   
    /**
     * Get the name of the index.
     * @return Value of name.
     */
    public String getName(){ return this.name; }
    

    /**
     * Returns the type of the index. 
     * @return type of the index. 
     */
    public SixdmlIndexType getType(){
        
	return SixdmlIndexType.VALUE_INDEX;
    } /* getType() */
    
    /**
     * Returns a hash table containing various characteristics of the index depending on
     * its type. All eXcelon DXE indexes will have an entry for "key", "indexElement", 
     * "options" and "type".
     * Both the "options" and "type" fields will be  integer values that will be one of a range 
     * of values defined as static ints in the XlnIndex, XlnTextIndex and XlnValueIndex classes. 
     * @return a hash table containing the relevant data about the index. The hashtable returned 
     * is a COPY of the one used by this class internally. 
     */
    public synchronized HashMap getIndexFields(){
	
	HashMap toReturn = new HashMap(); 
	toReturn.putAll(this.indexFields); 
	return toReturn; 

    }/* getIndexFields() */


    /**
     * Creates an XML representation of this object that conforms to the following DTD
     * as a DOM node. 
     * <PRE>
     * &lt;!ELEMENT index(key, pagesize?, maxkeysize?)&gt; 
     * &lt;!ATTLIST index name CDATA #REQUIRED &gt;
     * &lt;!ELEMENT key (#PCDATA)&gt; 
     * &lt;!ELEMENT pagesize (#PCDATA)&gt; 
     * &lt;!ELEMENT maxkeysize (#PCDATA)&gt; 
     * </PRE>
     * @return a DOM Node containing the XML representation of this class. 
     */
    public Node getXMLAsNode(){

	//  Create a Xerces DOM Parser
	DOMParser parser = new DOMParser();

      try{
	  parser.parse(new InputSource(new StringReader(this.getXMLAsString())));

      } catch (SAXException saxe) { /* shouldn't happen */
	  saxe.printStackTrace(); 
      } catch (IOException ioe) {  /* shouldn't happen */
	  ioe.printStackTrace(); 
      } 
	
      return parser.getDocument().getDocumentElement(); 
              
    }/* getXMLAsNode() */

    /**
     * Creates an XML representation of this object that conforms to the following DTD as 
     * a string. 
     * <PRE>
     * &lt;!ELEMENT index(name, type, key, pagesize?, maxkeysize?)&gt; 
     * &lt;!ELEMENT name (#PCDATA)&gt; 
     * &lt;!ELEMENT type (#PCDATA)&gt; 
     * &lt;!ELEMENT key (#PCDATA)&gt; 
     * &lt;!ELEMENT pagesize (#PCDATA)&gt; 
     * &lt;!ELEMENT maxkeysize (#PCDATA)&gt; 
     * </PRE>
     * @return a string containing the XML representation of this class. 
     */
    public String getXMLAsString(){
	
	StringBuffer xmlStr = new StringBuffer("<sixdml:index xmlns:sixdml=\"");
	xmlStr.append(SIXDML_NS);	
	xmlStr.append("\">\n<sixdml:name>"); 
	xmlStr.append(this.name);	    
	xmlStr.append("</sixdml:name>\n<sixdml:type>");
	 
        xmlStr.append(indexFields.get("type")); 
	
        xmlStr.append("</sixdml:type>\n<sixdml:key>");
	xmlStr.append(indexFields.get("pattern")); 
	xmlStr.append("</sixdml:key>\n");
	

	/* should these elements come from another namespace Xindice specific namespace? */
	if(indexFields.get("pagesize")!= null)
	    xmlStr.append("<sixdml:pagesize>" + indexFields.get("pagesize") + "</sixdml:pagesize>");

	if(indexFields.get("maxkeysize")!= null)
	    xmlStr.append("<sixdml:maxkeysize>" + indexFields.get("maxkeysize") + "</sixdml:maxkeysize>"); 
	
	xmlStr.append("</sixdml:index>\n"); 
 
	return xmlStr.toString(); 

    }/* getXMLAsString() */


    /**
     * Compares two objects of this class. Returns true if they have the same name and same values 
     * in their index fields. 
     * @param obj the object to compare. 
     * @return true if they have the same name and values in their index fields, false otherwise. 
     */
    public boolean equals(Object obj){

	if(this == obj) 
	    return true; 
	
	if((obj != null) && (this.getClass().equals(obj.getClass())) ){

	    xiSixdmlIndex xsi = (xiSixdmlIndex) obj;  
	    
	    if(this.getXMLAsString().equals(xsi.getXMLAsString())){
		return true;
	    }	
	}
	return false; 

    }/* equals(Object) */

} // xiSixdmlIndex




