package org.sixdml.xindice;
import org.sixdml.transform.SixdmlTransformType;
import org.sixdml.transform.SixdmlTransformService;
import org.xmldb.api.base.Database;
import org.xmldb.api.base.XMLDBException;
import org.xmldb.api.base.Resource;
import org.xmldb.api.base.Collection;
import org.xmldb.api.base.Service;
import org.xmldb.api.modules.CollectionManagementService;
import org.apache.xindice.client.xmldb.CollectionImpl;
import org.sixdml.SixdmlDatabase;
import java.util.HashMap; 
import org.sixdml.exceptions.UnsupportedIndexTypeException;
import org.xmldb.api.DatabaseManager; 
import org.sixdml.dbmanagement.*; 
import org.xmldb.api.base.ErrorCodes;
import org.xmldb.api.modules.XMLResource;

/**
 * <PRE>  
 * xiSixdmlDatabase.java
 *
 * The database object that represents an interface to the Xindice database.
 * </PRE>  
 * @version 1.0 
 */

public class xiSixdmlDatabase implements SixdmlDatabase {
   

    /**
     * Class name of Xindice database driver. 
     */
    String driver = "org.apache.xindice.client.xmldb.DatabaseImpl";

    /**
     * The Xindice Database object wrapped by this class. 
     */
    Database database;

    /**
     * Used for retrieving services. 
     * @see #getService(String, String)
     * @see #getServices()
     */
    private static xiSixdmlDatabase db; 

    /**
     * Initializes the class. 
     */
    public xiSixdmlDatabase() {

        try {
            Class c = Class.forName(driver);
            database = (Database) c.newInstance();
        }
        catch(Exception e) {
            System.err.println("Could not create instance of " + driver);
            e.printStackTrace(System.err);
	    System.exit (-1);
        }

    }

     /**
     * Creates singleton xiSixdmlDatabase instance for use in retrieving resources and collections. 
     * @see #db
     */
    synchronized static xiSixdmlDatabase getDB(){

	return db = (db == null ? new xiSixdmlDatabase() : db);  
    }



    /**
     * Gets the specified resource from the database. 
     * @param name the resource to obtain. This should be in the format 
     * <path-to-collection>/<xindice-key>. For example an XMl document with named foo.xml with the 
     * Xindice key 'mydoc' in the collection xindice:///db/examples/ will have the name 
     * /db/addressbook/mydoc 
     * @param username The username to use for authentication to the database or 
     * null if the database does not support authentication.
     * @param password The password to use for authentication to the database or 
     * null if the database does not support authentication.
     * @return the requested resource. 
     * @exception XMLDBException if an error occurs. 
     * @see ErrorCodes#NO_SUCH_COLLECTION
     * @see ErrorMessages#DUPLICATE_COLLECTION
     */
    public Resource getResource(String name, String username, String password) throws XMLDBException {
        
	//System.out.println("URI: " + name );	

	if(name.indexOf("xindice://")== -1){
	    
	    if(!name.startsWith("/"))
		name = "/db/" + name; 
	    
	    name = "xindice://" + name;
	}

	int fileNameIdx = name.lastIndexOf("/"); 

	if(fileNameIdx == -1)
	    throw new XMLDBException(ErrorCodes.INVALID_URI, ErrorMessages.BAD_URI); 

	String colName  = name.substring(0, fileNameIdx); 
	String rsrcName = name.substring(fileNameIdx + 1); 

	//System.out.println("COL NAME:" + colName + "\nRES NAME:" + rsrcName);

	SixdmlCollection col = (SixdmlCollection) this.getCollection(colName, username, password); 

	 if(col == null)
		throw new XMLDBException(ErrorCodes.NO_SUCH_COLLECTION, colName + " : " 
					 + ErrorMessages.NO_SUCH_COLLECTION); 

	SixdmlResource res   = (SixdmlResource)col.getResource(rsrcName); 
	
	return res; 	
    }

    
    

    /**
     * Gets the types of index that are supported by the this database. 
     * @return an array of SixdmlIndexTypes which the database supports.
     * @exception XMLDBException if an error occurs. 
     */
    public SixdmlIndexType[] getSupportedIndexTypes() throws XMLDBException {
        return new SixdmlIndexType[]{SixdmlIndexType.VALUE_INDEX};
    }
 
      /**
     * Gets the types of transforms that are supported by the this database. 
     * @return an array of SixdmlTransformTypes which the database supports.
     * @exception XMLDBException if an error occurs. 
     */
    public SixdmlTransformType[] getSupportedTransformTypes() throws XMLDBException {
        return new SixdmlTransformType[]{SixdmlTransformType.XSLT}; 
    }

     /**
     * Provides a list of all services known to the collection. If no services are known an 
     * empty list is returned.
     * @return An array of registered Service implementations.
     * @exception XMLDBException if an error occurs. 
     */
    public Service[] getServices() throws XMLDBException {
        
	return this.getServices((xiSixdmlCollection)this.getCollection("/db/", "", "")); 
    }


    /**
     * Provides a list of all services known to the collection. If no services are known an 
     * empty list is returned.
     * @param collection The SixdmlCollection to use to initialize the xiSixdmlCollectionManagementService.
     * @return An array of registered Service implementations.
     * @exception XMLDBException if an error occurs. 
     */
    Service[] getServices(xiSixdmlCollection collection) throws XMLDBException {
        
	//TODO: Consider using singeletons. 
	//Ahhh, but how to deal with namespace consistency for queries?
        return new Service[]{ new xiSixdmlTransactionService(), 
			      new xiSixdmlQueryService(), 
			      new xiXsltTransformService(), 
			      new xiSixdmlCollectionManagementService(collection), 
			      new xiSixdmlUpdateService(),
			      new xiSixdmlStatementService()}; 
    }
    
     /**
     * Returns a Service instance for the requested service name and version. If no 
     * Service exists for those parameters a null value is returned. The only valid 
     * name and version number for this implementation are "XSLT" and "1.0" respectively.
     * @param name the name of the service to return. 
     * @param version the version number of the service to return. 
     * @exception XMLDBException if an error occurs. 
     */
    public Service getService(String name, String version) throws XMLDBException {        
        
        //TODO: how are we going to manage versions?
        
        if(!version.equals(org.sixdml.SixdmlConstants.SIXDML_VERSION)) 
	    throw new XMLDBException(ErrorCodes.VENDOR_ERROR, ErrorMessages.WRONG_VERSION);
        
        Service service = null;
        

	//TODO: Consider using singeletons. 
        
        if(name.equals("SixdmlTransactionService")) 
            service =  new xiSixdmlTransactionService();
	else if(name.equals("SixdmlQueryService"))
	    service = new xiSixdmlQueryService();
	else if(name.equals("XsltTransformService"))
	    service = new xiXsltTransformService();
	else if(name.equals("SixdmlStatementService"))
	    service = new xiSixdmlStatementService();
	else if(name.equals("SixdmlUpdateService"))
	    service = new xiSixdmlUpdateService();
        else if(name.equals("SixdmlCollectionManagementService"))     	
	    service = new xiSixdmlCollectionManagementService((xiSixdmlCollection)this.getCollection("/db/", "", "")); 
        
        return service;
    }


    /**
     * Returns a Service instance for the requested service name and version. If no 
     * Service exists for those parameters a null value is returned. The only valid 
     * name and version number for this implementation are "XSLT" and "1.0" respectively.
     * @param name the name of the service to return. 
     * @param version the version number of the service to return. 
     * @param collection The SixdmlCollection to use to initialize the xiSixdmlCollectionManagementService.
     * @exception XMLDBException if an error occurs. 
     */
    public Service getService(String name, String version, xiSixdmlCollection collection) throws XMLDBException{  
        
        //TODO: how are we going to manage versions?
        
        if(!version.equals(org.sixdml.SixdmlConstants.SIXDML_VERSION)) 
	    throw new XMLDBException(ErrorCodes.VENDOR_ERROR, ErrorMessages.WRONG_VERSION);
        
        Service service = null;
        

	//TODO: Consider using singeletons. 
        
        if(name.equals("SixdmlTransactionService")) 
            service =  new xiSixdmlTransactionService();
	else if(name.equals("SixdmlQueryService"))
	    service = new xiSixdmlQueryService();
	else if(name.equals("XsltTransformService"))
	    service = new xiXsltTransformService();
	else if(name.equals("SixdmlUpdateService"))
	    service = new xiSixdmlUpdateService();
        else if(name.equals("SixdmlCollectionManagementService")) 
	    service = new xiSixdmlCollectionManagementService(collection); 
        
        return service;
    }


    /**
     * Determines whether this Database implementation can handle the URI. It should return 
     * true if the Database instance knows how to handle the URI and false otherwise. In this 
     * implementation it checks to see if the target of the URI exists in the DB, this may not
     * be what is meant for this method to do. 
     * @param uri the URI to check for.
     * @return true if the URI can be handled, false otherwise
     */
    public boolean acceptsURI(String str) throws org.xmldb.api.base.XMLDBException {
        return database.acceptsURI(str);
    }
    

    /**
     * Retrieves a Collection instance based on the URI provided in the uri parameter. This 
     * implementation does <b>not</b> support authentication. 
     * @param uri the URI to use to locate the collection. This must be a hierarchical directory 
     * path NOT a URI scheme such as xindice:// or xmldb://
     * @param username The username to use for authentication to the database or 
     * null if the database does not support authentication.
     * @param password The password to use for authentication to the database or 
     * null if the database does not support authentication.
     * @return the requested vollection. 
     * @exception XMLDBException if no such collection exists 
     */
    public Collection getCollection(String uri, String username, String password) 
	throws XMLDBException {
	
	SixdmlCollection col = null; 
	//System.out.println("URI: '" + uri + "'\nUSERNAME: '" + username + "'\nPASSWORD: '" + password +"'");

	if(uri.indexOf("xindice://")== -1){
	    
	    if(!uri.startsWith("/"))
		uri = "/db/" + uri; 

	    uri = "xindice://" + uri;
	}

        try {
	    Collection col2 = database.getCollection(uri, username, password);

	    if(col2 == null)
		return col2; 
	    else
		col = new xiSixdmlCollection(col2); 
      
        }catch(XMLDBException xmldbe){
	    if (col != null) {
		col.close();
	    }
	    throw xmldbe; 
	}

	 return col; 
    }
	
      /**
     * Returns the XML:DB API Conformance level for the implementation. This can 
     * be used by client programs to determine what functionality is available to them.
     * @return XML:DB API conformance level for this implementation.
     */
    public String getConformanceLevel() throws org.xmldb.api.base.XMLDBException {
        return "0";
    }
    
    
    /**
     * Returns the name associated with the Database instance.
     * @return the name of the database instance. 
     */
    public String getName() throws org.xmldb.api.base.XMLDBException {       
        return database.getName();        
    }
    

     /**
     * Returns the value of the property identified by name. 
     * @return the value of the property or null if there is no matching value 
     * for the key in hash table.
     */
    public String getProperty(String str) throws org.xmldb.api.base.XMLDBException {
        return database.getProperty(str);
    }

    /**
     * Sets the property name to have the value provided in value. 
     * @param name the name of the property to set.
     * @param value the value to set for the property.
     */
    public void setProperty(String str, String str1) throws org.xmldb.api.base.XMLDBException {
        database.setProperty(str,str1);
    }


    /**
     * Main used for testing class. 
     * @param args IGNORED
     */
    public static void main(String[] args) throws Exception{

	String driver = "org.sixdml.xindice.xiSixdmlDatabase";
	Class c = Class.forName(driver);
	SixdmlDatabase database = (org.sixdml.SixdmlDatabase) c.newInstance(); 
	DatabaseManager.registerDatabase(database); 

	Collection col = DatabaseManager.getCollection("xmldb:xindice:///db/"); 

	System.out.println(col.getName());

    }
    

} // xiSixdmlDatabase







