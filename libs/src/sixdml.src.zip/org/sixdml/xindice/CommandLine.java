package org.sixdml.xindice;

import org.sixdml.*;
import org.sixdml.exceptions.*; 
import org.sixdml.command.*; 
import org.sixdml.dbmanagement.*; 

import org.xmldb.api.*; 
import org.xmldb.api.base.*;
import java.io.*; 

/**
 * Command line interface for interacting with Xindice via SiXDML. 
 */ 

class CommandLine{

    /**
     * Main method contains loop which keeps accepting statements terminated with a ';' until 
     * it sees the string "exit" with no semi colons. 
     * 
     * @param args IGNORED
     */
    public static void main(String[] args) throws Exception{

	BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	String sixdml = ""; 
	boolean done  = false; 

	Collection col = null;

	String driver = "org.sixdml.xindice.xiSixdmlDatabase";
	Class c = Class.forName(driver);

	SixdmlDatabase database = (SixdmlDatabase) c.newInstance(); 
	SixdmlTransactionService transaction = 
	    (SixdmlTransactionService) database.getService("SixdmlTransactionService", "1.0"); 

	transaction.begin(); 
	DatabaseManager.registerDatabase(database); 

	SixdmlStatementService stmtManager = 
	    (SixdmlStatementService) database.getService("SixdmlStatementService", "1.0"); 

	

	/* TODO: Write a loop that reads until the last thing entered was a ';', rinse, repeat */ 
	do { 
	    
	    System.out.print(">");
	    sixdml += in.readLine(); 
	    
	    try{

		if(sixdml.trim().endsWith(";")){
		    SixdmlStatement stmt = stmtManager.createStatement(); 
		    stmt.execute(sixdml, System.out); 
		    sixdml = ""; 
		}
		
	    }catch(SixdmlException e){
		System.out.println(e.getMessage());
		sixdml = ""; 
	    }
	
    }while(!sixdml.trim().toLowerCase().equals("exit")); 

    }/* main(String[]) */ 
}
