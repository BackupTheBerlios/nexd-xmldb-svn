package org.sixdml.xindice;

import org.sixdml.dbmanagement.SixdmlResource;
import org.w3c.dom.*;
import org.xml.sax.ContentHandler;

import org.xmldb.api.base.Collection;
import org.xmldb.api.base.XMLDBException;
import org.xmldb.api.base.Resource;
import org.xmldb.api.modules.XMLResource;


/**
 * <PRE>
 * xiSixdmlCollection.java
 *
 * An implementation of the <code>SixdmlResource</code> interface which maps to an XML resource  in
 * Xindice. This class is <b>NOT</b> thread safe.
 * </PRE>
 * @version 1.0
 */
public class xiSixdmlResource implements SixdmlResource {

    /**
     * The underlying Xindice resource used by this class. 
     */ 
    XMLResource resource; 

    /**
     * The name of the resource, which should be the same as the Xindice key of XML file. 
     */
    private String name = null;


    /**
     * Default constructor private because an instance of this class must always 
     * be instantiated with an underlying Xindice XML resource.
     */
    private xiSixdmlResource() {;}

    /**
     * Creates a resource from a Xindice XML resource. 
     * @param resource the resource to initilize this object with. 
     * @exception XMLDBException if a call to the getId() function of the Resource passed in 
     * fails. 
     * @see Resource#getId()
     */ 
    xiSixdmlResource(XMLResource resource) throws XMLDBException{
	       
	this.resource = resource;
	this.name     = resource.getId(); 
    }

    /**
     * Gets the name of the resource.
     *
     * @return The name of the resource
     */
    public String getName(){
	return name;
    }

    /**
     * Returns the unique id for the parent document to this Resource. Both getId() and getDocumentId() 
     * will always return the same id.
     * @return the id for this Resource 
     */
    public String getDocumentId(){

	return name;
    }
	

	
    /**
     * Returns the content of the Resource as a DOM Node by making a deep copy of the DOM document
     * used internally by this resource. 
     * @return A deep copy of the document element node of this object's internal DOM. 
     */
    public Node getContentAsDOM() throws XMLDBException {
	return ((XMLResource)resource).getContentAsDOM();
    }

    /**
     * Sets the content of the Resource using a DOM Node as the source. The assumption 
     * is that the node will be an eXcelon DXE DOM node. 
     * @param content The new content value
     * @exception XMLDBException if the DOM node is not an Element node. 
     */
    public void setContentAsDOM(Node content) throws XMLDBException {
	resource.setContentAsDOM(content); 
    }

    /**
     * Gets the content of the Resource using SAX ContentHandler as the source.  
     * @param handler the SAX content handler 
     * @exception XMLDBException always.  
     */ 
    public void getContentAsSAX(ContentHandler handler) throws XMLDBException {
	resource.getContentAsSAX(handler);
    }

    /**
     * Sets the content of the Resource using a SAX ContentHandler. This feature
     * is <B>not implemented</b>
     * @return a SAX ContentHandler that can be used to add content into the Resource
     * @exception XMLDBException always. 
     */
    public ContentHandler setContentAsSAX() throws XMLDBException {
	return resource.setContentAsSAX();
    }

     /**
     * Returns the Collection instance that this resource is associated with. All 
     * resources must exist within the context of a collection.
     * @return the collection associated with the resource.
     */
    public Collection getParentCollection() throws XMLDBException {
	return new xiSixdmlCollection(resource.getParentCollection());
    }

    /**
     * Returns the unique id for this Resource or null if the Resource is anonymous. 
     * The Resource will be anonymous if it is obtained as the result of a query.
     * @return the id for the Resource or null if no id exists.
     */
    public String getId() throws XMLDBException {
	return name;
    }

    /**
     * Returns the resource type for this Resource. This always returns the string "XMLResource"
     * @return the resource type for this Resource. 
     */
    public String getResourceType() throws XMLDBException {
	return resource.getResourceType();
    }

	
    /** 
     * Retrieves the content from the resource. The actual type of the content is java.lang.String
     * @return the content of the resource.
     */
    public Object getContent() throws XMLDBException {
	return resource.getContent();
    }

    /**
     * Sets the content for this resource. It is expected that the content being passed in is 
     * a string or something that returns XML when its toString() method is called. 
     * @param value the content value to set for the resource.
     */	public void setContent(Object value) throws XMLDBException {
	 resource.setContent(value); 
     }

    /**
     * Main used for testing class. 
     * @param args IGNORED
     */
    public static void main(String[] args) throws Exception{

	
	String driver = "org.sixdml.xindice.xiSixdmlDatabase";
	Class c = Class.forName(driver);
	org.sixdml.SixdmlDatabase database = (org.sixdml.SixdmlDatabase) c.newInstance(); 
	org.xmldb.api.DatabaseManager.registerDatabase(database); 

	SixdmlResource res = (SixdmlResource) database.getResource("/db/addressbook/address1", "", ""); 

	System.out.println(res.getName());
	System.out.println(res.getContent());

	System.out.println(((Document)res.getContentAsDOM()).getDocumentElement().getTagName());

    }

}
