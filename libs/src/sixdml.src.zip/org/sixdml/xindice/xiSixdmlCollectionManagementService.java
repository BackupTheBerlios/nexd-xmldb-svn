package org.sixdml.xindice;

import org.sixdml.*;
import java.util.HashMap;
import java.net.URL; 
import org.sixdml.SixdmlConstants;
import org.xmldb.api.base.Collection;
import org.xmldb.api.base.XMLDBException;
import java.io.IOException;
import org.xmldb.api.base.ErrorCodes;
import org.sixdml.exceptions.*;
import org.xmldb.api.DatabaseManager; 
import org.sixdml.dbmanagement.*;
import org.apache.xindice.client.xmldb.services.CollectionManager; 
import org.apache.xindice.tools.command.Command;

/**
 * <PRE>  
 * xiSixdmlCollectionManagementService.java
 *
 * Manages the creation and deletion of collections in the database. 
 * </PRE>  
 * @version 1.0 
 */

class xiSixdmlCollectionManagementService extends xiServiceBase implements SixdmlCollectionManagementService, 
							     SixdmlConstants{
    
    /*=================================================================*/
    /*                I N S T A N C E    V A R I A B L E S             */
    /*=================================================================*/    

     /**
     * The underlying collection object that provides the context for this service. 
     */
    private xiSixdmlCollection collection = null; 

    


    /*=================================================================*/
    /*                        C O N S T R U C T O R S                  */
    /*=================================================================*/    

    /**
     * Initializes the service. 
     * @param collection the collection that owns this CollectionManagementService
     */
    xiSixdmlCollectionManagementService(xiSixdmlCollection collection){
	this.collection = collection; 
    }

    /*=================================================================*/
    /*                I N S T A N C E       M E T H O D S              */
    /*=================================================================*/
    


      /**
     * Gets the types of index that are supported by the this database. 
     * @return an array of SixdmlIndexTypes which the database supports.
     */
    public SixdmlIndexType[] getSupportedIndexTypes(){

	return new SixdmlIndexType[] {SixdmlIndexType.VALUE_INDEX};
    }

    /**
     * Creates an index with a name and an indexFields table in the Xindice database. <BR>
     * <B>NOTE</b>: Runtime error may occur if table not properly populated. 
     * @param name the name of the index. 
     * @param indexFields the index fields for the class. 
     * @exception UnsupportedIndexTypeException if the type of index requested is unsupported by the 
     * database. 
     */
    public SixdmlIndex createIndex(String name, HashMap indexFields) throws UnsupportedIndexTypeException{

	String type = (String) indexFields.get("type"); 

	//throw exception if we unknown index type 
	if(!type.equals(SixdmlIndexType.VALUE_INDEX.toString()))
	   throw new UnsupportedIndexTypeException(); 
	   
	   return new xiSixdmlIndex(name, indexFields); 

    }/* createIndex(String, HashMap) */ 


    /**
     * Creates a new Collection in the database.
     * @param name The name of the collection to create.
     * @return The created Collection instance.
     * @exception XMLDBException if the collection already exists or  
     * one of the collections in the path given does not exist. 
     * @see ErrorCodes#NO_SUCH_COLLECTION
     * @see ErrorMessages#DUPLICATE_COLLECTION
     */
    public Collection createCollection(String name) throws XMLDBException{

	int fileNameIdx           = name.lastIndexOf("/"); 
	CollectionManager colMgr  = null; 
	xiSixdmlCollection newCol = null; 

	if(fileNameIdx == -1){

	    System.out.println("Creating collection " + name);
	    System.out.flush(); 

	   colMgr = 
	       (CollectionManager) this.collection.collection.getService("CollectionManager", Command.XMLDBAPIVERSION);
	   newCol =  new xiSixdmlCollection(colMgr.createCollection(name));

	}else{
	
	    String parentColName       = name.substring(0, fileNameIdx); 
	    String newColName          = name.substring(fileNameIdx + 1); 

	    System.out.println("Creating collection /db/" + parentColName + "/" + newColName);
	    xiSixdmlCollection parentCol = 
		(xiSixdmlCollection) xiSixdmlDatabase.getDB().getCollection("/db/" + parentColName, "", ""); 
	    
	    if(parentCol == null)
		throw new XMLDBException(ErrorCodes.NO_SUCH_COLLECTION, parentColName + " : " 
					 + ErrorMessages.NO_SUCH_COLLECTION); 
	    

	    colMgr = 
		(CollectionManager) parentCol.collection.getService("CollectionManager", Command.XMLDBAPIVERSION);
	    
	    newCol =  new xiSixdmlCollection(colMgr.createCollection(newColName));
	}
	
	return newCol; 

    }/* createCollection(String) */



     /**
     * Creates a collection that is constrained by a particular schema. 
     * @param name The name of the collection to create. 
     * @param schemaFile the location of the schema file either on the local file 
     * system or over the internet. 
     * @exception XMLDBException if the collection already exists or  
     * one of the collections in the path given does not exist. 
     * @see ErrorCodes#NO_SUCH_COLLECTION
     * @see ErrorMessages#DUPLICATE_COLLECTION
     * @exception IOException if an error occurs while trying to retrieve the file.
     * @exception InvalidSchemaException if the schema is invalid.      
     */ 
    public Collection createCollection(String name, URL schemaFile) 
	throws XMLDBException, IOException, InvalidSchemaException{
	
	SixdmlCollection newCol = (SixdmlCollection) this.createCollection(name); 

	try{
	    newCol.setSchema(schemaFile); 
	}catch(InvalidCollectionDocumentException icde){ icde.printStackTrace(); } /* Can't happen */
	
	return (Collection) newCol; 

    }/* createCollection(String, URL) */


    /**
     * Removes a collection from the database. 
     * @param name The name of the collection to delete.     
     * @exception XMLDBException if the path is invalid. 
     * @see ErrorCodes#NO_SUCH_COLLECTION
     */
    public void removeCollection(String name) throws XMLDBException{

	int fileNameIdx           = name.lastIndexOf("/"); 
	CollectionManager colMgr  = null; 
	xiSixdmlCollection newCol = null; 

	if(fileNameIdx == -1){

	    System.out.println("Deleting collection " + name);
	    System.out.flush(); 
	    
	    colMgr = 
		(CollectionManager) this.collection.collection.getService("CollectionManager", Command.XMLDBAPIVERSION);
	    colMgr.dropCollection(name);
	
	}else{
	
	String parentColName       = name.substring(0, fileNameIdx); 
	String newColName          = name.substring(fileNameIdx + 1); 
	
	System.out.println("Deleting collection /db/" + parentColName + "/" + newColName);
	xiSixdmlCollection parentCol = 
	    (xiSixdmlCollection) xiSixdmlDatabase.getDB().getCollection("/db/" + parentColName, "", ""); 
	    
	    colMgr = 
		(CollectionManager) parentCol.collection.getService("CollectionManager", Command.XMLDBAPIVERSION);
	    
	    colMgr.dropCollection(newColName);
	}
		
    }/* removeCollection(String) */


    /**
     * Gets the name of the service. 
     * @return the name of the service. 
     */
    public String getName(){

	return "SixdmlCollectionManagementService"; 
    }

    
   /*=================================================================*/
    /*                 S T A T I C        M E T H O D S                */
    /*=================================================================*/

    /**
     * Main used for testing class. 
     * @param args IGNORED
     */
    public static void main(String[] args) throws Exception{

	/* test retrieving collections */
	
	String driver = "org.sixdml.xindice.xiSixdmlDatabase";
	Class c = Class.forName(driver);
	
	SixdmlDatabase database = (SixdmlDatabase) c.newInstance();
	SixdmlTransactionService transaction = 
	    (SixdmlTransactionService) database.getService("SixdmlTransactionService", "1.0"); 

	transaction.begin(); 
	DatabaseManager.registerDatabase(database);

	SixdmlCollectionManagementService colManager = 
	    (SixdmlCollectionManagementService) database.getService("SixdmlCollectionManagementService", "1.0"); 
		
	SixdmlCollection col = (SixdmlCollection) colManager.createCollection("test_collection2"); 
	SixdmlCollection col2 = (SixdmlCollection) colManager.createCollection("test_collection2/subdirectory2");

	 col.setSchema(new URL("http://www.25hoursaday.com/books.xsd"));

	System.out.println(col.getName()+ "created with the following XML schema:\n\n"
			   + col.showSchema());
	
	colManager.removeCollection("test_collection2");

	
	transaction.commit(); 
    }

} // xiSixdmlCollectionManagementService
