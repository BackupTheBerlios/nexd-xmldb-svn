package org.sixdml.xindice;
import org.sixdml.dbmanagement.*;
import org.sixdml.SixdmlConstants;
import org.sixdml.exceptions.*;
import org.xmldb.api.base.*;
import org.w3c.dom.*;
import org.xml.sax.*; 
import java.net.URL;
import java.net.MalformedURLException;
import java.io.*;
import java.util.HashMap;
import org.xmldb.api.modules.XMLResource;
import java.util.Hashtable; 

import org.apache.xerces.parsers.DOMParser;
import org.apache.xindice.client.xmldb.resources.XMLResourceImpl; 


/**
 * <PRE>
 * xiSixdmlCollection.java
 *
 * An implementation of the <code>SixdmlCollection</code> interface which maps to a collection in
 * Xindice. This class is <b>NOT</b> thread safe.
 * </PRE>
 * @version 1.0
 */

public class xiSixdmlCollection implements SixdmlCollection, SixdmlConstants {


   

    /**
     * The name of this Collection's index file. The index file is an XML 
     * document that creates mappings between names given to indexes and the actual 
     * index objects in eXcelon's DXE. An index file is needed because eXcelon DXE 
     * does not support naming indexes. 
     */
    private String indexFile = null;

    /**
     * The name of this Collection's schema file. 
     */
    private String schemaName = null;   
 
    /**
     * This is the table of properties for the needed by the <code>Configurable</code> interface.
     * @see org.xmldb.api.base.Configurable
     */
    private HashMap properties = new HashMap(); 
    
    /**
     * Flag indicates whether the collection is open or not.
     */
    private boolean open = true; 

    /**
     * The underlying Xindice collection that this class uses to interact with the database. 
     */
    Collection collection;

    /**
     * Default constructor private because an instance of this class must always 
     * be instantiated with an underlying Xindice collection.
     */
    private xiSixdmlCollection() {;}

    /**
     * Initializes this Collection by mapping it to a Xindice collection. 
     * @param col the collection that will be this object's interface to the database.
     * @exception XMLDBException if a call to the getName() function of the Collection passed in 
     * fails. 
     * @see Collection#getName()
     */
    xiSixdmlCollection(Collection collection) throws XMLDBException{

	this.collection = collection; 

	/* name our "system files" for the collection's schema and index information */
	String name = collection.getName(); 
	this.schemaName = name + ".6dml" ; 
	this.indexFile  = name + ".indx"; 

    }
    

    /**
     * Adds an index to apply to the collection.
     * @param index the index to add
     * @exception UnsupportedIndexTypeException if the index is of a type unsupported
     * by the database.
     * @exception IndexAlreadyExistsException if an index with the same name already exists
     * for the collection.
     * @exception XMLDBException if a database error occurs.
     */
    public void addIndex(SixdmlIndex index)
	throws
	    UnsupportedIndexTypeException,
	    IndexAlreadyExistsException,
	    XMLDBException {
	

	SixdmlIndexType indexType = index.getType(); 
	
	if(indexType != SixdmlIndexType.VALUE_INDEX)
	    throw new UnsupportedIndexTypeException();

	/* get index file (create it if it doesn't exist) and grab the root node */ 
	XMLResource indexDoc = (XMLResource) this.collection.getResource(this.indexFile); 
	Document indexDOM = null;
	Element rootElem = null; 


	if(indexDoc == null){ // no index file exists 

	    try{
		 
		DOMParser parser = new DOMParser();
		String xmlStr = "<sixdml:indices xmlns:sixdml=\"" 
		    + SIXDML_NS + "\">\n</sixdml:indices>\n";

		 parser.parse(new InputSource(new StringReader(xmlStr)));
		 
		//grab empty index file as DOM node
		indexDOM  = parser.getDocument(); 
		rootElem  = indexDOM.getDocumentElement(); 
		indexDoc  = new XMLResourceImpl(this.indexFile, this.collection);
		  

	    } catch (SAXException saxe) {
		throw new XMLDBException(ErrorCodes.UNKNOWN_ERROR, saxe.getMessage()); 
	    }catch(IOException ioe){
		//ioe.printStackTrace(); 
		throw new XMLDBException(ErrorCodes.UNKNOWN_ERROR, ioe.getMessage()); 
	    }

	}else{ // we already have an index file 

	    indexDOM  = (Document)indexDoc.getContentAsDOM(); 
	    rootElem  = indexDOM.getDocumentElement(); 
	}

	/* search for index name in file and complain if we see it */ 
	NodeList nodelist = indexDOM.getElementsByTagNameNS( SIXDML_NS, "name");
	Node curr = null; 
	
	
	for(int i = 0, length = nodelist.getLength(); i < length; i++){

	    curr      = nodelist.item(i);
	    
	    /* Yet more proof that the DOM is dumb API */ 	    
	    if( curr.getFirstChild().getNodeValue().equals(index.getName())) //BUG: Potential NPE
		throw new IndexAlreadyExistsException(); 
	}

	/* add node for new index */
	Node newIndexNode       =  
	    indexDOM.importNode(((xiSixdmlIndex)index).getXMLAsNode(), true); 
	rootElem.appendChild(newIndexNode); 


	/* update all documents in collection with new index information */
	Hashtable idxTable = new Hashtable(index.getIndexFields()); 
	idxTable.put("nameOf", index.getName()); 
	idxTable.put("collection", this.getName()); 
	idxTable.put("verbose", "false");


	try{
	    new org.apache.xindice.tools.command.AddIndexer().execute(idxTable); 	

	}catch(Exception e){
		e.printStackTrace(); 
		throw new XMLDBException(ErrorCodes.UNKNOWN_ERROR, e.getMessage()); 
	}

	/* store index file */
	indexDoc.setContentAsDOM(indexDOM);
	collection.storeResource(indexDoc); 

    }
    

    /**
     * Releases all resources consumed by the Collection. The close method must always be called 
     * when use of a Collection is complete. It is not safe to use a Collection after the close 
     * method has been called.    <BR>
     * <B>NOTE:</B> This may close ALL connections to the database and thus must be used only when 
     * all database interaction is completed. 
     */
    public void close() throws XMLDBException {
	collection.close();
    }
    

    /**
     * Creates a new unique ID within the context of the Collection.
     * @return the created id as a string.
     */
    public String createId() throws XMLDBException {
	return collection.createId();
    }


    /**
     * Creates a new empty Resource with the provided id.
     * @param id  the unique id to associate with the created Resource.
     * @param type the Resource type to create.
     * @exception XMLDBException if the close method has been called on the Collection or the resource
     * type is unknown. 
     * @see ErrorMessages#COLLECTION_CLOSED
     * @see ErrorMessages#UNKNOWN_RESOURCE_TYPE
     */
    public Resource createResource(String id, String type) throws XMLDBException {
				
	return new xiSixdmlResource((XMLResource)collection.createResource(id, type));
    }

    /**
     * Returns a Collection instance for the requested child collection if it exists.
     * @param name the name of the child collection to retrieve.
     * @return the requested child collection or null if it couldn't be found.
     * @exception XMLDBException if the close method has been called on the Collection
     * @see ErrorMessages#COLLECTION_CLOSED
     */
    public Collection getChildCollection(String name)throws XMLDBException {
	return new xiSixdmlCollection(collection.getChildCollection(name));
    }


    /**
     * Returns the number of child collections under this Collection or 0 if no child 
     * collections exist. 
     * @return the number of child collections
     * @exception XMLDBException if the close method has been called on the Collection
     * @see ErrorMessages#COLLECTION_CLOSED
     */
    public int getChildCollectionCount() throws XMLDBException {
	return collection.getChildCollectionCount();
    }

    /**
     * Returns an array of SixdmlIndex objects that apply to this collection. If no indexes
     * exist in the collection then an empty array is returned.
     * @return an array of SixdmlIndex objects.
     * @exception XMLDBException if a database error occurs.
     */
    public SixdmlIndex[] getIndices() throws XMLDBException {
	
	XMLResource indexDoc = (XMLResource) this.collection.getResource(this.indexFile); 

	//no index file, return 0 length array
	if(indexDoc == null)
	     return new SixdmlIndex[]{}; 

	Document indexDOM = (Document)indexDoc.getContentAsDOM(); 
	NodeList nodelist = indexDOM.getElementsByTagNameNS( SIXDML_NS, "index");
	Node indexNode = null; 
	Attr curr = null; 
	SixdmlIndex[] returnArray = new SixdmlIndex[nodelist.getLength()];

	for(int i = 0, length = nodelist.getLength(); i < length; i++)
	    returnArray[i] = xiSixdmlIndex.createIndex((Element)nodelist.item(i)); 

	return returnArray; 
	
    }

    /**
     * Returns the name associated with the Collection instance.
     * @return the name of the object.
     */
    public String getName() throws org.xmldb.api.base.XMLDBException {
	return collection.getName(); 
    }

    
    /**
     * Returns the parent collection for this collection or null if no parent collection exists.
     * @return the parent Collection instance.
     * @exception XMLDBException if the close method has been called on the Collection
     * @see ErrorMessages#COLLECTION_CLOSED
     */ 
    public org.xmldb.api.base.Collection getParentCollection() throws XMLDBException {
	return new xiSixdmlCollection(collection.getParentCollection());
    }
    
    
    /**
     * Returns the value of the property identified by name. 
     * @return the value of the property or null if there is no matching value 
     * for the key in hash table.
     */
    public String getProperty(String str) throws XMLDBException {
	return collection.getProperty(str);
    }

    /**
     * Retrieves a Resource from the database. If the Resource could not be located a null 
     * value will be returned.
     * @param id the unique id for the requested resource.
     * @return The retrieved Resource instance.
     * @exception XMLDBException if the close method has been called on the Collection or the 
     * user attempts to access the collection's schema. 
     * @see ErrorMessages#COLLECTION_CLOSED 
     * @see ErrorMessages#PERMISSION_DENIED_SCHEMA 
     * @see ErrorMessages#PERMISSION_DENIED_INDEX 
     */ 
    public Resource getResource(String id)throws XMLDBException {
	    
	if(id.equals(this.schemaName)){
	    throw new XMLDBException(ErrorCodes.PERMISSION_DENIED, 
				     ErrorMessages.PERMISSION_DENIED_SCHEMA); 
	}
	
	if(id.equals(this.indexFile)){
	    throw new XMLDBException(ErrorCodes.PERMISSION_DENIED, 
				     ErrorMessages.PERMISSION_DENIED_INDEX); 
	}


	return new xiSixdmlResource((XMLResource)collection.getResource(id));
    }

    /**
     * Returns the number of XML resources in this Collection or 0 if no child 
     * collections exist. 
     * @return the number of resources
     * @exception XMLDBException if the close method has been called on the Collection
     * @see ErrorMessages#COLLECTION_CLOSED
     */
    public int getResourceCount() throws XMLDBException {
	return collection.getResourceCount();
    }


    
    
    /**
     * Returns a Service instance for the requested service name and version. If no 
     * Service exists for those parameters a null value is returned. The only valid 
     * name and version number for this implementation are "XSLT" and "1.0" respectively.
     * @param name the name of theservice to return. 
     * @param version the version number of the service to return. 
     */
    public Service getService(String name, String version) 
	throws XMLDBException {
	return xiSixdmlDatabase.getDB().getService(name,version, this);
    }


    /**
     * Provides a list of all services known to the collection. If no services are known an 
     * empty list is returned.
     * @return An array of registered Service implementations.
     */
    public Service[] getServices()
	throws org.xmldb.api.base.XMLDBException {
	return xiSixdmlDatabase.getDB().getServices(this);
    }

    /**
     * Adds an XML document created from the string argument to the collection.
     * @param name the name of the document.
     * @param xmlString the string representation of a well-formed XML document
     * @exception DocumentAlreadyExistsException if there already exists a document with
     * the specified name in the database.
     * @exception InvalidCollectionDocumentException if the document fails to validate against
     * the collection's schema.
     * @exception NonWellFormedXMLException if the XML is not well formed.
     * @exception XMLDBException if a database error occurs.
     */
    public void insertDocument(String name, String xmlString)
	throws
	    DocumentAlreadyExistsException,
	    InvalidCollectionDocumentException,
	    NonWellFormedXMLException,
	    XMLDBException {

	Document doc = null; 
	DOMParser parser = new DOMParser();	

	/* put XML in a transient doc  */
	try{		 		
	    parser.parse(new InputSource(new StringReader(xmlString)));
	    
	} catch (SAXException saxe) {
	    throw new NonWellFormedXMLException(saxe.getMessage()); 
	}catch(IOException ioe){
	    //ioe.printStackTrace(); 
	    throw new XMLDBException(ErrorCodes.UNKNOWN_ERROR, ioe.getMessage()); 
	}
	
	doc = parser.getDocument(); 

	if(collection.getResource(name) != null)
	    throw new DocumentAlreadyExistsException(); 
	
	Resource res =  new XMLResourceImpl(name, this.collection, xmlString); 
	this.storeResource(res); 
    }

    /**
     * Adds an XML document loaded from the specified URL to the collection.
     * @param name the name of the document.
     * @param xmlString the string representation of a well-formed XML document
     * @exception DocumentAlreadyExistsException if there already exists a document with
     * the specified name in the database.
     * @exception IOException if an error occurs while trying to retrieve the file.
     * @exception InvalidCollectionDocumentException if the document fails to validate against
     * the collection's schema.
     * @exception NonWellFormedXMLException if the XML is not well formed.
     * @exception XMLDBException if a database error occurs.
     */
    public void insertDocument(String   name, URL documentSource)
	throws
	    DocumentAlreadyExistsException,
	    IOException,
	    InvalidCollectionDocumentException,
	    NonWellFormedXMLException,
	    XMLDBException {

	//get URL contents as string 
	String xmlStr = getContentsOfURL(documentSource); 	
		
	this.insertDocument(name, xmlStr);
    }

    /**
     * Returns true if the Collection is open false otherwise. Calling the close method on Collection 
     * will result in isOpen returning false. It is not safe to use Collection instances that have 
     * been closed.
     * @return true if the Collection is open, false otherwise.
     */
    public boolean isOpen() throws XMLDBException {
	return collection.isOpen();	
    }


    /**
     * Returns a list of collection names naming all child collections of the current collection. 
     * If no child collections exist an empty list is returned.
     * @return an array containing collection names for all child collections.
     * @exception XMLDBException if the close method has been called on the Collection
     */
    public String[] listChildCollections()throws XMLDBException {
	return collection.listChildCollections();
    }


    /**
     * Returns a list of resource names naming all the resources in the current collection. 
     * @return an array containing collection names for all child collections.
     * @exception XMLDBException if the close method has been called on the Collection
     */
    public String[] listResources() throws org.xmldb.api.base.XMLDBException {

	String[] resources; 

	try{
	    resources = collection.listResources();
	}catch(XMLDBException xmldbe){

	     /* Handle fact that collections with no documents throw exceptions */
	    if(xmldbe.vendorErrorCode == org.apache.xindice.core.FaultCodes.COL_NO_INDEXMANAGER)
		return new String[]{};
	    else 
		throw xmldbe; 
	}
	    

	/* very inefficient because we want to hide index and schema file if any */
	int numSystemFiles = 0; 
	
	for(int i=0; i < resources.length; i++){
	    if(resources[i].equals(schemaName) || resources[i].equals(schemaName))
		numSystemFiles++; 
	}

	if(numSystemFiles ==0)
	    return resources; 

	System.out.println("NUM SYSTEM FILES: " + numSystemFiles);
	

	String[] toReturn = new String[resources.length - numSystemFiles]; 


	for(int i=0, j =0; i < resources.length; i++){
	    if( resources[i].equals(schemaName) || resources[i].equals(schemaName) )
		continue; 
	    else
		toReturn[j++] = resources[i]; 
	}

	return toReturn; 

    }/* listResources() */

    /**
     * Removes an XML document from   the collection.
     * @param name the name of the document.
     * @exception NonExistentDocumentException if the document does not exist
     * in the collection.
     * @exception XMLDBException if a database error occurs.
     */
    public void removeDocument(String name)
	throws NonExistentDocumentException, XMLDBException {

	if(name.equals(this.schemaName)){
	    throw new XMLDBException(ErrorCodes.PERMISSION_DENIED, 
				     ErrorMessages.PERMISSION_DENIED_SCHEMA); 
	}
	
	if(name.equals(this.indexFile)){
	    throw new XMLDBException(ErrorCodes.PERMISSION_DENIED, 
				     ErrorMessages.PERMISSION_DENIED_INDEX); 
	}
	    
	Resource res = collection.getResource(name); 

	if(res == null)
	    throw new NonExistentDocumentException();
	    
	collection.removeResource(res);	    
    }

    /**
     * Removes a particular index from the collection.
     * @param index the index to add
     * @exception XMLDBException if a database error occurs.
     */
    public void removeIndex(String name)
	throws NonExistentIndexException, XMLDBException {
	
	/* get index file  */ 
	XMLResource indexDoc = (XMLResource) this.collection.getResource(this.indexFile); 

	if(indexDoc == null)
	    throw new NonExistentIndexException(name); 

	Document indexDOM =   (Document)indexDoc.getContentAsDOM();  
	Element rootElem  =   indexDOM.getDocumentElement(); 


	/* search for index name in file and delete it */ 
	NodeList nodelist = indexDOM.getElementsByTagNameNS( SIXDML_NS, "name");
	Node curr = null; 
	Node indexNode = null; 
	boolean indexFound = false; 
	
	for(int i = 0, length = nodelist.getLength(); i < length; i++){

	    curr      = nodelist.item(i);
	    indexNode = curr.getParentNode();
	    
	    /* Yet more proof that the DOM is dumb API */
	    if( curr.getFirstChild().getNodeValue().equals(name))
		indexFound = true; 
	}

	if(!indexFound)
	    throw new NonExistentIndexException(name); 
       
	/* remove index from document */
	rootElem.removeChild(indexNode); 

	Hashtable idxTable = new Hashtable(); 
	idxTable.put("collection", this.getName()); 
	idxTable.put("nameOf", name); 
	idxTable.put("force", "yes"); 
	idxTable.put("verbose", "false"); 

	try{
	new org.apache.xindice.tools.command.DeleteIndexer().execute(idxTable); 
	
	}catch(Exception e){
		e.printStackTrace(); 
		throw new XMLDBException(ErrorCodes.UNKNOWN_ERROR, e.getMessage()); 
	}

    }


    /**
     * Removes the Resource from the database.
     * @param res the resource to remove.
     * @exception XMLDBException if the close method has been called on the Collection
     * @see ErrorMessages#COLLECTION_CLOSED  
     * @see ErrorMessages#NO_SUCH_RESOURCE 
     * @see ErrorMessages#PERMISSION_DENIED_SCHEMA
     * @see ErrorMessages#PERMISSION_DENIED_INDEX
     */
    public void removeResource(Resource res) throws XMLDBException {
	
	try{
	    this.removeDocument(res.getId()); 	    
	}catch(NonExistentDocumentException nede){
	    throw new XMLDBException(ErrorCodes.NO_SUCH_RESOURCE, ErrorMessages.NO_SUCH_RESOURCE); 
	} 
    }


    /**
     * Sets the property name to have the value provided in value. 
     * @param name the name of the property to set.
     * @param value the value to set for the property.
     */
    public void setProperty(String name, String value)throws XMLDBException {
	collection.setProperty(name, value);
    }

    /**
     * Sets the XML schema or DTD that will be used to constrain the documents in
     * this collection. For this operation to succeed, all documents in the collection
     * <b>must</b> pass schema validation. If a schema already exists for the collection
     * then it is replaced by the new one if all documents pass validation.
     * @param schemaFile the location of the schema file either on the local file
     * system or over the internet.
     * @exception InvalidCollectionDocumentException if an XML document in the
     * collection fails to be validated by the schema.
     * @exception IOException if an error occurs while trying to retrieve the file.
     * @exception InvalidSchemaException if the schema is invalid.
     * @exception XMLDBException if a database error occurs.
     */
    public void setSchema(URL schemaFile) throws InvalidCollectionDocumentException,
						 IOException,InvalidSchemaException,
						 XMLDBException {

	Document schemaDoc; 
	DOMParser parser = new DOMParser();

	/* first try to validate the schema */
	try{
	    //turn on validation then parse schema 		
	    initializeParser(parser, null, null); 
	    parser.parse(schemaFile.toString());

	    /* VALIDATION SUCCESSFUL */

	    //set target namespace for subsequent parses
	    String targetNS = parser.getDocument().getDocumentElement().getAttribute("targetNamespace"); 
	    initializeParser(parser, targetNS, schemaFile.toString()); 

	}catch(Exception e){
	    System.out.println(e);
	    throw new InvalidSchemaException(schemaFile.toString(), e);
	}	
	    
	/* iterate through contents of collection and validate each one */
	String[] resources = collection.listResources();
	String tempfile = System.currentTimeMillis() + ".xml"; 
	String fileId = ""; 
	File file = null; 

	//HACK: Write each doc to a temp file then validate. Must be a better way to do this. 
	try{

	    for(int i = resources.length ; i-->0 ;){
		    
		fileId = resources[i];

		//don't validate index or schema "hidden" files. That would be dumb.
		if((fileId.equals(schemaName)) ||  (fileId.equals(indexFile)) )
		    continue; 
		    
		Resource res = collection.getResource(fileId); 
		file = writeToFile(tempfile, (String)res.getContent(), false);  
		parser.parse(tempfile);						
	    }

	}catch(IOException ioe){   // from creating temp file 
	    throw ioe; 
	}catch(Exception e){ //from validation
	    throw new InvalidCollectionDocumentException(fileId, e); 
	}finally{
	    if(file != null)
		file.delete(); 
	}

	/* add schema to DB. Ideally this should be a database transaction. */ 
	XMLResource newSchema = (XMLResource) collection.createResource(schemaName, "XMLResource"); 
	newSchema.setContent(getContentsOfURL(schemaFile)); 	
	collection.storeResource(newSchema); 
    }

    /**
     * Returns the contents of the schema for the collection as a string.
     * @return the schema for the collection or null if none exists.
     * @exception XMLDBException if a database error occurs.
     */
    public String showSchema() throws XMLDBException {

	XMLResource schema = (XMLResource) collection.getResource(this.schemaName); 

	if(schema != null){
	    return (String) schema.getContent(); 
	}
	    
	return null; 
    }



    /**
     * Stores the provided resource into the database. If the resource does not already 
     * exist it will be created. If it does already exist it will be updated.
     * @param res the resource to store in the database.
     * @exception XMLDBException if the close method has been called on the Collection or the 
     * document does validate against the collection's schema if any. 
     * @see ErrorMessages#COLLECTION_CLOSED  
     * @see ErrorMessages#WRONG_CONTENT_TYPE_STORE
     * @see ErrorMessages#PERMISSION_DENIED_SCHEMA
     * @see ErrorMessages#PERMISSION_DENIED_INDEX
     */
    public void storeResource(Resource resource) throws XMLDBException {

	String id = resource.getId(); 

	if(id.equals(this.schemaName)){
	    throw new XMLDBException(ErrorCodes.PERMISSION_DENIED, 
				     ErrorMessages.PERMISSION_DENIED_SCHEMA); 
	}
	
	if(id.equals(this.indexFile)){
	    throw new XMLDBException(ErrorCodes.PERMISSION_DENIED, 
				     ErrorMessages.PERMISSION_DENIED_INDEX); 
	}

	try{
	    this.validate((String)resource.getContent());	
	}catch(Exception e){ 		
	    e.printStackTrace(); 
	    throw new XMLDBException(ErrorCodes.VENDOR_ERROR, ErrorMessages.VALIDATION_ERROR  + e);
	}

	collection.storeResource(resource);
    }

    /**
     * Unsets the schema for this collection. Does nothing if no schema exists for the
     * collection.
     * @exception XMLDBException if a database error occurs.
     */
    public void unsetSchema() throws XMLDBException {
		
	XMLResource schema = (XMLResource) collection.getResource(this.schemaName); 

	if(schema != null)
	    collection.removeResource(schema); 	    	    	    
    }


    /**
     * Helper Method: Validates an XML document against the collection's schema. Does 
     * nothing if there is no schema for the collection. 
     * @param xmlStr the document to validate as a string. 
     * @exception Exception if anything goes wrong. 
     */
    private void validate(String xmlStr) throws Exception{
	
	Resource res = (Resource) collection.getResource(this.schemaName); 

	if(res == null)
	    return;

	SixdmlResource schema = new xiSixdmlResource((XMLResource)res); 	
	File schemaFile = null, instanceFile = null; 

	try{
	    String schemaFileName = System.currentTimeMillis() + "-schema.xsd";
	    schemaFile = writeToFile(schemaFileName, (String) schema.getContent(), false); 
	    
	    String instanceFileName = System.currentTimeMillis() + "-doc-instance.xml";
	    instanceFile = writeToFile(instanceFileName, xmlStr , false); 
	    
	    //create a Xerces DOM parser
	    DOMParser parser = new DOMParser();
	    
	    //  Turn on validation and related features 
	    initializeParser(parser, null, null); 

	    //if the xsd:schema element isn't the first one in the schema then this doesn't work
	    String targetNS = 
		((Document)schema.getContentAsDOM()).getDocumentElement().getAttribute("targetNamespace"); 
	    if(targetNS == "")
		parser.setProperty("http://apache.org/xml/properties/schema/external-noNamespaceSchemaLocation", schemaFile);
	    else 
		parser.setProperty("http://apache.org/xml/properties/schema/external-schemaLocation", targetNS + " " + schemaFile);
	    
	    parser.setErrorHandler (new ValidationEventHandler());
            parser.parse(instanceFileName);
	    System.out.println("DONE VALIDATING.............");
	}finally{
	    
	    if(schemaFile != null)
		schemaFile.delete(); 		
	    
	    if(instanceFile != null)
		instanceFile.delete(); 	
	}

    }/* validate(String) */


    /**
     * Helper Method: Initializes properties related to schema validation in parser.
     * @param parser the DOM parser to initialize
     * @param targetNS the targetNamespace of the schema to use. 
     * @param schemaLocation path to the schema. Only used if targetNS isn't null. 
     */
    private static void initializeParser(DOMParser parser, String targetNS, String schemaLocation) throws SAXNotRecognizedException, SAXNotSupportedException{	

	parser.setFeature("http://xml.org/sax/features/validation",true);
	parser.setFeature("http://xml.org/sax/features/namespaces",true);
	parser.setFeature("http://apache.org/xml/features/validation/schema",true);
	parser.setFeature("http://apache.org/xml/features/validation/schema-full-checking", true);

	if(targetNS != null){
	
	    if(targetNS == "")
		parser.setProperty("http://apache.org/xml/properties/schema/external-noNamespaceSchemaLocation", schemaLocation);
	    else 
		parser.setProperty("http://apache.org/xml/properties/schema/external-schemaLocation", targetNS + " " + schemaLocation);

	}
    
    }
    
    /**
     * Helper method to create a URL from a file name. <BR>
     * <b>NOTE:</b>The code below was obtained from the modifying example programs in the Oracle 
     * XDK. I wonder if this is a violation of their EULA's? 
     * @param fileName file to convert. 
     * @return the URL version of the filename. 
     */
    private static URL createURL(String fileName) throws MalformedURLException{

	URL url = null;
	
	try{	    
	    url = new URL(fileName);

	}catch (MalformedURLException ex){
	    
	    File f = new File(fileName);
		
	    try{
		    
		/* file seperator code convoluted due to supporting Windows behavior */
		String path = f.getAbsolutePath();		    
		String file_seperator = System.getProperty("file.separator");

		if (file_seperator.length() == 1){
			
		    char sep = file_seperator.charAt(0);

		    if (sep != '/')
			path = path.replace(sep, '/');

		    if (path.charAt(0) != '/')
			path = '/' + path;
		}

		path = "file://" + path;
		url = new URL(path);

	    }catch (MalformedURLException e){

		throw new MalformedURLException("Cannot create URL from '" + fileName + "'");            
	    }
	}

	return url;

    }/* createURL(String) */

     /**
      * Helper Method: Writes the contents of a string to a file. 
      * @param file the file to write to. 
      * @param contents the string to write to the file. 
      * @param append boolean if true, then data will be written to the 
      * end of the file rather than the beginning. 
      * @return the File object that represents the file just modified.
      * @exception IOException if an error occurs in writing the file. 
      */
    private static File writeToFile(String file, String contents, boolean append) throws IOException{

	FileWriter fw = new FileWriter(file, append);		
	BufferedWriter bw = new BufferedWriter(fw);              
	bw.write(contents);
	bw.close();		

	File fileObj = new File(file); 
	return fileObj; 
    
    }/*  writeToFile(String, String, boolean) */


     /**
      * Helper Method: Obtains the contents at a particular URL and returns them as a string. 
      * @param source the URL to obtaion the data from. 
      * @return the contents at the specified URL. 
      * @exception IOException if an error occurs while trying to retrieve the file.
      */
    public static String getContentsOfURL(URL source) throws IOException{

	BufferedReader reader = new BufferedReader(new InputStreamReader(source.openStream()));
	StringBuffer dest = new StringBuffer(""); 
	String s=null;  	
	
	while((s = reader.readLine()) != null){  dest.append(s); }

	return dest.toString();

    }/* getContentsOfURL(URL) */

       

    /**
     * Main used for testing class. 
     * @param args IGNORED
     */
    public static void main(String[] args) throws Exception{

	
	String driver = "org.sixdml.xindice.xiSixdmlDatabase";
	Class c = Class.forName(driver);
	org.sixdml.SixdmlDatabase database = (org.sixdml.SixdmlDatabase) c.newInstance(); 
	org.xmldb.api.DatabaseManager.registerDatabase(database); 

	SixdmlCollection col = (SixdmlCollection) database.getCollection("/db/addressbook", "", ""); 

	System.out.println(col.getName());

	System.out.println("Setting schema...");
	col.setSchema(new URL("http://www.25hoursaday.com/books.xsd")); 
	System.out.println(col.showSchema());

	SixdmlResource resource = (SixdmlResource) col.createResource("books", "XMLResource");
	resource.setContent(getContentsOfURL(new URL("http://www.25hoursaday.com/books.xml")));
	System.out.println(resource.getName());	

	col.storeResource(resource); 
	resource = (SixdmlResource) col.getResource("books");
	System.out.println(resource.getContent());
	System.out.println("Validation of 'books' Succeeded As Expected");              	

	try{
	    SixdmlResource resource2 = (SixdmlResource) col.createResource("title", "XMLResource");
	    resource2.setContent(getContentsOfURL(new URL("http://www.25hoursaday.com/title.xsl")));
	    System.out.println(resource2.getName());
	    System.out.println(resource2.getContent());

	    col.storeResource(resource2); 

	}catch(Exception e){	   
	    e.printStackTrace(); 
	    System.out.println("Validation of 'title' Failed As Expected");
	}

    }

} // xiSixdmlCollection


class ValidationEventHandler implements ErrorHandler {
    
    // Constructor
    public ValidationEventHandler () {;}
    //  Warning Event Handler

    public void warning (SAXParseException e)
        throws SAXException {
        System.err.println ("Schema Validation Warning:  "+e);
    }

    //  Error Event Handler
    public void error (SAXParseException e)
        throws SAXException {	
	throw e;
    }
    
    //  Fatal Error Event Handler
    public void fatalError (SAXParseException e)
        throws SAXException {
	throw e;
    }
      
}

