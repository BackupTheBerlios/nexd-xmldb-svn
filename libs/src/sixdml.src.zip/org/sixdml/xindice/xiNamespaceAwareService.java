package org.sixdml.xindice;
//import java.net.URI; 
import org.xmldb.api.base.ErrorCodes;
import org.sixdml.SixdmlNamespaceMap;
import org.xmldb.api.base.XMLDBException;
import org.w3c.dom.*;
import javax.xml.parsers.*; 
import java.util.Iterator; 

/**
 * <PRE>  
 * xiNamespaceAwareService.java
 *
 * This is the base class for services that perform XPath queries and need to 
 * manage relationships between prefixes and namespace URI in these queries. 
 * </PRE>
 * @version 1.0 
 */

abstract class xiNamespaceAwareService extends xiServiceBase {
    
    /*=================================================================*/
    /*                I N S T A N C E    V A R I A B L E S             */
    /*=================================================================*/
       

    /**
     * This is the table of prefix to namespace mapping used when performing XPath queries 
     * against the database. 
     */
    private SixdmlNamespaceMap namespaceMap = new SixdmlNamespaceMap(); 

    
    /*=================================================================*/
    /*                I N S T A N C E       M E T H O D S              */
    /*=================================================================*/   

    
    /**
     * Set the SixdmlNamespaceMap used by this class to map prefixes to namespace URIs used 
     * in XPath queries. . 
     * @param nsMap the new namespace map to use.      
     */
    public void setNamespaceMap(SixdmlNamespaceMap nsMap) throws XMLDBException{
	namespaceMap = nsMap; 
    } 

    /**
     * Add a mapping between a given prefix and a namespace to the service's internal namespace 
     * map.  
     * @param prefix key with which the specified namespace URI is associated.
     * @param namespaceURI value to be associated with the specified prefix.           
     */
    /* public void addNamespaceMapping(String prefix, URI namespaceURI) throws XMLDBException{ */
    public void addNamespaceMapping(String prefix, String namespaceURI) throws XMLDBException{
	namespaceMap.put(prefix, namespaceURI); 
    } 
  
    /**
     * Remove a mapping between a given prefix and a namespace to the service's internal namespace 
     * map. . 
     * @param prefix key with which the specified namespace URI is associated.              
     */
    public void removeNamespaceMapping(String prefix) throws XMLDBException{
	namespaceMap.remove(prefix); 
    }  

    /**
     * Clear all namespace mappings in the service's internal namespace map.      
     */
    public void clearNamespaceMappings() throws XMLDBException{
	namespaceMap.clear(); 
    } 

    /**
     * Obtain the namespace URI mapped to a particular . 
     * @param prefix the prefix whose namespace is being sought. 
     * @return the namespace URI mapped to the prefix or null if the map contains 
     * no mapping for this prefix.     
     */
    /*   public URI getNamespaceMapping(String prefix) throws XMLDBException{ */
    public String getNamespaceMapping(String prefix) throws XMLDBException{
	return namespaceMap.get(prefix); 
    }  
  
    
    /**
     * Creates an DOM element node containing all the prefix<->namespace bindings in this object's 
     * namespace map. 
     * @return a DOM node containing this objects prefix<->namespace mapping as xmlns declarations. 
     * @exception ParserConfigurationException if an error occurs in utilizing the XML DOM. 
     */
    protected Node getNamespaceNode() throws ParserConfigurationException{
	
	 DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	 DocumentBuilder builder = factory.newDocumentBuilder();  
	 DOMImplementation impl = builder.getDOMImplementation();
	 Document namespaceHolder = impl.createDocument(SIXDML_NS, "sixdml:namespace-holder", null);
	 Element root = namespaceHolder.getDocumentElement();

	 Iterator it = namespaceMap.entrySet().iterator(); 

	 while(it.hasNext()){
	     
	     java.util.Map.Entry kvPair = (java.util.Map.Entry) it.next(); 
	     
	     if((kvPair.getKey() == null)||(kvPair.getKey().equals(""))) //this shouldn't happen but just in case...
		 root.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns" ,"" + kvPair.getValue());
	     else
		 root.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:" + kvPair.getKey(),"" + kvPair.getValue());
	 }
	 
	 return root;

    }/* getNamespaceNode() */


} // xiNamespaceAwareService
