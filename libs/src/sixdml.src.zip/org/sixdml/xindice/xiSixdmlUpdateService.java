package org.sixdml.xindice; 
import org.sixdml.update.*;
import org.xmldb.api.base.XMLDBException;
import org.sixdml.exceptions.*;
import org.w3c.dom.*; 
import java.util.HashMap;
import org.xmldb.api.base.Collection;
import org.xmldb.api.base.XMLDBException;
import org.sixdml.dbmanagement.SixdmlResource;
import org.sixdml.dbmanagement.SixdmlCollection;
import org.sixdml.SixdmlConstants;
import org.xml.sax.*;
import java.io.*;
import org.apache.xpath.*;
import org.apache.xpath.objects.*;
import org.apache.xerces.parsers.DOMParser;



/**
 * <PRE>  
 * xlnSixdmlUpdateService.java
 *
 * Used to update nodes in collections or documents via  XPath queries.
 * </PRE>  
 * @version 1.0 
 */

class xiSixdmlUpdateService extends xiNamespaceAwareService implements SixdmlUpdateService , SixdmlConstants{
        

   

    /*=================================================================*/
    /*                        C O N S T R U C T O R S                  */
    /*=================================================================*/

    /**
     * Default constructor initializes service.
     */
    xiSixdmlUpdateService() {;}

    
    /*=================================================================*/
    /*                I N S T A N C E       M E T H O D S              */
    /*=================================================================*/   


   
    /**
     * Gets the name of the service. 
     * @return the name of the service. 
     */
    public String getName(){

	return "SixdmlUpdateService"; 
    }

    /** 
     * Helper method that tests if a node is of a specific type. 
     * @param type the type of the node we are testing. 
     * @param nodetypes the array of nodes types we are interested in testing if this node is 
     * a member of. 
     * @return true if the node type is in the list of approved node types. 
     */
    private static boolean isNodeOfType(short type, short[] nodetypes){


	for(int i=0; i < nodetypes.length; i++)
	    if(type == nodetypes[i]){ 
		return true; }

	return false; 

    }/* isNodeOfType(short, short[]) */


    /**
     * Creates a DOM node list from an XML fragment. 
     * @param xmlString the XML fragment. 
     * @return the DOM nodelist. 
     * @exception NonWellFormedXMLException if the XML fragment is not a valid XML fragment. 
     */
    static  NodeList loadIntoNodeList(String xmlString) throws NonWellFormedXMLException{

	//  Create a Xerces DOM Parser
      DOMParser parser = new DOMParser();

	try{
	    parser.parse(new InputSource(new StringReader("<root>" + xmlString + "</root>")));

	} catch (SAXException saxe) {
	    throw new NonWellFormedXMLException(saxe.getMessage(), saxe); 
	} catch (IOException ioe) {
	     throw new NonWellFormedXMLException(ioe.getMessage(), ioe); 
	}

	return parser.getDocument().getDocumentElement().getChildNodes(); 

    }/* loadIntoNodeList(String) */


    /**
     * Inserts an XML fragment as a sibling of each of the nodes returned from the XPath query. 
     * A boolean flag indicates whether the new node will be inserted before or after the 
     * selected nodes.     
     * @param query The query which selects the nodes to update
     * @param fragment The XML fragment to insert
     * @param resource the document to perform the update against 
     * @param before if this is true then the new node wil be inserted before each of the selected node
     * while if it is false the new node will be inserted after the selected nodes in the tree.  
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException if the target node is the document root and an attempt is 
     * made to insert anything besides comments or processing instructions. 
     * @exception NonWellFormedXMLException if the XML fragment is not a valid XML fragment. 
     */
    public int insertSibling(String query, String fragment,SixdmlResource resource, boolean before)
	throws XMLDBException, InvalidQueryException, NonWellFormedXMLException, UpdateTypeMismatchException{ 

	return this.insertSibling(query, this.loadIntoNodeList(fragment), resource, before); 	
    
    }/* insertSibling(String, String, SixdmlResource, boolean) */ 


    /**
     * Inserts an XML fragment as a child of each of the nodes returned from the XPath query. 
     * A boolean flag indicates whether the new node will be inserted before or after the 
     * selected nodes. The new node is appended to the end of the current children of the 
     * selected node. 
     * @param query The query which selects the nodes to update
     * @param fragment The XML fragment to insert
     * @param resource the document to perform the update against 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node, document node
     * or set of element nodes. 
     * @exception NonWellFormedXMLException if the XML fragment is not a valid XML fragment. 
     */
    public int insertChild(String query, String fragment,SixdmlResource resource)
	throws XMLDBException, InvalidQueryException, NonWellFormedXMLException, UpdateTypeMismatchException{
	
	return this.insertChild(query,  this.loadIntoNodeList(fragment) , resource); 	

    }/* insertChild(String, String, SixdmlResource) */


    /**
     * Inserts a node as a sibling of each of the nodes returned from the XPath query. 
     * A boolean flag indicates whether the new node will be inserted before or after the 
     * selected nodes.     
     * @param query The query which selects the nodes to update
     * @param nodes The DOM node(s) to insert
     * @param resource the document to perform the update against 
     * @param before if this is true then the new node wil be inserted before each of the selcted node
     * while if it is false the new node will be inserted after the selected nodes in the tree.  
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException if the target node is the document root and an attempt is 
     * made to insert anything besides comments or processing instructions. 
     * @see ErrorMessages#NODES_NOT_RETURNED
     * @see ErrorMessages#BAD_UPDATE_ATTEMPT
     */
    public int insertSibling(String query, NodeList nodes, SixdmlResource resource, boolean before)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException{

	int nodeCount = 0; 

	try{
	
	    Node namespaceNode = this.getNamespaceNode(); 	    
		    
	    //get DOM node from resource and run XPath query 
	    Node target    = resource.getContentAsDOM();
	    XObject xobj   = XPathAPI.eval(target, query, namespaceNode); 
	    
	    
	    //Did the query return a nodeset? 
	    if(xobj.getType() != XObject.CLASS_NODESET)
		throw new UpdateTypeMismatchException(ErrorMessages.NODES_NOT_RETURNED); 

	    /* Need this because Nodes returned via NodeList aren't from target but from a clone */
	    Node nodeInModifiedDocument = null; 
	  	  
	    NodeList results = new org.apache.xpath.NodeSet(xobj.nodeset());
	    Node result   = null; 
	    nodeCount     = results.getLength(); 

	    //Did the query return any nodes? 
	    if(results.getLength() ==0)
		 throw new UpdateTypeMismatchException(ErrorMessages.NODES_NOT_RETURNED); 	    

	    //Make sure the insertion is valid before attempting 
	     for(int i=0, ilength = results.getLength(); i < ilength;  i++){
		 
		 result =  results.item(i);
		 Node docRoot = (Node) result.getOwnerDocument().getDocumentElement();

	      //if we found the doc root, check if only PIs or comments to insert
		if(result.equals(docRoot)){ 
		    
		    for(int j=0, jlength = nodes.getLength(); j < jlength; j++){
		      
			short[] validInsrtTypes = {Node.PROCESSING_INSTRUCTION_NODE, 
						   Node.COMMENT_NODE}; 
			
			if(isNodeOfType(nodes.item(j).getNodeType(), validInsrtTypes) == false){
			    
			    if(nodes.item(j).getNodeType() == Node.ELEMENT_NODE)
				throw new UpdateTypeMismatchException(ErrorMessages.MULTIPLE_ROOT_ELEMENTS); 
			    else 
				throw new UpdateTypeMismatchException(ErrorMessages.BAD_UPDATE_ATTEMPT); 
			    
			}//if(isNodeOfType(...)			
		    }//for(int j...)		    		    
		}//if				
	    }//while(...)
	    
	  
	  Document doc =   (Document) target;	  

	  //perform update to target node
	  for(int k=0, klength = results.getLength(); k < klength;  k++){
	      
	      Node parent  = results.item(k).getParentNode(); 
	      Node sibling = results.item(k).getNextSibling();

	      // we need to be able to refer to document element of the modified 
	      //DOM document outside this loop 
	      if(nodeInModifiedDocument == null) 
		  nodeInModifiedDocument = results.item(k); 
	      
	      for(int m=0, mlength = nodes.getLength(); m < mlength; m++){
		  
		  Node newNode = doc.importNode(nodes.item(m), true); 
		  
		  if(before)
		      parent.insertBefore(newNode,  results.item(k));
		  else
		      parent.insertBefore(newNode, sibling); //does parent.appendChild() if sibling null		  
	      }//for(int m...)
		
	  }//for(int k...)

	  
	  //update resource and save 
	  resource.setContentAsDOM(nodeInModifiedDocument.getOwnerDocument().getDocumentElement()); 
	  resource.getParentCollection().storeResource(resource); 	

	}catch(javax.xml.parsers.ParserConfigurationException pce){
	    throw new XMLDBException(org.xmldb.api.base.ErrorCodes.VENDOR_ERROR, pce.getMessage()); 
	}catch(javax.xml.transform.TransformerException te){
		
		throw new InvalidQueryException(te.getMessage(), te); 
	}

	return nodeCount; 

    }/* insertSibling(String, NodeList, SixdmlResource, boolean) */



     /**
     * Inserts a node as a child of each of the nodes returned from the XPath query. 
     * A boolean flag indicates whether the new node will be inserted before or after the 
     * selected nodes. The new node is appended to the end of the current children of the 
     * selected node. 
     * @param query The query which selects the nodes to update
     * @param nodes The DOM node(s) to insert
     * @param resource the document to perform the update against 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node, document node
     * or set of element nodes. 
     * @see ErrorMessages#NODES_NOT_RETURNED
     * @see ErrorMessages#BAD_UPDATE_ATTEMPT
     */
    public int insertChild(String query, NodeList nodes,SixdmlResource resource)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException{ 

	int nodeCount; 

	try{

	    Node namespaceNode = this.getNamespaceNode(); 	    
		    
	    //get DOM node from resource and run XPath query 
	    Node target    = resource.getContentAsDOM();
	    XObject xobj   = XPathAPI.eval(target, query, namespaceNode); 
	    
	    
	    //Did the query return a nodeset? 
	    if(xobj.getType() != XObject.CLASS_NODESET)
		throw new UpdateTypeMismatchException(ErrorMessages.NODES_NOT_RETURNED); 

	    /* Need this because Nodes returned via NodeList aren't from target but from a clone */
	    Node nodeInModifiedDocument = null; 
	  	  
	    NodeList results = new org.apache.xpath.NodeSet(xobj.nodeset());
	    Node result   = null; 
	    nodeCount     = results.getLength(); 
	  
	    //Did the query return any nodes? 
	    if(results.getLength() ==0)
		 throw new UpdateTypeMismatchException(ErrorMessages.NODES_NOT_RETURNED); 	
	  
	  //Make sure the insertion is valid before attempting :
	  //all nodes returned by query must be elements or document node
	  for(int i=0, ilength = results.getLength(); i < ilength;  i++){	      	    
	      
		  short[] validInsrtTypes = {Node.DOCUMENT_NODE, Node.ELEMENT_NODE}; 
		  
		  if(isNodeOfType(results.item(i).getNodeType(), validInsrtTypes) == false)
		      throw new UpdateTypeMismatchException(ErrorMessages.BAD_UPDATE_ATTEMPT); 	
	  }//for(int i...) 
	  
	  	  
	  Document doc = target.getOwnerDocument();

	  //perform updates to selected nodes
	  for(int k=0, klength = results.getLength(); k < klength;  k++){	      
	      for(int m=0, mlength = nodes.getLength(); m < mlength; m++){

		  // we need to be able to refer to document element of the modified 
		  //DOM document outside this loop 
		  if(nodeInModifiedDocument == null) 
		      nodeInModifiedDocument = results.item(k); 
	      
		  Node newNode = doc.importNode(nodes.item(m), true); 
		  results.item(k).appendChild(newNode); 
					      
	      }//for(int m...)	      
	  }//for(int k...)

	  //update resource and save 
	  resource.setContentAsDOM(nodeInModifiedDocument.getOwnerDocument().getDocumentElement());   
	  resource.getParentCollection().storeResource(resource); 

	}catch(javax.xml.parsers.ParserConfigurationException pce){
	    throw new XMLDBException(org.xmldb.api.base.ErrorCodes.VENDOR_ERROR, pce.getMessage()); 
	}catch(javax.xml.transform.TransformerException te){
	    
	    throw new InvalidQueryException(te.getMessage(), te); 
	}

	return nodeCount; 

    }/* insertChild(String, NodeList, resource) */ 

   


    
    /**
     * Inserts an attribute node as a child of each of the nodes returned from the XPath query.     
     * @param query The query which selects the nodes to update
     * @param resource the document to perform the update against 
     * @param name The name of the attribute to insert. 
     * @param value the value of the attribute to insert.     
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node
     * or set of element nodes. 
     * @see ErrorMessages#NODES_NOT_RETURNED
     * @see ErrorMessages#BAD_UPDATE_ATTEMPT
     */
    public int insertAttribute(String query, SixdmlResource resource, String name, String value)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException{ 

	return this.insertAttribute(query, resource, name, value, null); 
    } 

    /**
     * Inserts an attribute node as a child of each of the nodes returned from the XPath query.     
     * @param query The query which selects the nodes to update
     * @param resource the document to perform the update against 
     * @param name The name of the attribute to insert. It should be an XML qualified name. 
     * @param value the value of the attribute to insert.     
     * @param prefix the namespace prefix for the attribute node. 
     * @param namespaceURI the namsepace URI for the attribute node. If this is null then this 
     * operation is the same as inserting an attribute without a namespace. 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node
     * or set of element nodes. 
     * @see ErrorMessages#NODES_NOT_RETURNED
     * @see ErrorMessages#BAD_UPDATE_ATTEMPT
     */
    public int insertAttribute(String query, SixdmlResource resource, String name,
				String value, String namespaceURI) 
				/* 	String value, String namespaceURI) */
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException{ 

	int nodeCount; 

	try{

	     Node namespaceNode = this.getNamespaceNode(); 	    
		    
	    //get DOM node from resource and run XPath query 
	    Node target    = resource.getContentAsDOM();
	    XObject xobj   = XPathAPI.eval(target, query, namespaceNode); 
	    
	    
	    //Did the query return a nodeset? 
	    if(xobj.getType() != XObject.CLASS_NODESET)
		throw new UpdateTypeMismatchException(ErrorMessages.NODES_NOT_RETURNED); 

	    /* Need this because Nodes returned via NodeList aren't from target but from a clone */
	    Node nodeInModifiedDocument = null; 
	  	  
	    NodeList results = new org.apache.xpath.NodeSet(xobj.nodeset());
	    Node result   = null; 
	    nodeCount     = results.getLength(); 
	  
	    //Did the query return any nodes? 
	    if(results.getLength() ==0)
		 throw new UpdateTypeMismatchException(ErrorMessages.NODES_NOT_RETURNED); 	
	   
	    //all nodes returned by query must be elements
	    for(int i=0, ilength = results.getLength(); i < ilength;  i++){	      	    
		  
		short[] validInsrtTypes = { Node.ELEMENT_NODE}; 
		
		if(isNodeOfType(results.item(i).getNodeType(), validInsrtTypes) == false)
		    throw new UpdateTypeMismatchException(ErrorMessages.BAD_UPDATE_ATTEMPT); 	
	    }//for(int i...) 
	   				   

	    //perform updates to selected nodes
	    for(int j=0, jlength = results.getLength(); j < jlength;  j++){	      
		
		// we need to be able to refer to document element of the modified 
		//DOM document outside this loop 
		if(nodeInModifiedDocument == null)
		    nodeInModifiedDocument = results.item(j); 

		if(namespaceURI == null)
		    ((Element) results.item(j)).setAttribute(name, value);
		else
		     ((Element) results.item(j)).setAttributeNS(namespaceURI, name, value);
		
	    }//for(int j...)

	  //update resource and save
	  resource.setContentAsDOM(nodeInModifiedDocument.getOwnerDocument().getDocumentElement());    
	  resource.getParentCollection().storeResource(resource); 

	}catch(javax.xml.parsers.ParserConfigurationException pce){
	    throw new XMLDBException(org.xmldb.api.base.ErrorCodes.VENDOR_ERROR, pce.getMessage()); 
	}catch(javax.xml.transform.TransformerException te){
	    
	    throw new InvalidQueryException(te.getMessage(), te); 
	}

	return nodeCount; 
	
    }/* insertAttribute(String, SixdmlResource, String, String, String, String) */ 

    /**
     * Deletes all nodes that match the expression from the target document. 
     * @param query The query which selects the nodes to delete. 
     * @param resource the document to perform the update against
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid.      
     */
    public int delete(String query, SixdmlResource resource)
	throws XMLDBException, InvalidQueryException{ 

	int nodeCount; 

	try{
	    	    
	     Node namespaceNode = this.getNamespaceNode(); 	    
		    
	    //get DOM node from resource and run XPath query 
	    Node target    = resource.getContentAsDOM();
	    XObject xobj   = XPathAPI.eval(target, query, namespaceNode); 
	    
	    
	    /* Need this because Nodes returned via NodeList aren't from target but from a clone */
	    Node nodeInModifiedDocument = null; 
	  	  
	    NodeList results = new org.apache.xpath.NodeSet(xobj.nodeset());
	    Node result   = null; 
	    nodeCount     = results.getLength(); 
	  
	    //Did the query return any nodes? 
	    if(results.getLength() ==0)
		 return nodeCount; 	

	    //delete nodes
	    for(int i=0, ilength = results.getLength(); i < ilength;  i++){	      	    
		
		Node current = results.item(i); 

		// we need to be able to refer to document element of the modified 
		//DOM document outside this loop 
		if(nodeInModifiedDocument == null)
		    nodeInModifiedDocument = current; 
		
		if(current.getNodeType() == Node.ATTRIBUTE_NODE)
		    ((Attr)current).getOwnerElement().removeAttributeNode((Attr)current); 
		else
		    current.getParentNode().removeChild(current);

	    }//for(int i...) 

	    //update resource and save 
	    Document d1  = nodeInModifiedDocument.getOwnerDocument();
	    Element e1 = d1.getDocumentElement(); 
	    resource.setContentAsDOM(e1);
	    resource.getParentCollection().storeResource(resource); 

	}catch(javax.xml.parsers.ParserConfigurationException pce){
	    throw new XMLDBException(org.xmldb.api.base.ErrorCodes.VENDOR_ERROR, pce.getMessage()); 
	}catch(javax.xml.transform.TransformerException te){
	    
	    throw new InvalidQueryException(te.getMessage(), te); 
	}

	return nodeCount; 

    }/*   delete(String, SixdmlResource) */
     

     /**
     * Replaces one or more element, processing-instruction, comment, or text nodes with the new node.
     * @param query The query which selects the nodes to update
     * @param fragment the XML fragment to insert. 
     * @param resource the document to perform the update against 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not one or more comment, text, 
     * processing-instruction, or element nodes. 
     * @exception NonWellFormedXMLException if the XML fragment is not a valid XML fragment. 
     * @return the number of nodes affected by the update. 
     * @see ErrorMessages#NODES_NOT_RETURNED
     * @see ErrorMessages#BAD_UPDATE_ATTEMPT
     * @see ErrorMessages#MULTIPLE_ROOT_ELEMENTS
     * @see ErrorMessages#CANT_REPLACE_ATTRIBUTE
     */
    public int replace(String query, String fragment , SixdmlResource resource)
	throws XMLDBException, InvalidQueryException, NonWellFormedXMLException, UpdateTypeMismatchException{

	NodeList nodesToInsrt = this.loadIntoNodeList(fragment);  
	return this.replace(query, nodesToInsrt, resource); 
    } 

    /**
     * Replaces one or more element, processing-instruction, comment, or text nodes with the new node.
     * @param query The query which selects the nodes to update
     * @param nodes The DOM node(s) to insert
     * @param resource the document to perform the update against 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not one or more comment, text, 
     * processing-instruction, or element nodes.      
     * @see ErrorMessages#NODES_NOT_RETURNED
     * @see ErrorMessages#BAD_UPDATE_ATTEMPT
     * @see ErrorMessages#MULTIPLE_ROOT_ELEMENTS
     * @see ErrorMessages#CANT_REPLACE_ATTRIBUTE
     */
    public int replace(String query, NodeList nodes, SixdmlResource resource)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException{ 

	int nodeCount; 
	
	try{

	     Node namespaceNode = this.getNamespaceNode(); 	    
		    
	    //get DOM node from resource and run XPath query 
	    Node target    = resource.getContentAsDOM();
	    XObject xobj   = XPathAPI.eval(target, query, namespaceNode); 
	    
	    
	    //Did the query return a nodeset? 
	    if(xobj.getType() != XObject.CLASS_NODESET)
		throw new UpdateTypeMismatchException(ErrorMessages.NODES_NOT_RETURNED); 

	    /* Need this because Nodes returned via NodeList aren't from target but from a clone */
	    Node nodeInModifiedDocument = null; 
	  	  
	    NodeList results = new org.apache.xpath.NodeSet(xobj.nodeset());
	    Node result   = null; 
	    nodeCount     = results.getLength(); 
	    
	     if(results.getLength() ==0)
		throw new UpdateTypeMismatchException(ErrorMessages.NODES_NOT_RETURNED); 	    

	    int elemCount = 0, commentAndPICount = 0; 

	    //check to see if we are inserting only PIs and comments, if not see how many 
	    //element, PI and comment nodes we are inserting 
	    boolean onlyCommentsAndPIs = true; 

	    for(int a=0, alength = nodes.getLength(); a < alength; a++){
		      
		      short[] rootInsrtTypes = {Node.PROCESSING_INSTRUCTION_NODE, 
						 Node.COMMENT_NODE}; 
		      
		      if(isNodeOfType(nodes.item(a).getNodeType(), rootInsrtTypes) == false){
			  onlyCommentsAndPIs = false;

			  if(nodes.item(a).getNodeType() == Node.ELEMENT_NODE)
			      elemCount++; 
		      }
		      else{
			  commentAndPICount++;
		      }
	    }//for(int a...)	

	    //Make sure the insertion is valid before attempting 
	    for(int i=0, ilength = results.getLength(); i < ilength;  i++){
	      
		 Node docRoot = (Node) results.item(i).getOwnerDocument().getDocumentElement();

		//if we found the doc root, check if only PIs or comments and ONE element included 
		//in replacement 
		 if(results.item(i).equals(docRoot)){ 
		  
		  	    
		     if(onlyCommentsAndPIs == false){

		       if(elemCount > 1)
			  throw new UpdateTypeMismatchException(ErrorMessages.MULTIPLE_ROOT_ELEMENTS); 
		       else if((commentAndPICount + elemCount) < nodes.getLength())
			   throw new UpdateTypeMismatchException(ErrorMessages.BAD_UPDATE_ATTEMPT); 
		     }

		     
		 }else if(results.item(i).getNodeType() == Node.ATTRIBUTE_NODE){

		     throw new UpdateTypeMismatchException(ErrorMessages.CANT_REPLACE_ATTRIBUTE); 
		 }		
		
	  }//for(int i...) 

	     Document doc = (Document) target;

	     //perform replacements
	     for(int k=0, klength = results.getLength(); k < klength;  k++){
		 
		 Node toReplace = results.item(k);
		 Node parent    = toReplace.getParentNode(); 
		 Node sibling   = toReplace.getNextSibling();
		 
		 // we need to be able to refer to document element of the modified 
		 //DOM document outside this loop 
		 if(nodeInModifiedDocument == null)
		     nodeInModifiedDocument =  results.item(k);

		 for(int m=0, mlength = nodes.getLength(); m < mlength; m++){
		  
		     Node newNode = doc.importNode(nodes.item(m), true); 
		     parent.insertBefore(newNode, toReplace);		     		     

		 }//for(int m...)
		 
		 parent.removeChild(toReplace);
		 
	     }//for(int k...)
	     	     
	     //update resource and save 
	     resource.setContentAsDOM(nodeInModifiedDocument.getOwnerDocument().getDocumentElement());
	     resource.getParentCollection().storeResource(resource); 

	}catch(javax.xml.parsers.ParserConfigurationException pce){
	    throw new XMLDBException(org.xmldb.api.base.ErrorCodes.VENDOR_ERROR, pce.getMessage()); 
	}catch(javax.xml.transform.TransformerException te){
	    
	    throw new InvalidQueryException(te.getMessage(), te); 
	}

	return nodeCount; 

    }/* replace(String, NodeList, resource) */ 

    /**
     * Renames one or more attribute or element nodes.
     * @param query The query which selects the nodes to update
     * @param name The new name. It can be a qualified name. 
     * @param namespaceURI the namespace URI for the element being inserted. If it is null 
     * then it is assumed the new item has no namespace URI.   
     * @param resource the document to perform the update against 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not one or more attribute or 
     * element nodes.
     * @see ErrorMessages#NODES_NOT_RETURNED
     * @see ErrorMessages#RENAME_ERROR
     */
    public int rename(String query, String name, String namespaceURI, SixdmlResource resource)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException{ 

	int nodeCount; 

	try{
	
	      Node namespaceNode = this.getNamespaceNode(); 	    
		    
	    //get DOM node from resource and run XPath query 
	    Node target    = resource.getContentAsDOM();
	    XObject xobj   = XPathAPI.eval(target, query, namespaceNode); 
	    
  
	    //Did the query return a nodeset? 
	    if(xobj.getType() != XObject.CLASS_NODESET)
		throw new UpdateTypeMismatchException(ErrorMessages.NODES_NOT_RETURNED); 

	    /* Need this because Nodes returned via NodeList aren't from target but from a clone */
	    Node nodeInModifiedDocument = null; 
	  	  
	    NodeList results = new org.apache.xpath.NodeSet(xobj.nodeset());
	    Node result   = null; 
	    nodeCount     = results.getLength(); 
	    
	     if(results.getLength() ==0)
		throw new UpdateTypeMismatchException(ErrorMessages.NODES_NOT_RETURNED); 	  
	
	    //Make sure the renaming is valid before attempting 
	    for(int i=0, ilength = results.getLength(); i < ilength;  i++){
	      
		 short[] validRenameTypes = {Node.ATTRIBUTE_NODE, Node.ELEMENT_NODE}; 		      

		 if(isNodeOfType(results.item(i).getNodeType(), validRenameTypes) == false)
		     throw new UpdateTypeMismatchException(ErrorMessages.RENAME_ERROR);     
	    }


	    //perform rename operation
	    for(int j=0, jlength = results.getLength(); j < jlength;  j++){
	      

		// we need to be able to refer to document element of the modified 
		//DOM document outside this loop 
		if(nodeInModifiedDocument == null)
		    nodeInModifiedDocument = results.item(j); 

		if(results.item(j).getNodeType() == Node.ATTRIBUTE_NODE){

		    Attr oldAttr  = (Attr) results.item(j); 
		    Element owner = oldAttr.getOwnerElement(); 
		    owner.removeAttributeNode(oldAttr); 

		    if(namespaceURI == null){
			owner.setAttribute(name, oldAttr.getValue());
		    }else{
			owner.setAttributeNS(namespaceURI, name, oldAttr.getValue());
			int colonIndx = name.indexOf(':'); 

			//create namespace declaration 
			if(colonIndx!= -1){
			    owner.setAttribute("xmlns:" + name.substring(0, colonIndx), 
					       namespaceURI);
			}//if(colonIndx...)
		    }//else

		}else if (results.item(j).getNodeType() == Node.ELEMENT_NODE){

		    Element oldElem = (Element) results.item(j); 
		    Document doc    = oldElem.getOwnerDocument();  
		    Element newElem ;

		    if( namespaceURI == null){
			newElem = doc.createElement(name);
		    }else{	
			
			newElem = doc.createElementNS(namespaceURI, name); 
			//create namespace declaration 
			newElem.setAttribute("xmlns:" + newElem.getPrefix(), namespaceURI);
		    }
					

		    //copy children from old node to new
		    NodeList children = oldElem.getChildNodes(); 

		    //not sure if cloning is necessary but better safe than sorry
		    for(int k =0, klength = children.getLength(); k < klength; k++)
			newElem.appendChild(children.item(k).cloneNode(true));

		    //copy over attributes 
		    NamedNodeMap attributes = oldElem.getAttributes(); 

		    for(int m =0, mlength = attributes.getLength(); m < mlength; m++){
			Attr currAttr = (Attr) attributes.item(m).cloneNode(true);

			if(currAttr.getNamespaceURI() == null)
			    newElem.setAttributeNode(currAttr);
			else 
			    newElem.setAttributeNodeNS(currAttr);			
						
		    }//for

		    doc.replaceChild(newElem, oldElem); 
		}

	    }//for(int j...)

	    //update resource and save 
	    resource.setContentAsDOM(nodeInModifiedDocument.getOwnerDocument().getDocumentElement());
	    resource.getParentCollection().storeResource(resource); 
	

	}catch(javax.xml.parsers.ParserConfigurationException pce){
	    throw new XMLDBException(org.xmldb.api.base.ErrorCodes.VENDOR_ERROR, pce.getMessage()); 
	}catch(javax.xml.transform.TransformerException te){
	    
	    throw new InvalidQueryException(te.getMessage(), te); 
	}

	return nodeCount; 

    }/* rename(String,String, SixdmlResource) */ 


    /**
     * Inserts an XML fragment as a sibling of each of the nodes returned from the XPath query. 
     * A boolean flag indicates whether the new node will be inserted before or after the 
     * selected nodes.     
     * @param query The query which selects the nodes to update
     * @param fragment The XML fragment to insert
     * @param collection the collection whose documents to perform the update against 
     * @param before if this is true then the new node wil be inserted before each of the selected node
     * while if it is false the new node will be inserted after the selected nodes in the tree.  
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException if the target node is the document root and an attempt is 
     * made to insert anything besides comments or processing instructions. 
     * @exception NonWellFormedXMLException if the XML fragment is not a valid XML fragment. 
     */
    public int insertSibling(String query, String fragment,SixdmlCollection collection, boolean before)
	throws XMLDBException, InvalidQueryException, NonWellFormedXMLException, UpdateTypeMismatchException{ 

	return this.insertSibling(query, null, fragment, collection, before); 

    }/* insertSibling(String, String, SixdmlCollection, boolean) */ 


    /**
     * Inserts an XML fragment as a sibling of each of the nodes returned from the XPath query. 
     * A boolean flag indicates whether the new node will be inserted before or after the 
     * selected nodes.     
     * @param query The query which selects the nodes to update
     * @param fragment The XML fragment to insert
     * @param collection the collection whose documents to perform the update against 
     * @param before if this is true then the new node wil be inserted before each of the selected node
     * while if it is false the new node will be inserted after the selected nodes in the tree.  
     * @param predicate a filter expression used to determine which documents to update within the collection. 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException if the target node is the document root and an attempt is 
     * made to insert anything besides comments or processing instructions. 
     * @exception NonWellFormedXMLException if the XML fragment is not a valid XML fragment. 
     */
    public int insertSibling(String query, String predicate, String fragment,SixdmlCollection collection, boolean before)
	throws XMLDBException, InvalidQueryException, NonWellFormedXMLException, UpdateTypeMismatchException{ 

	String []resources = collection.listResources(); 
	int nodeCount = 0; 

	try{

	for(int i=0; i < resources.length; i++)
	    if( (predicate == null) || XPathAPI.eval(((SixdmlResource)collection.getResource(resources[i])).getContentAsDOM(), predicate, this.getNamespaceNode()).bool()==true)
	 nodeCount += this.insertSibling(query, fragment, (SixdmlResource)collection.getResource(resources[i]), before); 

	}catch(javax.xml.parsers.ParserConfigurationException pce){
	    throw new XMLDBException(org.xmldb.api.base.ErrorCodes.VENDOR_ERROR, pce.getMessage()); 
	}catch(javax.xml.transform.TransformerException te){
	    
	    throw new InvalidQueryException(te.getMessage(), te); 
	}

	return nodeCount; 

    }/* insertSibling(String, String, String, SixdmlCollection, boolean) */ 


    /**
     * Inserts an XML fragment as a child of each of the nodes returned from the XPath query. 
     * The new node is appended to the end of the current children of the 
     * selected node. 
     * @param query The query which selects the nodes to update
     * @param fragment The XML fragment to insert
     * @param collection the collection whose documents to perform the update against 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node, document node
     * or set of element nodes. 
     * @exception NonWellFormedXMLException if the XML fragment is not a valid XML fragment. 
     */
    public int insertChild(String query, String fragment,SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException, NonWellFormedXMLException, UpdateTypeMismatchException{ 

	return this.insertChild(query, null, fragment, collection);

    }/* insertChild(String, String,  SixdmlCollection) */


     /**
     * Inserts an XML fragment as a child of each of the nodes returned from the XPath query. 
     * The new node is appended to the end of the current children of the 
     * selected node. 
     * @param query The query which selects the nodes to update
     * @param fragment The XML fragment to insert
     * @param collection the collection whose documents to perform the update against 
     * @param predicate a filter expression used to determine which documents to update within the collection. 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node, document node
     * or set of element nodes. 
     * @exception NonWellFormedXMLException if the XML fragment is not a valid XML fragment. 
     */
    public int insertChild(String query, String predicate, String fragment,SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException, NonWellFormedXMLException, UpdateTypeMismatchException{ 

	String []resources = collection.listResources(); 
	int nodeCount = 0; 
	
	try{

	for(int i=0; i < resources.length; i++)
	    if( (predicate == null) || XPathAPI.eval(((SixdmlResource)collection.getResource(resources[i])).getContentAsDOM(), predicate, this.getNamespaceNode()).bool()==true)
	 nodeCount += this.insertChild(query, fragment, (SixdmlResource)collection.getResource(resources[i])); 

	}catch(javax.xml.parsers.ParserConfigurationException pce){
	    throw new XMLDBException(org.xmldb.api.base.ErrorCodes.VENDOR_ERROR, pce.getMessage()); 
	}catch(javax.xml.transform.TransformerException te){
	    
	    throw new InvalidQueryException(te.getMessage(), te); 
	}

	return nodeCount;

    }/* insertChild(String, String, String,  SixdmlCollection) */


    /**
     * Inserts a node as a sibling of each of the nodes returned from the XPath query. 
     * A boolean flag indicates whether the new node will be inserted before or after the 
     * selected nodes.     
     * @param query The query which selects the nodes to update
     * @param nodes The DOM node(s) to insert
     * @param collection the collection whose documents to perform the update against 
     * @param before if this is true then the new node wil be inserted before each of the selcted node
     * while if it is false the new node will be inserted after the selected nodes in the tree.  
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException if the target node is the document root and an attempt is 
     * made to insert anything besides comments or processing instructions. 
     */
    public int insertSibling(String query, NodeList nodes,SixdmlCollection collection, boolean before)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException{ 	

	return this.insertSibling(query, null, nodes, collection, before);

    } /* insertSibling(String, NodeList, SixdmlCollection, boolean) */


     /**
     * Inserts a node as a sibling of each of the nodes returned from the XPath query. 
     * A boolean flag indicates whether the new node will be inserted before or after the 
     * selected nodes.     
     * @param query The query which selects the nodes to update
     * @param nodes The DOM node(s) to insert
     * @param collection the collection whose documents to perform the update against 
     * @param before if this is true then the new node wil be inserted before each of the selcted node
     * while if it is false the new node will be inserted after the selected nodes in the tree.  
     * @param predicate a filter expression used to determine which documents to update within the collection. 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException if the target node is the document root and an attempt is 
     * made to insert anything besides comments or processing instructions. 
     */
    public int insertSibling(String query, String predicate, NodeList nodes,SixdmlCollection collection, boolean before)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException{ 

	int nodeCount = 0; 

	String []resources = collection.listResources(); 
	

	try{

	for(int i=0; i < resources.length; i++)
	    if( (predicate == null) || XPathAPI.eval(((SixdmlResource)collection.getResource(resources[i])).getContentAsDOM(), predicate, this.getNamespaceNode()).bool()==true)
		nodeCount += this.insertSibling(query, nodes, (SixdmlResource)collection.getResource(resources[i]), before); 

	}catch(javax.xml.parsers.ParserConfigurationException pce){
	    throw new XMLDBException(org.xmldb.api.base.ErrorCodes.VENDOR_ERROR, pce.getMessage()); 
	}catch(javax.xml.transform.TransformerException te){
	    
	    throw new InvalidQueryException(te.getMessage(), te); 
	}

	return nodeCount;

    } /* insertSibling(String, String, NodeList, SixdmlCollection, boolean) */


    /**
     * Inserts a node as a child of each of the nodes returned from the XPath query. 
     * The new node is appended to the end of the current children of the 
     * selected node. 
     * @param query The query which selects the nodes to update
     * @param nodes The DOM node(s) to insert
     * @param collection the collection whose documents to perform the update against 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node, document node
     * or set of element nodes. 
     */
    public int insertChild(String query, NodeList nodes,SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException{ 
	
	return this.insertChild(query, null, nodes, collection);
    
    }/* insertChild(String, NodeList, SixdmlCollection) */ 

     /**
     * Inserts a node as a child of each of the nodes returned from the XPath query. 
     * The new node is appended to the end of the current children of the 
     * selected node. 
     * @param query The query which selects the nodes to update
     * @param nodes The DOM node(s) to insert
     * @param collection the collection whose documents to perform the update against 
     * @param predicate a filter expression used to determine which documents to update within the collection. 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node, document node
     * or set of element nodes. 
     */
    public int insertChild(String query, String predicate, NodeList nodes,SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException{ 

	int nodeCount = 0; 

	String []resources = collection.listResources(); 
	
	try{
	
	    for(int i=0; i < resources.length; i++)
		if( (predicate == null) || XPathAPI.eval(((SixdmlResource)collection.getResource(resources[i])).getContentAsDOM(), predicate, this.getNamespaceNode()).bool()==true)
		    nodeCount += this.insertChild(query, nodes, (SixdmlResource)collection.getResource(resources[i]));
	    
	}catch(javax.xml.parsers.ParserConfigurationException pce){
	    throw new XMLDBException(org.xmldb.api.base.ErrorCodes.VENDOR_ERROR, pce.getMessage()); 
	}catch(javax.xml.transform.TransformerException te){
	    
	    throw new InvalidQueryException(te.getMessage(), te); 
	}

	return nodeCount;
    
    }/* insertChild(String, String, NodeList, SixdmlCollection) */ 


    
    /**
     * Inserts an attribute node as a child of each of the nodes returned from the XPath query.     
     * @param query The query which selects the nodes to update
     * @param collection the collection whose documents to perform the update against 
     * @param name The name of the attribute to insert. 
     * @param value the value of the attribute to insert.  
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node
     * or set of element nodes. 
     */
    public int insertAttribute(String query, SixdmlCollection collection, String name, String value)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException{ 

	return this.insertAttribute(query, null, collection, name, value);

    } /* insertAttribute(String, SixdmlCollection, String, String) */


     /**
     * Inserts an attribute node as a child of each of the nodes returned from the XPath query.     
     * @param query The query which selects the nodes to update
     * @param collection the collection whose documents to perform the update against 
     * @param name The name of the attribute to insert. 
     * @param value the value of the attribute to insert.  
     * @param predicate a filter expression used to determine which documents to update within the collection. 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node
     * or set of element nodes. 
     */
    public int insertAttribute(String query, String predicate, SixdmlCollection collection, String name, String value)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException{ 

	String []resources = collection.listResources(); 
	int nodeCount = 0; 

	try{

	    for(int i=0; i < resources.length; i++)
		if( (predicate == null) || XPathAPI.eval(((SixdmlResource)collection.getResource(resources[i])).getContentAsDOM(), predicate, this.getNamespaceNode()).bool()==true)
		    nodeCount += this.insertAttribute(query, (SixdmlResource)collection.getResource(resources[i]), name, value);
	    
	}catch(javax.xml.parsers.ParserConfigurationException pce){
	    throw new XMLDBException(org.xmldb.api.base.ErrorCodes.VENDOR_ERROR, pce.getMessage()); 
	}catch(javax.xml.transform.TransformerException te){
	    
	    throw new InvalidQueryException(te.getMessage(), te); 
	}

	return nodeCount;

    } /* insertAttribute(String, String, SixdmlCollection, String) */



    /**
     * Inserts an attribute node as a child of each of the nodes returned from the XPath query.     
     * @param query The query which selects the nodes to update
     * @param collection the collection whose documents to perform the update against 
     * @param name The name of the attribute to insert. It should be an XML qualified name. 
     * @param value the value of the attribute to insert.     
     * @param namespaceURI the namsepace URI for the attribute node
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node
     * or set of element nodes. 
     */
    public int insertAttribute(String query, SixdmlCollection collection, String name, 
				String value, String namespaceURI)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException{ 

	return this.insertAttribute(query, null, collection, name, value, namespaceURI); 

    }  /* insertAttribute(String, SixdmlCollection, String, String, String) */


     /**
     * Inserts an attribute node as a child of each of the nodes returned from the XPath query.     
     * @param query The query which selects the nodes to update
     * @param collection the collection whose documents to perform the update against 
     * @param name The name of the attribute to insert. It should be an XML qualified name. 
     * @param value the value of the attribute to insert.     
     * @param namespaceURI the namsepace URI for the attribute node
     * @param predicate a filter expression used to determine which documents to update within the collection. 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node
     * or set of element nodes. 
     */
    public int insertAttribute(String query, String predicate, SixdmlCollection collection, String name, 
				String value, String namespaceURI)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException{ 

	String []resources = collection.listResources(); 
	int nodeCount = 0; 
	
	try{
	
	    for(int i=0; i < resources.length; i++)
		if( (predicate == null) || XPathAPI.eval(((SixdmlResource)collection.getResource(resources[i])).getContentAsDOM(), predicate, this.getNamespaceNode()).bool()==true)
		    nodeCount += this.insertAttribute(query, (SixdmlResource)collection.getResource(resources[i]), name, value, namespaceURI);
	    
	}catch(javax.xml.parsers.ParserConfigurationException pce){
	    throw new XMLDBException(org.xmldb.api.base.ErrorCodes.VENDOR_ERROR, pce.getMessage()); 
	}catch(javax.xml.transform.TransformerException te){
	    
	    throw new InvalidQueryException(te.getMessage(), te); 
	}
    
	return nodeCount; 

    }  /* insertAttribute(String, String, SixdmlCollection, String, String, String) */

    /**
     * Deletes all nodes that match the expression from the target document. 
     * @param query The query which selects the nodes to delete. 
     * @param collection the collection whose documents to perform the update against 
     * @return the number of nodes affected by the update. 
     */
    public int delete(String query, SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException{ 
	
	return this.delete(query, null, collection); 
	
    }/* delete(String, SixdmlCollection) */ 


     /**
     * Deletes all nodes that match the expression from the target document. 
     * @param query The query which selects the nodes to delete. 
     * @param collection the collection whose documents to perform the update against 
     * @param predicate a filter expression used to determine which documents to update within the collection. 
     * @return the number of nodes affected by the update. 
     */
    public int delete(String query, String predicate,  SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException{ 

	
	
	String []resources = collection.listResources(); 
	int nodeCount = 0; 

	try{

	    for(int i=0; i < resources.length; i++)
		if( (predicate == null) || XPathAPI.eval(((SixdmlResource)collection.getResource(resources[i])).getContentAsDOM(), predicate, this.getNamespaceNode()).bool()==true)
		    nodeCount += this.delete(query, (SixdmlResource)collection.getResource(resources[i])); 
	    
	}catch(javax.xml.parsers.ParserConfigurationException pce){
	    throw new XMLDBException(org.xmldb.api.base.ErrorCodes.VENDOR_ERROR, pce.getMessage()); 
	}catch(javax.xml.transform.TransformerException te){
	    
	    throw new InvalidQueryException(te.getMessage(), te); 
	}
	
	return nodeCount; 
	
    }/* delete(String, String, SixdmlCollection) */ 


    /**
     * Replaces one or more element, processing-instruction, comment, or text nodes with the new node.
     * @param query The query which selects the nodes to update
     * @param fragment the XML fragment to insert. 
     * @param collection the collection whose documents to perform the update against 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not one or more comment, text, 
     * processing-instruction, or element nodes. 
     * @exception NonWellFormedXMLException if the XML fragment is not a valid XML fragment. 
     * @return the number of nodes affected by the update. 
     * @see ErrorMessages#NODES_NOT_RETURNED
     * @see ErrorMessages#BAD_UPDATE_ATTEMPT
     * @see ErrorMessages#MULTIPLE_ROOT_ELEMENTS
     * @see ErrorMessages#CANT_REPLACE_ATTRIBUTE
     */
    public int replace(String query, String fragment , SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException, NonWellFormedXMLException , UpdateTypeMismatchException{

	NodeList nodesToInsrt = this.loadIntoNodeList(fragment);
	return this.replace(query, nodesToInsrt, collection);	

    }  /* replace(String, String, SixdmlCollection) */

     /**
     * Replaces one or more element, processing-instruction, comment, or text nodes with the new node.
     * @param query The query which selects the nodes to update
     * @param fragment the XML fragment to insert. 
     * @param collection the collection whose documents to perform the update against 
     * @param predicate a filter expression used to determine which documents to update within the collection. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not one or more comment, text, 
     * processing-instruction, or element nodes. 
     * @exception NonWellFormedXMLException if the XML fragment is not a valid XML fragment. 
     * @return the number of nodes affected by the update. 
     * @see ErrorMessages#NODES_NOT_RETURNED
     * @see ErrorMessages#BAD_UPDATE_ATTEMPT
     * @see ErrorMessages#MULTIPLE_ROOT_ELEMENTS
     * @see ErrorMessages#CANT_REPLACE_ATTRIBUTE
     */
    public int replace(String query, String predicate, String fragment , SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException, NonWellFormedXMLException , UpdateTypeMismatchException{

	NodeList nodesToInsrt = this.loadIntoNodeList(fragment);
	return this.replace(query, predicate, nodesToInsrt, collection);	

    } /* replace(String, String, String, SixdmlCollection) */
     
    /**
     * Replaces one or more element, processing-instruction, comment, or text nodes with the new node.
     * @param query The query which selects the nodes to update
     * @param nodes The DOM node(s) to insert
     * @param collection the collection whose documents to perform the update against 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not one or more comment, text, 
     * processing-instruction, or element nodes. 
     * @return the number of nodes affected by the update. 
     * @see ErrorMessages#NODES_NOT_RETURNED
     * @see ErrorMessages#BAD_UPDATE_ATTEMPT
     * @see ErrorMessages#MULTIPLE_ROOT_ELEMENTS
     * @see ErrorMessages#CANT_REPLACE_ATTRIBUTE
     */
    public int replace(String query, NodeList nodes, SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException{ 
	
	return this.replace(query, null, nodes, collection); 

    }/* replace(String, NodeList, SixdmlCollection) */ 


      /**
     * Replaces one or more element, processing-instruction, comment, or text nodes with the new node.
     * @param query The query which selects the nodes to update
     * @param nodes The DOM node(s) to insert
     * @param collection the collection whose documents to perform the update against 
     * @param predicate a filter expression used to determine which documents to update within the collection. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not one or more comment, text, 
     * processing-instruction, or element nodes. 
     * @return the number of nodes affected by the update. 
     * @see ErrorMessages#NODES_NOT_RETURNED
     * @see ErrorMessages#BAD_UPDATE_ATTEMPT
     * @see ErrorMessages#MULTIPLE_ROOT_ELEMENTS
     * @see ErrorMessages#CANT_REPLACE_ATTRIBUTE
     */
    public int replace(String query, String predicate, NodeList nodes, SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException{ 

	String []resources = collection.listResources(); 
	int nodeCount = 0; 
	
	try{

	    for(int i=0; i < resources.length; i++)
		if( (predicate == null) || XPathAPI.eval(((SixdmlResource)collection.getResource(resources[i])).getContentAsDOM(), predicate, this.getNamespaceNode()).bool()==true)
		    nodeCount += this.replace(query, nodes, (SixdmlResource)collection.getResource(resources[i])); 

	}catch(javax.xml.parsers.ParserConfigurationException pce){
	    throw new XMLDBException(org.xmldb.api.base.ErrorCodes.VENDOR_ERROR, pce.getMessage()); 
	}catch(javax.xml.transform.TransformerException te){
	    
	    throw new InvalidQueryException(te.getMessage(), te); 
	}

	return nodeCount; 

    }/* replace(String, String, NodeList, SixdmlCollection) */ 

    /**
     * Renames one or more attribute or element nodes.
     * @param query The query which selects the nodes to update
     * @param name The new name
     * @param namespaceURI the namespace URI for the element being inserted. If it is null 
     * then it is assumed the new item has no namespace URI.  
     * @param collection the collection whose documents to perform the update against 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not one or more comment, text, 
     * processing-instruction, or element nodes. 
     */
    public int rename(String query, String name, String namespaceURI, SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException{ 

	return this.rename(query, null, name, namespaceURI, collection);

    }/* rename(String, String, SixdmlCollection) */ 

      /**
     * Renames one or more attribute or element nodes.
     * @param query The query which selects the nodes to update
     * @param name The new name
     * @param namespaceURI the namespace URI for the element being inserted. If it is null 
     * then it is assumed the new item has no namespace URI.  
     * @param collection the collection whose documents to perform the update against 
     * @param predicate a filter expression used to determine which documents to update within the collection. 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not one or more comment, text, 
     * processing-instruction, or element nodes. 
     */
    public int rename(String query, String predicate, String name, String namespaceURI, SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException{ 

	String []resources = collection.listResources(); 
	int nodeCount = 0;

	try{
	
	for(int i=0; i < resources.length; i++)
	    if( (predicate == null) || (XPathAPI.eval(((SixdmlResource)collection.getResource(resources[i])).getContentAsDOM(), predicate, this.getNamespaceNode()).bool()==true))
		nodeCount += this.rename(query, name, namespaceURI, (SixdmlResource)collection.getResource(resources[i]));

	}catch(javax.xml.parsers.ParserConfigurationException pce){
	    throw new XMLDBException(org.xmldb.api.base.ErrorCodes.VENDOR_ERROR, pce.getMessage()); 
	}catch(javax.xml.transform.TransformerException te){
	    
	    te.printStackTrace();
	    throw new InvalidQueryException(te.getMessage(), te); 
	    
	}

	return nodeCount;

    }/* rename(String, String, String, SixdmlCollection) */ 


}
