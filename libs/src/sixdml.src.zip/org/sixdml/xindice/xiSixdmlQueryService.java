package org.sixdml.xindice;

import org.sixdml.SixdmlConstants;
import org.sixdml.SixdmlNamespaceMap;
import org.sixdml.dbmanagement.SixdmlCollection;
import org.sixdml.dbmanagement.SixdmlResource;
import org.sixdml.exceptions.InvalidQueryException;
import org.sixdml.query.SixdmlQueryResultsMap;
import org.sixdml.query.SixdmlQueryService;
import org.sixdml.query.SixdmlXpathObject;
import org.xmldb.api.base.Collection;
import org.xmldb.api.base.ResourceIterator;
import org.xmldb.api.base.ResourceSet;
import org.xmldb.api.base.XMLDBException;
import org.xmldb.api.modules.XMLResource;
import org.xmldb.api.modules.XPathQueryService;
import org.w3c.dom.Node;
import org.apache.xpath.*;
import org.apache.xpath.objects.*;

/**
 * <PRE>
 * xiSixdmlQueryService.java
 *
 * An implementation of the <code>SixdmlQueryService</code> interface which enables the execution of 
 * XPath queries within the context of a collection or against the documents stored in the Collection.
 * </PRE>
 * @version 1.0
 */

class xiSixdmlQueryService  extends xiNamespaceAwareService implements SixdmlQueryService, SixdmlConstants{


     /**
     * Default constructor initializes service.
     */
    xiSixdmlQueryService() {;}

    /**
     * Gets the name of the service. 
     * @return the name of the service. 
     */
    public String getName() {
		return "SixdmlQueryService";
    }

    

    /**
     * Executes an XPath query against the specified collection only returning results from
     * documents that satisfy the given predicate.  
     * @param query the XPath query. 
     * @param collection the collection to execute the query against. 
     * @param predicate an XPath query used to filter which documents the main query is run against. 
     * @return the results of the query as a pairing of SixdmlResources and 
     * SixdmlXpathObjects.
     * @see SixdmlXpathObject
     * @exception InvalidQueryException if the query is not valid XPath. 
     * @exception XMLDBException if a database error occurs 
     */
    public SixdmlQueryResultsMap executeQuery(String query, SixdmlCollection collection, String predicate)
	throws InvalidQueryException, XMLDBException{

	SixdmlQueryResultsMap results = new SixdmlQueryResultsMap(collection.getName(), query); 
  	   
	 try{
 
	    String[] resources = collection.listResources(); 
	    Node namespaceNode = this.getNamespaceNode(); 

	   

	    //execute query on each document in collection and store result. 
	    for(int i=0; i < resources.length; i++){	

		SixdmlResource resource = (SixdmlResource) collection.getResource(resources[i]); 
		
		if( (predicate != null) && 
		    (XPathAPI.eval(resource.getContentAsDOM(), predicate, namespaceNode).bool()==false))
		    continue; 
			       
		SixdmlXpathObject result =  
		    new xiSixdmlXpathObject(XPathAPI.eval(resource.getContentAsDOM(), query, namespaceNode));
		
		String queryResults =  (result.getType() == SixdmlXpathObject.NODESET ? 
					result.getNodeSetAsXML(): 
					result.getObjectAsString()
					); 
				       
		//only store mapping if query returned something 
		if(!queryResults.trim().equals(""))
		    results.put(resources[i], queryResults); 

	    }//for
	   	
	    }catch(javax.xml.transform.TransformerException te){
		
		throw new InvalidQueryException(te.getMessage(), te); 
	    }catch(javax.xml.parsers.ParserConfigurationException pce){
		throw new XMLDBException(org.xmldb.api.base.ErrorCodes.VENDOR_ERROR, pce.getMessage()); 
	    }

	return results; 
    }


    /**
     * Executes an XPath query against the specified collection. 
     * @param query the XPath query. 
     * @param collection the collection to execute the query against. 
     * @return the results of the query as a pairing of SixdmlResources and 
     * SixdmlXpathObjects.
     * @see SixdmlXpathObject
     * @exception InvalidQueryException if the query is not valid XPath. 
     * @exception XMLDBException if a database error occurs 
     */
    public SixdmlQueryResultsMap executeQuery(String query, SixdmlCollection collection)
	throws InvalidQueryException, XMLDBException{

	return executeQuery(query, collection, null); 
	
    }/* executeQuery(String, SixdmlCollection) */

     /**
     * Executes an XPath query against the specified collection. 
     * @param query the XPath query. 
     * @param collection the collection to execute the query against. 
     * @return the results of the query as a SixdmlXpathObject.     
     * @exception XMLDBException if a database error occurs 
     * @exception InvalidQueryException if the query is not valid XPath. 
     */
    public SixdmlXpathObject executeQuery(String query, SixdmlResource resource)
    throws InvalidQueryException, XMLDBException{

	try{ 
	    return new xiSixdmlXpathObject(XPathAPI.eval( resource.getContentAsDOM(), query, this.getNamespaceNode())); 
	    
	}catch(javax.xml.transform.TransformerException te){
	    
	    throw new InvalidQueryException(te.getMessage(), te); 
	}catch(javax.xml.parsers.ParserConfigurationException pce){
	    throw new XMLDBException(org.xmldb.api.base.ErrorCodes.VENDOR_ERROR, pce.getMessage()); 
	}
		
    }      
 

     /**
     * Main used for testing class. 
     * @param args IGNORED
     */
    public static void main(String[] args) throws Exception{

	
	String driver = "org.sixdml.xindice.xiSixdmlDatabase";
	Class c = Class.forName(driver);
	org.sixdml.SixdmlDatabase database = (org.sixdml.SixdmlDatabase) c.newInstance(); 
	org.xmldb.api.DatabaseManager.registerDatabase(database); 

	SixdmlResource resource = (SixdmlResource) database.getResource("xindice:///db/addressbook/address1", "", ""); 

	String interimResults; 

	SixdmlQueryService queryManager = 
	    (SixdmlQueryService) database.getService("SixdmlQueryService", "1.0"); 

	/* query a document */
	SixdmlXpathObject sxo = queryManager.executeQuery("/*", resource);  

	if (sxo.getType() == SixdmlXpathObject.NODESET)
	    interimResults = sxo.getNodeSetAsXML(); 
	else
	    interimResults = sxo.getObjectAsString(); 	

	System.out.println(interimResults);
    }
  
}


