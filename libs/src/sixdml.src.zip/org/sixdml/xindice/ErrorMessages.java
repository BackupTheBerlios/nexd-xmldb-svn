package org.sixdml.xindice;

/**
 * <PRE>  
 * ErrorMessages.java
 *
 * This class holds error messages that are used when exceptions are thrown. 
 *
 * Created: Sat Jan 12 00:26:39 2002
 *
 * </PRE>  
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 */

public class ErrorMessages  {
    
    /*=================================================================*/
    /*                    E R R O R       M E S S A G E S              */
    /*=================================================================*/

    /**
     * Displayed when a URI to a collection or resource is malformed. 
     */ 
    public static final String BAD_URI = "The path to the collection or resource is improperly formed";


    /**
     * Displayed when an operation is invoked against an xlnSixdmlCollection instance 
     * that has been closed.
     */
    public static final String COLLECTION_CLOSED = "The collection has been closed."; 

    /**
     * Displayed when the resource type requested is unknown to the API implementation.
     */
    public static final String UNKNOWN_RESOURCE_TYPE = 
	"This implementation cannot handle the specified resource type"; 

    /**
     * Displayed when an attempt is made to access the schema for a collection
     * without going through the schema access methods. 
     */
    public static final String PERMISSION_DENIED_SCHEMA = 
	"The schema for a collection can only be manipulated via proper schema access methods"; 

    /**
     * Displayed when an attempt is made to access the index data for a collection
     * without going through the index manipulation methods. 
     */
    public static final String PERMISSION_DENIED_INDEX = 
	"The index file for a collection can only be manipulated via proper index manipulation methods"; 

    
    /**
     * Displayed when an attempt is made to perform an operation on a Resource that doesn't exist 
     * in that context. Prime example is trying to delete a Resource from a Collection that isn't
     * it's parent collection.
     */
    public static final String NO_SUCH_RESOURCE = "No such document exists in this context"; 

    /**
     * Displayed when an attempt is made to store a document in a collection that has a child 
     * collection with the the same name.
     */
    public static final String WRONG_CONTENT_TYPE_STORE = 
	"A collection already exists with the same name as the document being stored";

    /**
     * Displayed when an error occured in accessing the underlying DXE excelon database. 
     */
    public static final String XINDICE_ERROR = 
	"The following error occured in the underlying Xindice Server:"; 

    
    /**
     * Displayed when an attempt is made to initialize a resource from a DOM node that is not an 
     * Element node. 
     */
    public static final String WRONG_CONTENT_TYPE_ELEM_NODE = 
	"Wrong node type received, the application was expecting an Element node ";


    /**
     * Displayed when an attempt is made to utilize a feature that has not been implemented. 
     */
    public static final String NOT_IMPLEMENTED = 
	"The requested feature has not been implemented at this time";

    /**
     * Displayed when an XPath query that is supposed to be used as a source for update 
     * operations does not return nodes. 
     */
    public static final String NODES_NOT_RETURNED = 
	"The results of XPath query did not contain any nodes";

    /**
     * Displayed when an update operation would result in a document that is not well-formed. 
     */
    public static final String BAD_UPDATE_ATTEMPT = 
	"The attempted update would result in a document that is not well formed: "; 

    /**
     * Displayed if an attempt is made to create multiple document roots via an insertion operation.
     */
    public static final String MULTIPLE_ROOT_ELEMENTS = 
	"Attempt to create multiple root elements disallowed";
     
    /**
     * Displayed when an attempt is made to rename a node that isn't an element or attribute 
     * node. 
     */
    public static final String RENAME_ERROR = "Only attributes and elements can be renamed"; 

    /**
     * Displayed when an attempt is made to retrieve a non-existent collection. 
     */ 
    public static final String NO_SUCH_COLLECTION = 
	"No collection by that name exists in the database";

    /**
     * Displayed when a validation error occurs when attempting to store a document in a collection.
     */
    public static final String VALIDATION_ERROR = "Error occured while validating document, storage ABORTED : ";

    /**
     * Displayed when an attempt is made to replace an attribute. 
     */
    public static final String CANT_REPLACE_ATTRIBUTE = 
	"Attributes cannot be replaced using this method."; 
  


    /**
     * Displayed when an attempt is made to invoke a service using the wrong version number. 
     */
     public static final String WRONG_VERSION  = 
	 "Incorrect version number used to invoke service"; 

    /*=================================================================*/
    /*                    E R R O R       C O D E S                    */
    /*=================================================================*/


    /**
     * An error code that an attempt has been made to create a collection that already exists.      
     */
    public static final int DUPLICATE_COLLECTION = 10;



} // ErrorMessages
