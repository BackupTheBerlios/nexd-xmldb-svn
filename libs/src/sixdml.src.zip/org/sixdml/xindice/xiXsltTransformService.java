package org.sixdml.xindice;

import org.sixdml.transform.*;
import org.sixdml.SixdmlConstants;
import org.xmldb.api.base.Collection;
import org.xmldb.api.base.XMLDBException;
import org.sixdml.exceptions.InvalidTransformException;
import org.sixdml.exceptions.NonWellFormedXMLException;
import org.w3c.dom.DOMImplementation;
import java.net.URL;
import java.io.*; 
import org.sixdml.dbmanagement.SixdmlResource;
import java.util.HashMap; 
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.*;
import javax.xml.transform.stream.*;


/**
 * <PRE>  
 * xiXsltTransformService.java
 *
 * Performs XSLT ransformations on Nodes. 
 * </PRE>  
 * @version 1.0 
 */

class xiXsltTransformService extends xiServiceBase implements SixdmlTransformService, SixdmlConstants {
    

  
    /*=================================================================*/
    /*                        C O N S T R U C T O R S                  */
    /*=================================================================*/

    /**
     * Default constructor initializes service.
     * @param session the DXE session associated with the class.
     */
    xiXsltTransformService() {;}

    
    /*=================================================================*/
    /*                I N S T A N C E       M E T H O D S              */
    /*=================================================================*/   


     /**
     * Get the type of this object as a SixdmlTransformType.
     * @return the type of this object. 
     */
    public SixdmlTransformType getType(){

	return SixdmlTransformType.XSLT; 
    } 


    /**
     * Gets the types of transforms that are supported by the this database. 
     * Currently only XSLT is supported.
     * @return an array of SixdmlTransformTypes which the database supports. 
     */
    public SixdmlTransformType[] getSupportedTransformTypes(){

	return new SixdmlTransformType[]{ SixdmlTransformType.XSLT };
    } 
   
     /**
     * Transforms a SixdmlResource from one XML document to another and returns the 
     * results in a string. If the results are not XML then the root node 
     * will be a &lt;transform-result&lt; element from the http://www.25hoursaday.com/sixdml
     * namespace containing the actual results in a CDATA child node.
     * @param source the URL to the location of the file containing the transform. 
     * @param resource the resource to transform
     * @return the results of the transform in a string. 
     * @exception IOException if an error occurs while trying to retrieve the file.
     * @exception InvalidTransformException if the transform specified is an invalid or non-well formed
     * query or document. 
     */
    public String transformAndReturnString(URL source, SixdmlResource resource)
	throws IOException, InvalidTransformException{	 
	
	String trnsfrmStr = getContentsOfURL(source);
	return transformAndReturnString(trnsfrmStr, resource); 
	
    } /* transformAndReturnString(URL, SixdmlResource) */

    /**
     * Transforms a SixdmlResource from one XML document to another and returns the 
     * results in a string. If the results are not XML then the root node 
     * will be a &lt;transform-result&lt; element from the http://www.25hoursaday.com/sixdml
     * namespace containing the actual results in a CDATA child node.
     * @param transformCode the actual code for the stylesheet or query.
     * @param resource the resource to transform
     * @return the results of the transform in a string. 
     * @exception InvalidTransformException if the transform specified is an invalid or non-well formed
     * query or document. 
     */
    public String transformAndReturnString(String transformCode, SixdmlResource resource)
	throws InvalidTransformException{

	StringWriter toReturn = new StringWriter(); 

	try{	   

	   Source xmlSource  =  new DOMSource(resource.getContentAsDOM());
	   Source xsltSource =  new StreamSource(new StringReader(transformCode)); 
	   Result result     =  new StreamResult(toReturn);
 
	   // create an instance of TransformerFactory
	   TransformerFactory transFact = TransformerFactory.newInstance();
	   Transformer trans            = transFact.newTransformer(xsltSource);
 
	   trans.transform(xmlSource, result);	      

	}catch(TransformerException te){

	    throw new InvalidTransformException(te.getMessage()); 	
	
	}catch(XMLDBException xdbe){ 

	    throw new InvalidTransformException(xdbe); 
	}
	
	return toReturn.toString(); 

    }  /* transformAndReturnString(String, SixdmlResource) */



    /**
     * Transforms a string representation of a wellformed XML document to another and returns the 
     * results in a string.
     * @param transformCode the actual code for the stylesheet or query.
     * @param sourceXML the XML to transform
     * @return the results of the transform in a string. 
     * @exception InvalidTransformException if the transform specified is an invalid or 
     * non-well formed query or document. 
     * @exception NonWellFormedXMLException if the data to transform is not a wellformed 
     * XML document. 
     */
    public String transformAndReturnString(String transformCode, String sourceXML)
	throws InvalidTransformException, NonWellFormedXMLException{

	StringWriter toReturn = new StringWriter(); 

	try{	   

	   Source xmlSource  =  new StreamSource(new StringReader(sourceXML));
	   Source xsltSource =  new StreamSource(new StringReader(transformCode)); 
	   Result result     =  new StreamResult(toReturn);
 
	   // create an instance of TransformerFactory
	   TransformerFactory transFact = TransformerFactory.newInstance();
	   Transformer trans            = transFact.newTransformer(xsltSource);
 
	   trans.transform(xmlSource, result);	      

	}catch(TransformerException te){

	    throw new InvalidTransformException(te.getMessage()); 		
	}
	
	return toReturn.toString(); 

    }  /* transformAndReturnString(String, String) */

     /**
     * Transforms a SixdmlResource from one XML document to another and returns the 
     * results in a string. 
     * @param source the URL to the location of the file containing the transform. 
     * @param sourceXML the XML to transform
     * @return the results of the transform in a string. 
     * @exception IOException if an error occurs while trying to retrieve the file.
     * @exception InvalidTransformException if the transform specified is an invalid or 
     * non-well formed query or document. 
     * @exception NonWellFormedXMLException if the data to transform is not a wellformed 
     * XML document. 
     */
    public String transformAndReturnString(URL source, String sourceXML)
	throws IOException, InvalidTransformException, NonWellFormedXMLException{

	String trnsfrmStr = getContentsOfURL(source);
	return transformAndReturnString(trnsfrmStr, sourceXML); 

    } /* transformAndReturnString(URL, String) */


    /**
     * Gets the name of the service. 
     * @return the name of the service. 
     */
    public String getName(){

	return "XsltTransformService"; 
    }

    /*=================================================================*/
    /*                 S T A T I C        M E T H O D S                */
    /*=================================================================*/

    /**
     * Obtains the contents at a particular URL and returns them as a string. 
     * @param source the URL to obtaion the data from. 
     * @return the contents at the specified URL. 
     * @exception IOException if an error occurs while trying to retrieve the file.
     */
    public static String getContentsOfURL(URL source) throws IOException{

	BufferedReader reader = new BufferedReader(new InputStreamReader(source.openStream()));
	StringBuffer dest = new StringBuffer(""); 
	String s=null;  	
	
	while((s = reader.readLine()) != null){  dest.append(s); }

	return dest.toString();

    }/* getContentsOfURL(URL) */


  /**
     * Main used for testing class. 
     * @param args IGNORED
     */
    public static void main(String[] args) throws Exception{

	
	String driver = "org.sixdml.xindice.xiSixdmlDatabase";
	Class c = Class.forName(driver);
	org.sixdml.SixdmlDatabase database = (org.sixdml.SixdmlDatabase) c.newInstance(); 
	org.xmldb.api.DatabaseManager.registerDatabase(database); 

	SixdmlResource resource = (SixdmlResource) database.getResource("xindice:///db/addressbook/address1", "", ""); 

	String interimResults; 

	org.sixdml.query.SixdmlQueryService queryManager = 
	    (org.sixdml.query.SixdmlQueryService) database.getService("SixdmlQueryService", "1.0"); 

	/* query a document */
	org.sixdml.query.SixdmlXpathObject sxo = queryManager.executeQuery("/*", resource);  

	if (sxo.getType() == org.sixdml.query.SixdmlXpathObject.NODESET)
	    interimResults = sxo.getNodeSetAsXML(); 
	else
	    interimResults = sxo.getObjectAsString(); 	

	SixdmlTransformService transformer = 
	    (SixdmlTransformService) database.getService("XsltTransformService", "1.0"); 

	//print phone numbers of all persons
	String xsltString  = "<?xml version=\"1.0\"?>\n" + 
	    "<xsl:stylesheet xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" version=\"1.0\">\n" +
	    "<xsl:template match=\"/person\">" + 	    	    
	    "<xsl:value-of select=\"concat(fname,lname)\" />" + 
	    "<xsl:text>&#xa;</xsl:text><xsl:for-each select=\"phone\">" + 
	    "<xsl:value-of select=\".\" /><xsl:text>&#xa;</xsl:text>" + 
	    "</xsl:for-each></xsl:template></xsl:stylesheet>";

	String transformedXML =  
	    transformer.transformAndReturnString(xsltString, interimResults);  

	System.out.println(transformedXML);
    }
    
} // xiXsltTransformService
