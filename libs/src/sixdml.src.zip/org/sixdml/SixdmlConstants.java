package org.sixdml;

/**
 * <PRE>
 * SixdmlConstants.java
 * 
 * Contains constants used by all classes in the package. 
 * Created: Thu Jan 10 23:04:17 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 */


public interface SixdmlConstants  {

    /**
     * SiXDML namespace. 
     */
    String SIXDML_NS = "http://www.25hoursaday.com/sixdml/";

    /**
     * The version of the application. 
     */
    String SIXDML_VERSION = "1.0"; 

    
} // SixdmlConstants
