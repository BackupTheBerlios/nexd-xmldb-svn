package org.sixdml.test;

import java.io.StringReader;

import junit.framework.TestCase;
import java.io.StringReader;
import junit.framework.*;
import junit.extensions.*;
import org.sixdml.parser.*;
import org.xmldb.api.DatabaseManager;
import org.sixdml.SixdmlDatabase;
import org.sixdml.dbmanagement.*;


/**
 * @author administrator
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class AddressBookParserTest extends TestCase {

	String driver = "org.sixdml.xindice.xiSixdmlDatabase";
	SixdmlDatabase database;
	/**
	 * Constructor for AddressBookParserTest.
	 * @param arg0
	 */
	public AddressBookParserTest(String arg0) {
		super(arg0);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(AddressBookParserTest.class);
	}

	/**
	 * @see TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();

		Class c = Class.forName(driver);
		database = (org.sixdml.SixdmlDatabase) c.newInstance();
		DatabaseManager.registerDatabase(database);

	}

	/**
	 * @see junit.framework.TestCase#tearDown()
	 */
	/**
	 * @see TestCase#tearDown()
	 */
	protected void tearDown() throws Exception {
		super.tearDown();

		DatabaseManager.deregisterDatabase(database);
	}

	
	public void testSelect() throws Exception {
	
	StringBuffer strBuf = new StringBuffer(""); 	
	String command      = "SELECT /* FROM COLLECTION /db/addressbook ;";

	SixdmlLexer lexer  = new SixdmlLexer(new StringReader(command)); 
	SixdmlParser parser = new SixdmlParser(lexer);
	parser.sixdmlStatements(strBuf, driver);
	System.out.println(strBuf); 
	}
	

}
