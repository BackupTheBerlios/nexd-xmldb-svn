package org.sixdml.test;
import org.xmldb.api.base.*;
import org.xmldb.api.modules.*;
import org.xmldb.api.*;


import junit.framework.TestCase;

/**
 * @author administrator
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class xiSixdmlCollectionTest extends TestCase {

	/**
	 * Constructor for xiSixdmlCollectionTest.
	 * @param arg0
	 */
	public xiSixdmlCollectionTest(String arg0) {
		super(arg0);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(xiSixdmlCollectionTest.class);
	}

	public void testCollection() throws Exception{
        Collection col = null;
      try {
         String driver = "org.apache.xindice.client.xmldb.DatabaseImpl";
         Class c = Class.forName(driver);

         Database database = (Database) c.newInstance();
         DatabaseManager.registerDatabase(database);

         col = DatabaseManager.getCollection("xmldb:xindice:///db/addressbook");

         String xpath = "//person[fname='John']";
         XPathQueryService service =
            (XPathQueryService) col.getService("XPathQueryService", "1.0");
         ResourceSet resultSet = service.query(xpath);
         ResourceIterator results = resultSet.getIterator();
         while (results.hasMoreResources()) {
            Resource res = results.nextResource();
            System.out.println((String) res.getContent());
         }
      }
      catch (XMLDBException e) {
         System.err.println("XML:DB Exception occured " + e.errorCode);
         fail();
      }
      
      finally {
         if (col != null) {
            col.close();
         }
      }

        
        }

	public void testAddIndex() {
	}

	public void testClose() {
	}

	public void testCreateId() {
		
	}

	public void testCreateResource() {
	}

	public void testGetChildCollection() {
	}

	public void testGetChildCollectionCount() {
	}

	public void testGetIndices() {
	}

	public void testGetName() {
	}

	public void testGetParentCollection() {
	}

	public void testGetProperty() {
	}

	public void testGetResource() {
	}

	public void testGetResourceCount() {
	}

	public void testGetService() {
	}

	public void testGetServices() {
	}

	/*
	 * Test for void insertDocument(String, String)
	 */
	public void testInsertDocumentStringString() {
	}

	/*
	 * Test for void insertDocument(String, URL)
	 */
	public void testInsertDocumentStringURL() {
	}

	public void testIsOpen() {
	}

	public void testListChildCollections() {
	}

	public void testListResources() {
	}

	public void testRemoveDocument() {
	}

	public void testRemoveIndex() {
	}

	public void testRemoveResource() {
	}

	public void testSetProperty() {
	}

	public void testSetSchema() {
	}

	public void testShowSchema() {
	}

	public void testStoreResource() {
	}

	public void testUnsetSchema() {
	}

}
