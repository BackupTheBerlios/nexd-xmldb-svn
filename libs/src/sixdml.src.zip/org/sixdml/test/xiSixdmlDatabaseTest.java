package org.sixdml.test;

import junit.framework.TestCase;

import org.sixdml.SixdmlDatabase;
import org.sixdml.dbmanagement.SixdmlTransactionService;
import org.xmldb.api.DatabaseManager;
import org.xmldb.api.base.Collection;
import org.xmldb.api.base.Database;

/**
 * @author administrator
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class xiSixdmlDatabaseTest extends TestCase {

	String driver = "org.sixdml.xindice.xiSixdmlDatabase";

	/**
	 * Constructor for xiSixdmlDatabaseTest.
	 * @param arg0
	 */
	public xiSixdmlDatabaseTest(String arg0) {
		super(arg0);
	}

	public void testCreate() {

		try {
			Class c = Class.forName(driver);

			SixdmlDatabase database = (SixdmlDatabase) c.newInstance();
		} catch (Exception e) {
			fail();
		}
	}

	public void testTransaction() throws Exception {
		Class c = Class.forName(driver);

		SixdmlDatabase database = (SixdmlDatabase) c.newInstance();
		DatabaseManager.registerDatabase(database);
		SixdmlTransactionService ts =
			(SixdmlTransactionService) database.getService(
				"SixdmlTransactionService",
				"1.0");

		assertTrue(ts!=null);
		ts.begin();
	
		assertTrue(ts.isActive());

		ts.commit();

		assertTrue(!ts.isActive());

	}
	public void testRegister() {
		try {
			Class c = Class.forName(driver);

			SixdmlDatabase database = (SixdmlDatabase) c.newInstance();
			DatabaseManager.registerDatabase(database);

		} catch (Exception e) {
			e.printStackTrace();
			fail();
		}
	}
	public void testGetCollection() throws Exception {
		Class c = Class.forName(driver);

		SixdmlDatabase database = (SixdmlDatabase) c.newInstance();
		DatabaseManager.registerDatabase(database);

		//DatabaseManager.getDatabase("xmldb:sixdml");

		Database[] db = DatabaseManager.getDatabases();
		
		assertTrue(db.length==1);
		
		Collection col =
			DatabaseManager.getCollection(
				"xindice:///db/addressbook");

		assertTrue(col!=null);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(xiSixdmlDatabaseTest.class);
	}

	public void testXiSixdmlDatabase() {
	}

	public void testGetResource() {
	}

	public void testCreateIndex() {
	}

	public void testGetSupportedIndexTypes() {
	}

	public void testGetSupportedTransformTypes() {
	}

	public void testGetServices() {
	}

	public void testGetService() {
	}

	public void testAcceptsURI() {
	}

	public void testGetConformanceLevel() {
	}

	public void testGetName() {
	}

	public void testGetProperty() {
	}

	public void testSetProperty() {
	}

}
