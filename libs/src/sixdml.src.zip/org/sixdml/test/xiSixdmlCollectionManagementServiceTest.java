package org.sixdml.test;

import org.sixdml.dbmanagement.SixdmlCollectionManagementService;

import junit.framework.TestCase;
import junit.framework.TestCase;

import org.sixdml.SixdmlDatabase;
import org.sixdml.dbmanagement.SixdmlTransactionService;
import org.xmldb.api.DatabaseManager;
import org.xmldb.api.base.Collection;
import org.xmldb.api.base.Database;
import org.xmldb.api.base.XMLDBException;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * @author administrator
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class xiSixdmlCollectionManagementServiceTest extends TestCase {

	String driver = "org.sixdml.xindice.xiSixdmlDatabase";
	
	String colName = "xiSixdmlCollectionManagementServiceTest";

	SixdmlCollectionManagementService scm;
	/**
	 * Constructor for xiSixdmlCollectionManagementServiceTest.
	 * @param arg0
	 */
	public xiSixdmlCollectionManagementServiceTest(String arg0) {
		super(arg0);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(
			xiSixdmlCollectionManagementServiceTest.class);
	}

	public void setUp() throws Exception {
		Class c = Class.forName(driver);

		SixdmlDatabase database = (SixdmlDatabase) c.newInstance();
		DatabaseManager.registerDatabase(database);
		
		
		scm = (SixdmlCollectionManagementService) database.getService("SixdmlCollectionManagementService", "1.0");
		scm.createCollection(colName, new URL("http://test.xsd"));		
			
	}
	
	public void tearDown() throws Exception {
		scm.removeCollection(colName);
	}
	

	public void testXiSixdmlCollectionManagementService() {
	}

	public void testCreateCollection() throws Exception {
		
		
		
	}

	public void testRemoveCollection() {
	}

	public void testGetName() {
	}

	public void testGetVersion() {
	}

	public void testSetCollection() {
	}

	public void testGetProperty() {
	}

	public void testSetProperty() {
	}

}
