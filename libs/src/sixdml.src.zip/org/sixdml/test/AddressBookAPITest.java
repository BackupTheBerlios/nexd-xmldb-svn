package org.sixdml.test;

import java.net.URL;

import junit.framework.TestCase;

import org.sixdml.SixdmlDatabase;
import org.sixdml.dbmanagement.SixdmlCollection;
import org.sixdml.dbmanagement.SixdmlResource;
import org.sixdml.query.SixdmlQueryService;
import org.sixdml.query.SixdmlXpathObject;
import org.sixdml.xindice.xiSixdmlCollection;
import org.xmldb.api.DatabaseManager;
import org.xmldb.api.base.Collection;

/**
 * @author administrator
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class AddressBookAPITest extends TestCase {

	String driver = "org.sixdml.xindice.xiSixdmlDatabase";
	SixdmlDatabase database;

	/**
	 * Constructor for AddressBookTestTest.
	 * @param arg0
	 */
	public AddressBookAPITest(String arg0) {
		super(arg0);
	}

	public static void main(String[] args) {
		junit.textui.TestRunner.run(AddressBookAPITest.class);
	}

	/**
	 * @see TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();

		Class c = Class.forName(driver);
		database = (org.sixdml.SixdmlDatabase) c.newInstance();
		DatabaseManager.registerDatabase(database);

	}

	/**
	 * @see junit.framework.TestCase#tearDown()
	 */
	/**
	 * @see TestCase#tearDown()
	 */
	protected void tearDown() throws Exception {
		super.tearDown();

		DatabaseManager.deregisterDatabase(database);
	}

	public void testGetCollectionSucceed() throws Exception {

		Collection col =
			DatabaseManager.getCollection("xmldb:xindice:///db/addressbook");
		System.out.println(col.getName());

	}

	public void testGetCollectionFail() throws Exception {

		try {
			Collection col =
				DatabaseManager.getCollection(
					"xmldb:xindice:///db/address123book");
			System.out.println(col.getName());
		}
		catch (Exception e) {
			return;
		}

		fail();

	}

	public void testValidationSucceed() throws Exception {

		SixdmlCollection col =
			(SixdmlCollection) database.getCollection(
				"xindice:///db/addressbook",
				"",
				"");

		System.out.println(col.getName());

		System.out.println("Setting schema...");
		col.setSchema(new URL("http://www.25hoursaday.com/books.xsd"));

		SixdmlResource resource =
			(SixdmlResource) col.createResource("books", "XMLResource");
		resource.setContent(
			xiSixdmlCollection.getContentsOfURL(
				new URL("http://www.25hoursaday.com/books.xml")));
		System.out.println(resource.getName());

		col.storeResource(resource);
		resource = (SixdmlResource) col.getResource("books");
		System.out.println(resource.getContent());
		System.out.println("Validation of 'books' Succeeded As Expected");

	}

	public void testValidationFail() throws Exception {

		SixdmlCollection col =
			(SixdmlCollection) database.getCollection(
				"xindice:///db/addressbook",
				"",
				"");

		System.out.println(col.getName());

		System.out.println("Setting schema...");
		col.setSchema(new URL("http://www.25hoursaday.com/books.xsd"));

		try {
			SixdmlResource resource2 =
				(SixdmlResource) col.createResource("title", "XMLResource");

			resource2.setContent(
				xiSixdmlCollection.getContentsOfURL(
					new URL("http://www.25hoursaday.com/title.xsl")));
			System.out.println(resource2.getName());
			System.out.println(resource2.getContent());

			col.storeResource(resource2);

		}
		catch (Exception e) {

			System.out.println("Validation of 'title' Failed As Expected");
			return;
		}

		fail(); //title should not validate

	}

	private String executeAddressBookQuery(String query) throws Exception {

		SixdmlResource resource =
			(SixdmlResource) database.getResource(
				"xindice:///db/addressbook/address1",
				"",
				"");

		String interimResults;

		SixdmlQueryService queryManager =
			(SixdmlQueryService) database.getService(
				"SixdmlQueryService",
				"1.0");

		/* query a document */
		SixdmlXpathObject sxo = queryManager.executeQuery(query, resource);

		if (sxo.getType() == SixdmlXpathObject.NODESET)
			interimResults = sxo.getNodeSetAsXML();
		else
			interimResults = sxo.getObjectAsString();

		return interimResults;

	}

	public void testAddressBookQuery1() throws Exception{
		String results = executeAddressBookQuery("/person/fname");
		if(!results.equals("<fname>John</fname>")) fail();
		
	}
}
