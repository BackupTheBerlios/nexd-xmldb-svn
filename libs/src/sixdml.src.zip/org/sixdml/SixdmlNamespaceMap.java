package org.sixdml; 
import org.sixdml.SixdmlConstants;
import java.util.HashMap; 
import java.util.Set; 
import java.util.Iterator; 
import java.util.Map;
import java.util.Map.Entry;
import org.sixdml.query.SixdmlQueryService;
import org.sixdml.update.SixdmlUpdateService;
// import java.net.URI; Java 1.4 

/**
 * <PRE>  
 * SixdmlNamespaceMap.java
 * A hashtable containing mappings between prefixes and namespace URIs
 * for use by the <code>SixdmlQueryService</code> and <code>SixdmlUpdateService</a> classes. 
 * <BR>This class is <B>not</B> thread-safe. 
 *
 * Created: Tue Feb 04 02:49:16 2002
 *
 * </PRE>  
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 * @see SixdmlQueryService
 * @see SixdmlUpdateService
 */

public class SixdmlNamespaceMap implements SixdmlConstants{
    
    /*=================================================================*/
    /*                I N S T A N C E    V A R I A B L E S             */
    /*=================================================================*/
       

    /**
     * This is the table of containing mappings of prefixes to namespace URI. 
     */
    private HashMap namespaceTable = new HashMap(); 


    
    /*=================================================================*/
    /*                        C O N S T R U C T O R S                  */
    /*=================================================================*/

    /**
     * Default constructor initializes class.
     */
    public SixdmlNamespaceMap() {;}       


    /*=================================================================*/
    /*                I N S T A N C E       M E T H O D S              */
    /*=================================================================*/   
   
     
    
    /**
     * Removes all mappings from this map. 
     */
    public void clear(){

	namespaceTable.clear(); 
    }

    /**
     * Returns true if this map contains a mapping for the specified key. 
     * @param prefix The key whose presence in this map is to be tested. The key should 
     * be a namespace prefix. 
     * @return true if this map contains a mapping for the specified key.
     */
    public boolean containsKey(String prefix){

	return namespaceTable.containsKey(prefix); 
    }


    /**
     * Returns true if this map contains a mapping for the specified value. 
     * @param namespaceURI The value whose presence in this map is to be tested. The value should 
     * be a URI. 
     * @return true if this map contains a mapping for the specified value.
     */
    //  public boolean containsValue(URI value){ Java 1.4 
    public boolean containsValue(String namespaceURI){

	return namespaceTable.containsValue(namespaceURI); 
    }
    
    /**
     * Returns true if this map contains no key-value mappings. 
     * @return true if this map contains no key-value mappings
     */
    public boolean isEmpty(){

	return namespaceTable.isEmpty(); 
    }

    /**
     * Returns the number of key-value mappings in this map. 
     * @return the number of key-value mappings in this map.
     */
    public int size(){

	return namespaceTable.size(); 
    }

    /**
     * Returns a collection view of the mappings contained in this map. Each element in 
     * the returned collection is a Map.Entry. The collection is backed by the map, so 
     * changes to the map are reflected in the collection, and vice-versa. 
     * @return  collection view of the mappings contained in this map.
     * @see java.util.Map.Entry
     */
    public Set entrySet(){

	return namespaceTable.entrySet(); 
    }

    /**
     * Returns the value to which the specified key is mapped in this identity hash map, 
     * or null if the map contains no mapping for this key. A return value of null does not 
     * necessarily indicate that the map contains no mapping for the key; it is also possible 
     * that the map explicitly maps the key to null. The containsKey method may be used to 
     * distinguish these two cases. 
     * @param prefix  the key whose associated value is to be returned. The key should be a 
     * prefix associated with a particular namespace URI. 
     * @return the namespace URI to which this map maps the specified prefix, or null if the map 
     * contains no mapping for this key.
     */
    /*    public URI get(String key){

	return (URI) namespaceTable.get(key); 
	} Java 1.4 */
    public String get(String prefix){
	
	return (String) namespaceTable.get(prefix); 
    } 

    /**
     * Associates the specified value with the specified key in this map. If the map 
     * previously contained a mapping for this key, the old value is replaced. 
     * @param prefix key with which the specified value is to be associated.
     * @param namespaceURI value to be associated with the specified key. 
     * @return previous namespace URI associated with specified prefix, or null if there 
     * was no mapping for the prefix. 
     * A null return can also indicate that the Map previously associated null with the 
     * specified key.
     */
    /* public URI put(String prefix, URI namespaceURI){

	return (URI) namespaceTable.put(prefix, namespaceURI); 
	} Java 1.4 */
    public String put(String prefix, String namespaceURI){
	
	return (String) namespaceTable.put(prefix, namespaceURI); 
    }

    /**
     * Removes the mapping for this key from this map if present. 
     * @param prefix key whose mapping is to be removed from the map. 
     * @return previous value associated with specified key, or null if there 
     * was no mapping for key. A null return can also indicate that the map 
     * previously associated null with the specified key.
     */
    /* public URI remove(String prefix){

	return (URI) namespaceTable.remove(prefix); 
    } Java 1.4*/ 
    public String remove(String prefix){
	
	return (String) namespaceTable.remove(prefix); 
    }

    
} // SixdmlNamespaceMap
