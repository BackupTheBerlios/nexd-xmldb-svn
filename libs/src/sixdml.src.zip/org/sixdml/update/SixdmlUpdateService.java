package org.sixdml.update;
import org.xmldb.api.base.Service;
import org.xmldb.api.base.XMLDBException;
import org.sixdml.exceptions.*;
import org.w3c.dom.Node;
//import java.net.URI; Java 1.4
import org.sixdml.dbmanagement.SixdmlCollection;
import org.sixdml.dbmanagement.SixdmlResource; 
import org.w3c.dom.NodeList;
import org.sixdml.SixdmlNamespaceMap;


/**
 * <PRE>
 * SixdmlUpdateService.java
 *
 * This is a Service that enables the execution of updates within the context of a 
 * Collection or against the documents stored in the Collection.
 *
 * Created: Fri Jan 11 11:55:20 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 */


public interface SixdmlUpdateService extends Service {

     
    
     /**
     * Set the SixdmlNamespaceMap used by this class to map prefixes to namespace URIs used 
     * in XPath queries. 
     * @param nsMap the new namespace map to use. 
     * @exception XMLDBException if anything goes wrong. 
     */
    void setNamespaceMap(SixdmlNamespaceMap nsMap) throws XMLDBException; 

    /**
     * Add a mapping between a given prefix and a namespace to the service's internal namespace 
     * map. 
     * @param prefix key with which the specified namespace URI is associated.
     * @param namespaceURI value to be associated with the specified prefix. 
     * @exception XMLDBException if anything goes wrong. 
     */
    //void addNamespaceMapping(String prefix, URI namespaceURI) throws XMLDBException; Java 1.4
    void addNamespaceMapping(String prefix, String namespaceURI) throws XMLDBException; 
  
    /**
     * Remove a mapping between a given prefix and a namespace to the service's internal namespace 
     * map. 
     * @param prefix key with which the specified namespace URI is associated.    
     * @exception XMLDBException if anything goes wrong. 
     */
    void removeNamespaceMapping(String prefix) throws XMLDBException; 

    /**
     * Clear all namespace mappings in the service's internal namespace map. 
     * @exception XMLDBException if anything goes wrong. 
     */
    void clearNamespaceMappings() throws XMLDBException;

    /**
     * Obtain the namespace URI mapped to a particular prefix. 
     * @param prefix the prefix whose namespace is being sought. 
     * @return the namespace URI mapped to the prefix or null if the map contains 
     * no mapping for this prefix.
     */
    //URI getNamespaceMapping(String prefix) throws XMLDBException; Java 1.4
    String getNamespaceMapping(String prefix) throws XMLDBException; 


    /**
     * Inserts an XML fragment as a sibling of each of the nodes returned from the XPath query. 
     * A boolean flag indicates whether the new node will be inserted before or after the 
     * selected nodes.     
     * @param query The query which selects the nodes to update
     * @param fragment The XML fragment to insert
     * @param resource the document to perform the update against 
     * @param before if this is true then the new node wil be inserted before each of the selected node
     * while if it is false the new node will be inserted after the selected nodes in the tree.  
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException if the target node is the document root and an attempt is 
     * made to insert anything besides comments or processing instructions. 
     * @exception NonWellFormedXMLException if the XML fragment is not a valid XML fragment. 
     */
    int insertSibling(String query, String fragment,SixdmlResource resource, boolean before)
	throws XMLDBException, InvalidQueryException, NonWellFormedXMLException, UpdateTypeMismatchException; 


    /**
     * Inserts an XML fragment as a child of each of the nodes returned from the XPath query. 
     * A boolean flag indicates whether the new node will be inserted before or after the 
     * selected nodes. The new node is appended to the end of the current children of the 
     * selected node. 
     * @param query The query which selects the nodes to update
     * @param fragment The XML fragment to insert
     * @param resource the document to perform the update against 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node, document node
     * or set of element nodes. 
     * @exception NonWellFormedXMLException if the XML fragment is not a valid XML fragment. 
     */
    int insertChild(String query, String fragment,SixdmlResource resource)
	throws XMLDBException, InvalidQueryException, NonWellFormedXMLException, UpdateTypeMismatchException; 


    /**
     * Inserts a node as a sibling of each of the nodes returned from the XPath query. 
     * A boolean flag indicates whether the new node will be inserted before or after the 
     * selected nodes.     
     * @param query The query which selects the nodes to update
     * @param nodes The DOM node(s) to insert
     * @param resource the document to perform the update against 
     * @param before if this is true then the new node wil be inserted before each of the selcted node
     * while if it is false the new node will be inserted after the selected nodes in the tree.  
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException if the target node is the document root and an attempt is 
     * made to insert anything besides comments or processing instructions. 
     */
    int insertSibling(String query, NodeList nodes,SixdmlResource resource, boolean before)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException; 


    /**
     * Inserts a node as a child of each of the nodes returned from the XPath query. 
     * A boolean flag indicates whether the new node will be inserted before or after the 
     * selected nodes. The new node is appended to the end of the current children of the 
     * selected node. 
     * @param query The query which selects the nodes to update
     * @param nodes The DOM node(s) to insert
     * @param resource the document to perform the update against 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node, document node
     * or set of element nodes. 
     */
    int insertChild(String query, NodeList nodes,SixdmlResource resource)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException; 


    
    /**
     * Inserts an attribute node as a child of each of the nodes returned from the XPath query.     
     * @param query The query which selects the nodes to update
     * @param resource the document to perform the update against 
     * @param name The name of the attribute to insert. 
     * @param value the value of the attribute to insert.  
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node
     * or set of element nodes. 
     */
    int insertAttribute(String query, SixdmlResource resource, String name, String value)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException; 

    /**
     * Inserts an attribute node as a child of each of the nodes returned from the XPath query.     
     * @param query The query which selects the nodes to update
     * @param resource the document to perform the update against 
     * @param name The name of the attribute to insert. It should be an XML qualified name. 
     * @param value the value of the attribute to insert.     
     * @param namespaceURI the namsepace URI for the attribute node
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node
     * or set of element nodes. 
     */
    int insertAttribute(String query, SixdmlResource resource, String name, String value, 
			 String namespaceURI)
			 //	  URI namespaceURI) Java 1.4
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException; 

    /**
     * Deletes all nodes that match the expression from the target document. 
     * @param query The query which selects the nodes to delete. 
     * @param resource the document to perform the update against 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid.
     * @exception UpdateTypeMismatchException if no nodes matching the query are found. 
     */
    int delete(String query, SixdmlResource resource)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException; 
     
    /**
     * Replaces one or more element, processing-instruction, comment, or text nodes with the new node.
     * @param query The query which selects the nodes to update
     * @param nodes The DOM node(s) to insert
     * @param resource the document to perform the update against 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not one or more comment, text, 
     * processing-instruction, or element nodes. 
     */
    int replace(String query, NodeList nodes, SixdmlResource resource)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException; 

    /**
     * Replaces one or more element, processing-instruction, comment, or text nodes with the new node.
     * @param query The query which selects the nodes to update
     * @param fragment the XML fragment to insert. 
     * @param resource the document to perform the update against 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not one or more comment, text, 
     * processing-instruction, or element nodes. 
     * @exception NonWellFormedXMLException if the XML fragment is not a valid XML fragment. 
     */
    int replace(String query, String fragment , SixdmlResource resource)
	throws XMLDBException, InvalidQueryException, NonWellFormedXMLException, UpdateTypeMismatchException; 

    /**
     * Renames one or more attribute or element nodes.
     * @param query The query which selects the nodes to update
     * @param name The new name
     * @param namespaceURI the namespace URI for the element being inserted. If it is null 
     * then it is assumed the new item has no namespace URI.  
     * @param resource the document to perform the update against 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not one or more attribute or 
     * element nodes.
     */
    //int rename(String query, String name, URI namespaceURI, SixdmlResource resource) Java 1.4
    int rename(String query, String name, String namespaceURI, SixdmlResource resource)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException; 


    /**
     * Inserts an XML fragment as a sibling of each of the nodes returned from the XPath query. 
     * A boolean flag indicates whether the new node will be inserted before or after the 
     * selected nodes.     
     * @param query The query which selects the nodes to update
     * @param fragment The XML fragment to insert
     * @param collection the collection whose documents to perform the update against 
     * @param before if this is true then the new node wil be inserted before each of the selected node
     * while if it is false the new node will be inserted after the selected nodes in the tree.  
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException if the target node is the document root and an attempt is 
     * made to insert anything besides comments or processing instructions. 
     * @exception NonWellFormedXMLException if the XML fragment is not a valid XML fragment. 
     */
    int insertSibling(String query, String fragment,SixdmlCollection collection, boolean before)
	throws XMLDBException, InvalidQueryException, NonWellFormedXMLException, UpdateTypeMismatchException; 


    /**
     * Inserts an XML fragment as a child of each of the nodes returned from the XPath query. 
     * A boolean flag indicates whether the new node will be inserted before or after the 
     * selected nodes. The new node is appended to the end of the current children of the 
     * selected node. 
     * @param query The query which selects the nodes to update
     * @param fragment The XML fragment to insert
     * @param collection the collection whose documents to perform the update against 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node, document node
     * or set of element nodes. 
     * @exception NonWellFormedXMLException if the XML fragment is not a valid XML fragment. 
     */
    int insertChild(String query, String fragment,SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException, NonWellFormedXMLException, UpdateTypeMismatchException; 


    /**
     * Inserts a node as a sibling of each of the nodes returned from the XPath query. 
     * A boolean flag indicates whether the new node will be inserted before or after the 
     * selected nodes.     
     * @param query The query which selects the nodes to update
     * @param node The DOM node(s) to insert
     * @param collection the collection whose documents to perform the update against 
     * @param before if this is true then the new node wil be inserted before each of the selcted node
     * while if it is false the new node will be inserted after the selected nodes in the tree.  
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException if the target node is the document root and an attempt is 
     * made to insert anything besides comments or processing instructions. 
     */
    int insertSibling(String query, NodeList nodes,SixdmlCollection collection, boolean before)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException; 


    /**
     * Inserts a node as a child of each of the nodes returned from the XPath query. 
     * A boolean flag indicates whether the new node will be inserted before or after the 
     * selected nodes. The new node is appended to the end of the current children of the 
     * selected node. 
     * @param query The query which selects the nodes to update
     * @param node The DOM node(s) to insert
     * @param collection the collection whose documents to perform the update against 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node, document node
     * or set of element nodes. 
     */
    int insertChild(String query, NodeList nodes,SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException; 


    
    /**
     * Inserts an attribute node as a child of each of the nodes returned from the XPath query.     
     * @param query The query which selects the nodes to update
     * @param collection the collection whose documents to perform the update against 
     * @param name The name of the attribute to insert. 
     * @param value the value of the attribute to insert.  
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node
     * or set of element nodes. 
     */
    int insertAttribute(String query, SixdmlCollection collection, String name, String value)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException; 

    /**
     * Inserts an attribute node as a child of each of the nodes returned from the XPath query.     
     * @param query The query which selects the nodes to update
     * @param collection the collection whose documents to perform the update against 
     * @param name The name of the attribute to insert. It should be an XML qualified name. 
     * @param value the value of the attribute to insert.     
     * @param namespaceURI the namsepace URI for the attribute node
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node
     * or set of element nodes. 
     */
    int insertAttribute(String query, SixdmlCollection collection, String name, String value, 
			 String namespaceURI)
			 //URI namespaceURI) Java 1.4			 
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException; 

    /**
     * Deletes all nodes that match the expression from the target document. 
     * @param query The query which selects the nodes to delete. 
     * @param collection the collection whose documents to perform the update against 
      * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid.    
     */
    int delete(String query, SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException; 
     
    /**
     * Replaces one or more element, processing-instruction, comment, or text nodes with the new node.
     * @param query The query which selects the nodes to update
     * @param nodes The DOM node(s) to insert
     * @param collection the collection whose documents to perform the update against 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not one or more comment, text, 
     * processing-instruction, or element nodes. 
     */
    int replace(String query, NodeList nodes, SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException; 

    /**
     * Replaces one or more element, processing-instruction, comment, or text nodes with the new node.
     * @param query The query which selects the nodes to update
     * @param fragment the XML fragment to insert. 
     * @param collection the collection whose documents to perform the update against 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not one or more comment, text, 
     * processing-instruction, or element nodes. 
     * @exception NonWellFormedXMLException if the XML fragment is not a valid XML fragment. 
     */
    int replace(String query, String fragment , SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException, NonWellFormedXMLException , UpdateTypeMismatchException; 

    /**
     * Renames one or more attribute or element nodes.
     * @param query The query which selects the nodes to update
     * @param name The new name
     * @param namespaceURI the namespace URI for the element being inserted. If it is null 
     * then it is assumed the new item has no namespace URI.  
     * @param collection the collection whose documents to perform the update against 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException   if the target node is not one or more attribute or 
     * element nodes.
     */
    //int rename(String query, String name, URI namespaceURI, SixdmlCollection collection) Java 1.4
    int rename(String query, String name, String namespaceURI, SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException; 
   
     /**
     * Inserts an XML fragment as a child of each of the nodes returned from the XPath query. 
     * The new node is appended to the end of the current children of the 
     * selected node. 
     * @param query The query which selects the nodes to update
     * @param fragment The XML fragment to insert
     * @param collection the collection whose documents to perform the update against 
     * @param predicate a filter expression used to determine which documents to update within the collection. 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node, document node
     * or set of element nodes. 
     * @exception NonWellFormedXMLException if the XML fragment is not a valid XML fragment. 
     */
    public int insertChild(String query, String predicate, String fragment,SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException, NonWellFormedXMLException, UpdateTypeMismatchException;


     /**
     * Inserts a node as a child of each of the nodes returned from the XPath query. 
     * The new node is appended to the end of the current children of the 
     * selected node. 
     * @param query The query which selects the nodes to update
     * @param nodes The DOM node(s) to insert
     * @param collection the collection whose documents to perform the update against 
     * @param predicate a filter expression used to determine which documents to update within the collection. 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node, document node
     * or set of element nodes. 
     */
    public int insertChild(String query, String predicate, NodeList nodes,SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException;

    /**
     * Inserts a node as a sibling of each of the nodes returned from the XPath query. 
     * A boolean flag indicates whether the new node will be inserted before or after the 
     * selected nodes.     
     * @param query The query which selects the nodes to update
     * @param nodes The DOM node(s) to insert
     * @param collection the collection whose documents to perform the update against 
     * @param before if this is true then the new node wil be inserted before each of the selcted node
     * while if it is false the new node will be inserted after the selected nodes in the tree.  
     * @param predicate a filter expression used to determine which documents to update within the collection. 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException if the target node is the document root and an attempt is 
     * made to insert anything besides comments or processing instructions. 
     */
    public int insertSibling(String query, String predicate, NodeList nodes,SixdmlCollection collection, boolean before)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException;

      /**
     * Inserts an XML fragment as a sibling of each of the nodes returned from the XPath query. 
     * A boolean flag indicates whether the new node will be inserted before or after the 
     * selected nodes.     
     * @param query The query which selects the nodes to update
     * @param fragment The XML fragment to insert
     * @param collection the collection whose documents to perform the update against 
     * @param before if this is true then the new node wil be inserted before each of the selected node
     * while if it is false the new node will be inserted after the selected nodes in the tree.  
     * @param predicate a filter expression used to determine which documents to update within the collection. 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException if the target node is the document root and an attempt is 
     * made to insert anything besides comments or processing instructions. 
     * @exception NonWellFormedXMLException if the XML fragment is not a valid XML fragment. 
     */
    public int insertSibling(String query, String predicate, String fragment,SixdmlCollection collection, boolean before)
	throws XMLDBException, InvalidQueryException, NonWellFormedXMLException, UpdateTypeMismatchException;

      /**
     * Inserts an attribute node as a child of each of the nodes returned from the XPath query.     
     * @param query The query which selects the nodes to update
     * @param collection the collection whose documents to perform the update against 
     * @param name The name of the attribute to insert. 
     * @param value the value of the attribute to insert.  
     * @param predicate a filter expression used to determine which documents to update within the collection. 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node
     * or set of element nodes. 
     */
    public int insertAttribute(String query, String predicate, SixdmlCollection collection, String name, String value)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException;

     /**
     * Inserts an attribute node as a child of each of the nodes returned from the XPath query.     
     * @param query The query which selects the nodes to update
     * @param collection the collection whose documents to perform the update against 
     * @param name The name of the attribute to insert. It should be an XML qualified name. 
     * @param value the value of the attribute to insert.     
     * @param namespaceURI the namsepace URI for the attribute node
     * @param predicate a filter expression used to determine which documents to update within the collection. 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not an element node
     * or set of element nodes. 
     */
    public int insertAttribute(String query, String predicate, SixdmlCollection collection, String name, 
				String value, String namespaceURI)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException;

       /**
     * Deletes all nodes that match the expression from the target document. 
     * @param query The query which selects the nodes to delete. 
     * @param collection the collection whose documents to perform the update against 
     * @param predicate a filter expression used to determine which documents to update within the collection. 
     * @return the number of nodes affected by the update. 
     */
    public int delete(String query, String predicate,  SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException;
    
    /**
     * Replaces one or more element, processing-instruction, comment, or text nodes with the new node.
     * @param query The query which selects the nodes to update
     * @param fragment the XML fragment to insert. 
     * @param collection the collection whose documents to perform the update against 
     * @param predicate a filter expression used to determine which documents to update within the collection. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not one or more comment, text, 
     * processing-instruction, or element nodes. 
     * @exception NonWellFormedXMLException if the XML fragment is not a valid XML fragment. 
     * @return the number of nodes affected by the update.     
     */
    public int replace(String query, String predicate, String fragment , SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException, NonWellFormedXMLException , UpdateTypeMismatchException;

     /**
     * Renames one or more attribute or element nodes.
     * @param query The query which selects the nodes to update
     * @param name The new name
     * @param namespaceURI the namespace URI for the element being inserted. If it is null 
     * then it is assumed the new item has no namespace URI.  
     * @param collection the collection whose documents to perform the update against 
     * @param predicate a filter expression used to determine which documents to update within the collection. 
     * @return the number of nodes affected by the update. 
     * @exception XMLDBException if a database error occurs during the insertion.
     * @exception InvalidQueryException if the XPath  query is invalid. 
     * @exception UpdateTypeMismatchException  if the target node is not one or more comment, text, 
     * processing-instruction, or element nodes. 
     */
    public int rename(String query, String predicate, String name, String namespaceURI, SixdmlCollection collection)
	throws XMLDBException, InvalidQueryException, UpdateTypeMismatchException;

} // SixdmlUpdateService


