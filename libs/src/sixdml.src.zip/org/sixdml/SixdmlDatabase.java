package org.sixdml;
import org.sixdml.dbmanagement.SixdmlIndexType;
import org.sixdml.dbmanagement.SixdmlIndex;
import org.sixdml.transform.SixdmlTransformType;
import org.xmldb.api.base.Database;
import org.xmldb.api.base.XMLDBException;
import org.xmldb.api.base.Resource;
import org.xmldb.api.base.Service;
import java.util.HashMap; 
import org.sixdml.exceptions.UnsupportedIndexTypeException;

/**
 * <PRE>
 * SixdmlDatabase.java
 *
 * This is an encapsulation of the database driver functionality that is necessary 
 * to access an XML database that understands SiXDML.
 *
 * Created: Thu Jan 10 17:46:25 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 */


public interface SixdmlDatabase extends Database {
   

    /**
     * Gets the specified resource from the database. 
     * @param name the resource to obtain. 
     * @param username The username to use for authentication to the database or 
     * null if the database does not support authentication.
     * @param password The password to use for authentication to the database or 
     * null if the database does not support authentication.
     * @return the requested resource. 
     */
    Resource getResource(String name, String username, String password) throws XMLDBException;
           

     /**
     * Provides a list of all services known to the collection. If no services are known an 
     * empty list is returned.
     * @return An array of registered Service implementations.
     * @exception XMLDBException if an error occurs. 
     */
    public Service[] getServices() throws XMLDBException;
    
     /**
     * Returns a Service instance for the requested service name and version. If no 
     * Service exists for those parameters a null value is returned. The only valid 
     * name and version number for this implementation are "XSLT" and "1.0" respectively.
     * @param name the name of the service to return. 
     * @param version the version number of the service to return. 
     * @exception XMLDBException if an error occurs. 
     */
    public Service getService(String name, String version) throws XMLDBException; 

} // SixdmlDatabase




