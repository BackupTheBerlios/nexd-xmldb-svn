package org.sixdml;
import org.sixdml.dbmanagement.SixdmlResource;
import org.xmldb.api.base.*;
import java.util.ArrayList;
import java.util.Iterator;
import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilderFactory; 
import javax.xml.parsers.ParserConfigurationException; 


/**
 * <PRE>
 * SixdmlResourceSet.java
 *
 * ResourceSet is a container for a set of resources. This class isn't really a Set, but 
 * instead is more like a Vector.
 *
 * Created: Thu Jan 10 20:46:09 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 */


public class SixdmlResourceSet implements ResourceSet, SixdmlConstants {
    
    /*=================================================================*/
    /*                I N S T A N C E    V A R I A B L E S             */
    /*=================================================================*/
    
    /**
     * This is the collection that holds the Resources.
     */
    private ArrayList resources = new ArrayList();
    
    
    /*=================================================================*/
    /*                        C O N S T R U C T O R S                  */
    /*=================================================================*/

    /**
     * Default constructor. 
     */
     public SixdmlResourceSet() {;}

    /*=================================================================*/
    /*                I N S T A N C E       M E T H O D S              */
    /*=================================================================*/

   
    /**
     * Adds a Resource instance to the set. 
     * @param res the Resource to add. 
     */
    public void addResource(Resource res){
	resources.add(res); 
    }
       
    /**
     *  Removes all Resource instances from the set. 
     */
    public void clear(){
	resources.clear(); 
    }
         
    /**
     *  Returns an iterator over all Resource instances stored in the set. 
     * @return an iterator  over all Resource instances stored in the set. 
     */
    public ResourceIterator getIterator(){

	return new SixdmlResourceIterator(resources.iterator());
    }

    /**
     * Returns a Resource containing an XML representation of all resources 
     * stored in the set. 
     * @return a Resource that contains an XML representation of all the resources in this
     * set. 
     */
    public Resource getMembersAsResource(){
	
	SixdmlResource toReturn = null; 

	try{
	
	Document doc = 
	    DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
	Element rootElem = doc.createElementNS(SIXDML_NS, "sixdml:resource-set"); 
	doc.appendChild(rootElem); 

	Iterator it = resources.iterator(); 
	SixdmlResource resource = null;

	while(it.hasNext()){

	    resource = (SixdmlResource) it.next();
	    rootElem.appendChild(resource.getContentAsDOM());
	}

	toReturn = (SixdmlResource) resource.getClass().newInstance(); 
	toReturn.setContentAsDOM(doc.getDocumentElement()); 	

	

	}catch(ParserConfigurationException pce){ /* Can't create Document instance */
	    
	    System.out.println(pce);
	    pce.printStackTrace(); 

	}catch(XMLDBException xe){ /* DB error on accessing Resources */

	    System.out.println(xe);
	    xe.printStackTrace(); 

	}catch(InstantiationException ie){ /* failed to construct SixdmlResource resource */

	    System.out.println(ie);
	    ie.printStackTrace();

	}catch(IllegalAccessException iae){ /* unable to access SixdmlResource constructor */

	    System.out.println(iae);
	    iae.printStackTrace();

	}finally{

	    return toReturn; 
	    
	}


    }/* getMembersAsResource() */

    /**
     * Returns the Resource instance stored at the index specified by index. 
     * @param index the index from which to return the Resource.
     * @return the Resource at the specified index. 
     * @exception IndexOutOfBoundsException if the index is out of range 
     * (index < 0 || index >= size()).
     */
    public Resource getResource(long index) {
	return (Resource) resources.get((int)index); 
    }

    /**
     * Returns the number of resources contained in the set. 
     * @return the number of resources in the set.
     */
    public long getSize(){
	return resources.size();
    }

    /**
     * Removes the Resource located at index from the set. 
     * @param index the index from which to remove the Resource.
     * @exception IndexOutOfBoundsException if the index is out of range 
     * (index < 0 || index >= size()).
     */    
    public void removeResource(long index){
	resources.remove((int) index);
    }
     
    
	
    /*=================================================================*/
    /*                 S T A T I C        M E T H O D S                */
    /*=================================================================*/

    /**
     * Main used for testing class. 
     * @param args IGNORED
     */
    public static void main(String[] args) {
	
    }
    
} // SixdmlResourceSet
