package org.sixdml.command; 

import org.xmldb.api.base.Service;
import org.xmldb.api.base.XMLDBException;



/**
 * <PRE>
 * SixdmlStatementService.java
 *
 * This is a Service that enables users to create objects for issuing SiXDML statements over the 
 * database. 
 *
 * Created: Mon Feb 25 01:03:24 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 */


public interface SixdmlStatementService extends Service{


    /**
     * Creates an implementation of the <code>SixdmlStatement</code> interface for executing SiXDML 
     * statements over the database. Parameter-less SiXDML statements should be executed via 
     * <code>SixdmlStatement</code> objects although statements that are executed several times may 
     * benefit from using a <code>SixdmlPreparedStatement</code> if the database implements certain 
     * optimizations. 
     * 
     * @return a <code>SixdmlStatement</code> object
     * @exception XMLDBException if a database error occurs. 
     */
    SixdmlStatement createStatement() throws XMLDBException; 

    /**
     * Creates an implementation of the <code>SixdmlPreparedStatement</code> interface for executing
     * parameterized SiXDML statements over the database. <code>SixdmlPreparedStatement</code> objects 
     * are also useful for implementations that support precompilation of SiXDML statements so that 
     * statements that are to be executed multiple times can be stored and precompiled once in a single 
     * object and not many times to increase efficiency. 
     * 
     * @param query this is a SiXDML statement that contains one or more ? as placeholders for an XPath 
     * expression, an XML fragment or post-processing operation (such as an XQuery expression) 
     * 
     * @return a <code>SixdmlPreparedStatement</code> object. 
     * @exception XMLDBException if a database error occurs. 
     */
    SixdmlPreparedStatement prepareStatement(String query) throws XMLDBException; 

}
