package org.sixdml.command; 

import org.xml.sax.helpers.DefaultHandler;
import org.w3c.dom.Document;

import org.xmldb.api.base.XMLDBException;
import org.sixdml.exceptions.SixdmlException;

import java.io.OutputStream; 
import java.io.Writer; 

/**
 * <PRE>
 * SixdmlStatement.java
 *
 * This class is used to execute SiXDML statements over the database.  
 *
 * Created: Sun Feb 24 01:03:24 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 * 
 * @see SixdmlStatementService#createStatement()
 */


public interface SixdmlStatement{

    /**
     * Executes a SiXDML DDL statement such as a CREATE, DROP and CONSTRAIN or update statements such 
     * as RENAME, REPLACE, INSERT and DELETE over the database. 
     * <br><br>
     * <b>Note</b>: INSERTs statements that add documents to a collection are DDL statements not update 
     * statements. 
     * @param statement the update to execute
     * @return an integer signifying the number of nodes affected by the update or 0 if the operation 
     * was a DDL statement. 
     * 
     * @exception SixdmlException if the statement is invalid.
     * @exception XMLDBException  if a database error occurs
     */
    //REMOVED BECAUSE IT REQUIRES A REWRITE OF EXISTING PARSER. 
    //int executeUpdate(String statement)throws XMLDBException, SixdmlException;

 /**
     * Executes a SiXDML statement against the database and returns the results as an XML DOM object. 
     * This method is best used if the results of the statement is XML which is not large. 
     * 
     * @param statement the statement to execute 
     * @return the results of the statement as a DOM object. 
     * 
     * @exception SixdmlException if the statement is invalid.
     * @exception XMLDBException  if a database error occurs
     */ 
    Document execute(String statement) throws XMLDBException, SixdmlException; 

    
     /**
     * Executes a SiXDML statement against the database and feeds the results to a SAX handler. 
     * This method is best used if the results of the statement is XML which may be large and the database 
     * supports streaming of the results. 
     * 
     * @param statement the statement to execute 
     * @param handler a SAX handler which operates on the results of the statement. 
     * 
     * @exception SixdmlException if the statement is invalid.
     * @exception XMLDBException  if a database error occurs
     */ 
    void execute(String statement, DefaultHandler handler) throws XMLDBException, SixdmlException;


    /**
     * Executes a SiXDML statement against the database and writes the results to the specified OutputStream. 
     * This method is best used when the results of the statement are not XML. 
     * 
     * @param statement the statement to execute 
     * @param outputStream the stream to write the results to 
     * 
     * @exception SixdmlException if the statement is invalid.
     * @exception XMLDBException  if a database error occurs
     */ 
    void execute(String statement, OutputStream outputStream) throws XMLDBException, SixdmlException; 

     /**
     * Executes a SiXDML statement against the database and writes the results using the specified writer. 
     * This method is best used when the results of the statement are not XML. 
     * 
     * @param statement the statement to execute 
     * @param writer the writer to send results to  
     * 
     * @exception SixdmlException if the statement is invalid.
     * @exception XMLDBException  if a database error occurs
     */ 
    void execute(String statement, Writer writer) throws XMLDBException, SixdmlException; 


}
