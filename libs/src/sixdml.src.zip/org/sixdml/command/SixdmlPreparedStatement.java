package org.sixdml.command; 

import org.xml.sax.helpers.DefaultHandler;
import org.w3c.dom.Document;

import org.xmldb.api.base.XMLDBException;
import org.sixdml.exceptions.SixdmlException;

import java.io.OutputStream; 
import java.io.Writer; 

/**
 * <PRE>
 * SixdmlPreparedStatement.java
 *
 * This class is used to store and execute pre-compiled SiXDML statements over the database. It is assumed 
 * that implementers of this interface will have the query specified in their constructor. 
 *
 * Created: Sun Feb 24 01:31:41 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 * 
 * @see SixdmlStatementService#prepareStatement(String)
 */


public interface SixdmlPreparedStatement{

    /**
     * Sets the value of the designated parameter with the given object. Implementations are 
     * encouraged to create more specific versions of this method such as setInt, setNode, setString, 
     * and so on. 
     * <br><br>
     * @param paramIndex the index of the parameter whose value is being set. The value 
     * for the first parameter is 1, the second 2, etc
     * @param value the object containing the input parameter value
     * 
     * @exception IndexOutOfBoundsException if the index range is invalid
     * @exception SixdmlException if the statement is invalid.
     * @exception XMLDBException  if a database error occurs
     */
    void setObject(int paramIndex, Object value) throws XMLDBException, SixdmlException;
    

    /**
     * Executes a SiXDML DDL statement such as a CREATE, DROP and CONSTRAIN or update statements such 
     * as RENAME, REPLACE, INSERT and DELETE over the database. 
     * <br><br>
     * <b>Note</b>: INSERTs statements that add documents to a collection are DDL statements not update 
     * statements. 
     * @return an integer signifying the number of nodes affected by the update or 0 if the operation 
     * was a DDL statement. 
     * 
     * @exception SixdmlException if the statement is invalid.
     * @exception XMLDBException  if a database error occurs
     */
    //REMOVED DUE TO REQUIRING PARSER REWRITE 
    //int executeUpdate()throws XMLDBException, SixdmlException;


    /**
     * Executes a SiXDML statement against the database and returns the results as an XML DOM object. 
     * This method is best used if the results of the statement are not large. 
     *    
     * @return the results of the statement as a DOM object. 
     * 
     * @exception SixdmlException if the statement is invalid.
     * @exception XMLDBException  if a database error occurs
     */ 
    Document execute() throws XMLDBException, SixdmlException; 

    
     /**
     * Executes a SiXDML statement against the database and feeds the results to a SAX handler. 
     * This method is best used if the results of the statement are large and the database supports 
     * streaming of the results. 
     *     
     * @param handler a SAX handler which operates on the results of the statement. 
     * 
     * @exception SixdmlException if the statement is invalid.
     * @exception XMLDBException  if a database error occurs
     */ 
    void execute( DefaultHandler handler) throws XMLDBException, SixdmlException;


    /**
     * Executes a SiXDML statement against the database and writes the results to the specified OutputStream. 
     * This method is best used when the results of the statement are not XML. 
     *     
     * @param outputStream the stream to write the results to 
     * 
     * @exception SixdmlException if the statement is invalid.
     * @exception XMLDBException  if a database error occurs
     */ 
    void execute( OutputStream outputStream) throws XMLDBException, SixdmlException; 

     /**
     * Executes a SiXDML statement against the database and writes the results using the specified writer. 
     * This method is best used when the results of the statement are not XML. 
     *     
     * @param writer the writer to send results to  
     * 
     * @exception SixdmlException if the statement is invalid.
     * @exception XMLDBException  if a database error occurs
     */ 
    void execute( Writer writer) throws XMLDBException, SixdmlException; 

}
