// $ANTLR 2.7.4: "Sixdml.g" -> "SixdmlParser.java"$
 
    package org.sixdml.parser;
    import java.io.*;
    import org.sixdml.exceptions.*;
    import org.sixdml.query.*;
    import org.sixdml.update.*;
    import org.sixdml.dbmanagement.*;
    import org.sixdml.*;
    import org.sixdml.transform.*;
    import java.util.Vector;
    import java.util.HashMap;
    import org.xmldb.api.*; 
    import org.xmldb.api.base.*; 
    import java.net.*; 
    

import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;


    /**
     * Helper class to work around the inability to declare member variables in the 
     * SixdmlParser class. 
     */
    class Helper{	
	static SixdmlNamespaceMap namespaceMap = new SixdmlNamespaceMap();
    }


/**
 * <PRE>
 * Recognizes SiXDML: The Simple XML Data Manipulation Language.
 * 
 * Created: Mon Jan 22 02:26:48 2002
 *
 * </PRE>  
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 */
public class SixdmlParser extends antlr.LLkParser       implements SixdmlTokenTypes
 {

protected SixdmlParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
}

public SixdmlParser(TokenBuffer tokenBuf) {
  this(tokenBuf,2);
}

protected SixdmlParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
}

public SixdmlParser(TokenStream lexer) {
  this(lexer,2);
}

public SixdmlParser(ParserSharedInputState state) {
  super(state,2);
  tokenNames = _tokenNames;
}

	public final void sixdmlStatements(
		StringBuffer results, String driver
	) throws RecognitionException, TokenStreamException, Exception {
		
		
		
		/* Connect to DB and start a transaction before parsing commands */
		
		
		SixdmlTransactionService transaction = null; 
		SixdmlDatabase database = null; 
		
		try{
			Class c     = Class.forName(driver);	
			database    = (SixdmlDatabase) c.newInstance();	
			DatabaseManager.registerDatabase(database); 
			
			transaction = 
			(SixdmlTransactionService) database.getService("SixdmlTransactionService", SixdmlConstants.SIXDML_VERSION); 
			
		}catch(ClassNotFoundException cnfe){		
			results.append("Could not locate the Database driver [" + driver + "]"); 
			results.append("\n"); throw cnfe; 
		}catch(InstantiationException ie){
			results.append("An error occured while instantiating the Database driver [org.sixdml.excelon.xlnSixdmlDatabase]"); 
			results.append("\n"); throw ie;
		}catch(XMLDBException xe){
			results.append(xe.getMessage()); 
			results.append("\n"); throw xe; 
		}
		
		transaction.begin(); 
		
		
		
		try {      // for error handling
			{
			int _cnt3=0;
			_loop3:
			do {
				if ((_tokenSet_0.member(LA(1)))) {
					sixdmlStatement(database, results);
				}
				else {
					if ( _cnt3>=1 ) { break _loop3; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt3++;
			} while (true);
			}
			
			
				    transaction.commit(); 
				    
				
		}
		catch (Exception e) {
			//rollback on failed transactions. VERY IMPORTANT. 
				    
				    try { transaction.rollback(); }catch (Exception e2){ results.append(e2.getMessage());}
				    throw e; 
				
		}
	}
	
	public final void sixdmlStatement(
		SixdmlDatabase database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case CREATE:
			{
				createStatement(database, results);
				break;
			}
			case DROP:
			{
				dropStatement(database, results);
				break;
			}
			case CONSTRAIN:
			{
				constrainStatement(database, results);
				break;
			}
			case INSERT:
			{
				insertStatement(database, results);
				break;
			}
			case SHOW:
			{
				showStatement(database, results);
				break;
			}
			case SELECT:
			{
				selectStatement(database, results);
				break;
			}
			case DELETE:
			{
				deleteStatement(database, results);
				break;
			}
			case REPLACE:
			{
				replaceStatement(database, results);
				break;
			}
			case RENAME:
			{
				renameStatement(database, results);
				break;
			}
			case NAMESPACE:
			{
				namespaceDecl(database, results);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(SEMI);
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_1);
		}
	}
	
	public final void createStatement(
		SixdmlDatabase database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		
		try {      // for error handling
			match(CREATE);
			{
			switch ( LA(1)) {
			case COLLECTION:
			{
				createCollectionStmt(database, results);
				break;
			}
			case INDEX:
			{
				createIndexStmt(database, results);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_2);
		}
	}
	
	public final void dropStatement(
		SixdmlDatabase database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		
		try {      // for error handling
			match(DROP);
			{
			switch ( LA(1)) {
			case CONSTRAINTS:
			{
				dropConstraintsStmt(database, results);
				break;
			}
			case COLLECTION:
			{
				dropCollectionStmt(database, results);
				break;
			}
			case INDEX:
			{
				dropIndexStmt(database, results);
				break;
			}
			case DOCNAME_N_FILEEXT:
			{
				dropDocumentStmt(database, results);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_2);
		}
	}
	
	public final void constrainStatement(
		SixdmlDatabase database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		Token  schemaURL = null;
		
		
		Vector v; 
		String id = ""; 
		Integer column = null, line = null; 
		
		
		
		
		try {      // for error handling
			match(CONSTRAIN);
			match(COLLECTION);
			v=colPath();
			match(WITH);
			schemaURL = LT(1);
			match(URL);
			
			
				    id     = (String) v.remove(0); 
				    column = (Integer) v.remove(0); 
				    line   = (Integer) v.remove(0); 
				    
				    /* get collection */
				    SixdmlCollection collection = 
				    (SixdmlCollection) database.getCollection(id, "", "");
			
				    if(collection == null)
				    throw new XMLDBException(0, "Cannot find collection named " + id);  
			
				    collection.setSchema(new URL(schemaURL.getText()));
			
				    /* avoid resource leaks especially in Xindice */ 
				    collection.close(); 
			
				
		}
		catch (XMLDBException xe) {
			//error obtaining collection 
				    results.append("Error - LINE[" + line +"] COLUMN[" + column	
					+ "]: " + xe.getMessage()); 
				    results.append("\n"); throw xe;
				
		}
		catch (InvalidSchemaException ise) {
			
				    results.append("Error - LINE[" + schemaURL.getLine() +"] COLUMN[" 
					+ schemaURL.getColumn() + "]: The schema at " + schemaURL.getText() + " is invalid "
					+ "due to the following error(s)\n\n" + ise.getCause()); 
				    results.append("\n"); throw ise; 
				
		}
		catch (InvalidCollectionDocumentException icde) {
			
				    results.append("Error - LINE[" + schemaURL.getLine() +"] COLUMN[" 
					+ schemaURL.getColumn() + "]: " + icde.getMessage() + " failed to validate against "
					+ "the new schema with the following error(s)\n\n" + icde.getCause()); 			
				    results.append("\n"); throw icde; 
				
		}
		catch (Exception e) {
			//IO error, schema validation error or malformed URL
				    results.append("Error - LINE[" + schemaURL.getLine() +"] COLUMN[" + 
					schemaURL.getColumn() + "]: " + e); 
				    results.append("\n"); throw e;
				
		}
	}
	
	public final void insertStatement(
		SixdmlDatabase database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		
		try {      // for error handling
			match(INSERT);
			{
			switch ( LA(1)) {
			case URL:
			{
				insrtDocumentStmt(database, results);
				break;
			}
			case ATTRIBUTE:
			{
				insrtAttributeStmt(database, results);
				break;
			}
			default:
				if ((LA(1)==INLINE_XML) && (LA(2)==NAMED)) {
					insrtInlineDocumentStmt(database, results);
				}
				else if ((LA(1)==INLINE_XML) && ((LA(2) >= BEFORE && LA(2) <= AFTER))) {
					insrtFragmentStmt(database, results);
				}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_2);
		}
	}
	
	public final void showStatement(
		SixdmlDatabase database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		
		try {      // for error handling
			match(SHOW);
			{
			switch ( LA(1)) {
			case CONSTRAINTS:
			{
				showSchemaStmt(database, results);
				break;
			}
			case INDICES:
			{
				showIndicesStmt(database, results);
				break;
			}
			case COLLECTION:
			{
				showCollectionStmt(database, results);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_2);
		}
	}
	
	public final void selectStatement(
		SixdmlDatabase database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		Token  root = null;
		Token  tr = null;
		Token  trsfrmXML = null;
		Token  trsfrmURL = null;
		
		
		Vector queryVec = null, docVec = null, colVec = null,  predVec = null; 
		String qstring ="", did, cid, pstring=null;
		Integer qcolumn = null,qline = null, dcolumn = null, dline = null;
		Integer  ccolumn = null, cline = null; 
		SixdmlResource queryResults = null; 
		String interimResults =""; 
		
		
		
		try {      // for error handling
			match(SELECT);
			queryVec=xpathQuery();
			
				    qstring     = (String)  queryVec.remove(0); 
				    qcolumn = (Integer) queryVec.remove(0); 
				    qline   = (Integer) queryVec.remove(0); 
				    queryVec = null; 
				
			match(FROM);
			{
			switch ( LA(1)) {
			case DOCNAME_N_FILEEXT:
			case XPATHEXPR1:
			case DOC_OR_COL_PATH:
			{
				try {      // for error handling
					docVec=docPath();
					
							did     = (String)  docVec.remove(0); 
							dcolumn = (Integer) docVec.remove(0); 
							dline   = (Integer) docVec.remove(0); 
							docVec = null;
					
							SixdmlQueryService queryManager = 
							(SixdmlQueryService) database.getService("SixdmlQueryService", SixdmlConstants.SIXDML_VERSION); 
							queryManager.setNamespaceMap(Helper.namespaceMap); 
					
							SixdmlResource document = (SixdmlResource) database.getResource(did, "", ""); 
					
							if(document == null)
							throw new XMLDBException(0, "Cannot find document named " + did); 
					
							SixdmlXpathObject sxo = queryManager.executeQuery(qstring.trim(), document); 
					
							if(sxo.getType() == SixdmlXpathObject.NODESET)
							interimResults = sxo.getNodeSetAsXML(); 
							else
							interimResults = sxo.getObjectAsString(); 
							
							/* avoid resource leaks especially in Xindice */ 
							document.getParentCollection().close(); 
							
						
				}
				catch (XMLDBException xe) {
					//error obtaining resource
							results.append("Error - LINE[" + dline +"] COLUMN[" + dcolumn	+ "]: " 
							    + xe.getMessage()); 
							results.append("\n"); throw xe;
						
				}
				break;
			}
			case COLLECTION:
			{
				try {      // for error handling
					match(COLLECTION);
					colVec=colPath();
					{
					switch ( LA(1)) {
					case WHERE:
					{
						match(WHERE);
						predVec=xpathQuery();
						pstring = ((String)predVec.remove(0)).trim() ;
						break;
					}
					case SEMI:
					case USING:
					case AND:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					
							cid     = (String)  colVec.remove(0); 
							ccolumn = (Integer) colVec.remove(0); 
							cline   = (Integer) colVec.remove(0); 
					
							
							SixdmlQueryService queryManager = 
							(SixdmlQueryService) database.getService("SixdmlQueryService", SixdmlConstants.SIXDML_VERSION); 			
							queryManager.setNamespaceMap(Helper.namespaceMap); 
					
							SixdmlCollection collection = 
							(SixdmlCollection) database.getCollection(cid, "", ""); 
					
							if(collection == null)
							throw new XMLDBException(0, "Cannot find collection named " + cid); 
					
							SixdmlQueryResultsMap sqrm = queryManager.executeQuery(qstring.trim(), collection, pstring); 
					
							interimResults = sqrm.getXML(); 
							
							/* avoid resource leaks especially in Xindice */ 
							collection.close(); 
					
						
				}
				catch (XMLDBException xe) {
					//error obtaining collection 
							results.append("Error - LINE[" + cline +"] COLUMN[" + ccolumn	+ "]: " 
							    + xe.getMessage()); 
							results.append("\n"); throw xe;
						
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case USING:
			{
				match(USING);
				match(ROOT);
				match(EQUAL);
				root = LT(1);
				match(QUOTED_VALUE);
				
				
						String xmlDecl = ""; 
				
						/* move XMLNS declaration if any. Performance may be bad for this, should reconsider */ 
						if(interimResults.startsWith("<?xml")){
				
						    int endDecl    = interimResults.indexOf("?>"); 
						    xmlDecl        = interimResults.substring(0, endDecl + 2) + "\n";
						    interimResults = interimResults.substring(endDecl + 2);  
						}
				
						/* check if QName with single colon in name  */
						String rootName = root.getText(); 
						String prefix ="", localName = rootName, nsDecl   = ""; 
						int colonIdx    = rootName.indexOf(':'); 
				
						if((colonIdx != -1) && (colonIdx == rootName.lastIndexOf(':')) && !rootName.endsWith(":")){
				
						    prefix = rootName.substring(0, colonIdx); 
						    localName = rootName.substring(colonIdx + 1); 
						    
						    String nsURI = Helper.namespaceMap.get(prefix); 
				
						    if(nsURI == null){
							
							prefix = ""; 
						    }else{
							
							nsDecl  = "xmlns:" + prefix + "=\"" + nsURI + "\"" ; 
							prefix += ":"; 			
						    }
						}
				
						interimResults = 
						    xmlDecl + "<" + prefix + localName + " " + nsDecl + ">\n" 
						    + interimResults 
						    + "\n</" + prefix + localName +  ">" ; 
					
				break;
			}
			case SEMI:
			case AND:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case AND:
			{
				match(AND);
				tr = LT(1);
				match(TRANSFORM);
				match(WITH);
				match(XSLT);
				match(IN);
				{
				switch ( LA(1)) {
				case INLINE_XML:
				{
					try {      // for error handling
						trsfrmXML = LT(1);
						match(INLINE_XML);
						
						
								    SixdmlTransformService transformer = 
								    (SixdmlTransformService) database.getService("XsltTransformService", SixdmlConstants.SIXDML_VERSION); 
						
								    interimResults = 
								    transformer.transformAndReturnString(trsfrmXML.getText(), interimResults); 
						
								
					}
					catch (InvalidTransformException ite) {
						//incorrect query syntax
								    results.append("Error - LINE[" + trsfrmXML.getLine() +"] COLUMN[" 
									+ trsfrmXML.getColumn()	+ "]: The following " 
									+ "error occured while processing " + qstring + "\n\n" 
									+ ite.getMessage()); 
								    results.append("\n"); throw ite;
								
					}
					break;
				}
				case URL:
				{
					try {      // for error handling
						trsfrmURL = LT(1);
						match(URL);
						
								    
								    SixdmlTransformService transformer = 
								    (SixdmlTransformService) database.getService("XsltTransformService", SixdmlConstants.SIXDML_VERSION); 
						
								    interimResults = 
								    transformer.transformAndReturnString(new URL(trsfrmURL.getText()), interimResults); 
								    
								
					}
					catch (InvalidTransformException ite) {
						//incorrect query syntax
								    results.append("Error - LINE[" + trsfrmURL.getLine() +"] COLUMN[" 
									+ trsfrmURL.getColumn()	+ "]: The following " 
									+ "error occured while transforming the results of " + qstring + "\n\n" 
									+ ite.getMessage()); 
								    results.append("\n"); throw ite;
								
					}
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				break;
			}
			case SEMI:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			//interimResults contains query results [after transformation, if any]
				    results.append(interimResults); 
				    
				
		}
		catch (InvalidQueryException iqe) {
			//incorrect query syntax
				    results.append("Error - LINE[" + qline +"] COLUMN[" + qcolumn	+ "]: The following " 
					+ "error occured while processing " + qstring + "\n\n" + iqe.getMessage()); 
				    results.append("\n"); throw iqe;
				
		}
		catch (NonWellFormedXMLException nwfe) {
			//results of query not XML 		
			
				    results.append("Error - LINE[" + tr.getLine() +"] COLUMN[" 	+ tr.getColumn() 
					+ "]: " + tr.getText() + " The results of the XPath query failed "
					+ " to be parsed as a well formed XML file with the following error(s)\n\n" 
					+ nwfe.getMessage()); 
				    results.append("\n"); throw nwfe; 
				
		}
		catch (Exception e) {
			//IO error or malformed URL
				    
				    results.append("Error - " + e); 
				    results.append("\n"); throw e;
				
		}
	}
	
	public final void deleteStatement(
		SixdmlDatabase database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		
		
		Vector queryVec = null, docVec = null, colVec = null, predVec = null; 
		String qstring ="", did, cid, pstring = null; 
		Integer qcolumn = null,qline = null, dcolumn = null, dline = null;
		Integer  ccolumn = null, cline = null; 
		
		
		try {      // for error handling
			match(DELETE);
			queryVec=xpathQuery();
			
				    qstring     = (String)  queryVec.remove(0); 
				    qcolumn = (Integer) queryVec.remove(0); 
				    qline   = (Integer) queryVec.remove(0); 
				    queryVec = null; 
				
			match(FROM);
			{
			switch ( LA(1)) {
			case DOCNAME_N_FILEEXT:
			case XPATHEXPR1:
			case DOC_OR_COL_PATH:
			{
				try {      // for error handling
					docVec=docPath();
					
					
							did     = (String)  docVec.remove(0); 
							dcolumn = (Integer) docVec.remove(0); 
							dline   = (Integer) docVec.remove(0); 
							docVec = null;
					
							SixdmlUpdateService updateManager = 
							(SixdmlUpdateService) database.getService("SixdmlUpdateService", SixdmlConstants.SIXDML_VERSION); 
					
							SixdmlResource document = (SixdmlResource) database.getResource(did, "", ""); 
					
							if(document == null)
							throw new XMLDBException(0, "Cannot find document named " + did); 
							
							updateManager.setNamespaceMap(Helper.namespaceMap); 
							updateManager.delete(qstring, document); 
					
							/* avoid resource leaks especially in Xindice */ 
							document.getParentCollection().close(); 
					
						
				}
				catch (XMLDBException xe) {
					//error obtaining collection or resource
							results.append("Error - LINE[" + dline +"] COLUMN[" + dcolumn	+ "]: " 
							    + xe.getMessage()); 
							results.append("\n"); throw xe;
						
				}
				break;
			}
			case COLLECTION:
			{
				try {      // for error handling
					match(COLLECTION);
					colVec=colPath();
					{
					switch ( LA(1)) {
					case WHERE:
					{
						match(WHERE);
						predVec=xpathQuery();
						pstring = ((String)predVec.remove(0)).trim() ;
						break;
					}
					case SEMI:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					
					
							cid     = (String)  colVec.remove(0); 
							ccolumn = (Integer) colVec.remove(0); 
							cline   = (Integer) colVec.remove(0); 
							colVec = null;
					
							SixdmlUpdateService updateManager = 
							(SixdmlUpdateService) database.getService("SixdmlUpdateService", SixdmlConstants.SIXDML_VERSION); 
					
							SixdmlCollection collection = 
							(SixdmlCollection) database.getCollection(cid, "", ""); 
					
							if(collection == null)
							throw new XMLDBException(0, "Cannot find collection named " + cid);
					
							updateManager.setNamespaceMap(Helper.namespaceMap); 
							updateManager.delete(qstring, pstring, collection); 
					
							/* avoid resource leaks especially in Xindice */ 
							collection.close(); 
					
						
				}
				catch (XMLDBException xe) {
					//error obtaining collection or resource
							results.append("Error - LINE[" + dline +"] COLUMN[" + dcolumn	+ "]: " 
							    + xe.getMessage()); 
							results.append("\n"); throw xe;
						
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (InvalidQueryException iqe) {
			//incorrect query syntax
				    results.append("Error - LINE[" + qline +"] COLUMN[" + qcolumn	+ "]: The following " 
					+ "error occured while processing " + qstring + "\n\n" + iqe.getMessage()); 
				    results.append("\n"); throw iqe;
				
		}
		catch (UpdateTypeMismatchException utme) {
			
				    results.append("Error - " + utme.getMessage()); 
				    results.append("\n"); throw utme;	
				
		}
	}
	
	public final void replaceStatement(
		SixdmlDatabase database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		Token  xmlFrag = null;
		
		
		Vector queryVec = null, docVec = null, colVec = null, nsVec = null, predVec = null; 
		String qstring ="", did, cid, nid = null, pstring = null; 
		Integer qcolumn = null,qline = null, dcolumn = null, dline = null;
		Integer  ccolumn = null, cline = null, ncolumn = null, nline = null; 	
		
		
		try {      // for error handling
			match(REPLACE);
			queryVec=xpathQuery();
			
				    qstring     = (String)  queryVec.remove(0); 
				    qcolumn = (Integer) queryVec.remove(0); 
				    qline   = (Integer) queryVec.remove(0); 
				    queryVec = null; 
				
			match(WITH);
			xmlFrag = LT(1);
			match(INLINE_XML);
			match(IN);
			{
			switch ( LA(1)) {
			case DOCNAME_N_FILEEXT:
			case XPATHEXPR1:
			case DOC_OR_COL_PATH:
			{
				try {      // for error handling
					docVec=docPath();
					
					
							did     = (String)  docVec.remove(0); 
							dcolumn = (Integer) docVec.remove(0); 
							dline   = (Integer) docVec.remove(0); 
							docVec = null;
					
							SixdmlUpdateService updateManager = 
							(SixdmlUpdateService) database.getService("SixdmlUpdateService", SixdmlConstants.SIXDML_VERSION); 
					
							SixdmlResource document = (SixdmlResource) database.getResource(did, "", ""); 
					
							if(document == null)
							throw new XMLDBException(0, "Cannot find document named " + did); 
							
							updateManager.setNamespaceMap(Helper.namespaceMap); 
							updateManager.replace(qstring, xmlFrag.getText().trim(), document); 
					
							/* avoid resource leaks especially in Xindice */ 
							document.getParentCollection().close(); 
					
						
				}
				catch (XMLDBException xe) {
					//error obtaining collection or resource
							results.append("Error - LINE[" + dline +"] COLUMN[" + dcolumn	+ "]: " 
							    + xe.getMessage()); 
							results.append("\n"); throw xe;
						
				}
				break;
			}
			case COLLECTION:
			{
				try {      // for error handling
					match(COLLECTION);
					colVec=colPath();
					{
					switch ( LA(1)) {
					case WHERE:
					{
						match(WHERE);
						predVec=xpathQuery();
						pstring = ((String)predVec.remove(0)).trim() ;
						break;
					}
					case SEMI:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					
					
							cid     = (String)  colVec.remove(0); 
							ccolumn = (Integer) colVec.remove(0); 
							cline   = (Integer) colVec.remove(0); 
							colVec = null;
					
							SixdmlUpdateService updateManager = 
							(SixdmlUpdateService) database.getService("SixdmlUpdateService", SixdmlConstants.SIXDML_VERSION); 
					
							SixdmlCollection collection = 
							(SixdmlCollection) database.getCollection(cid, "", ""); 
					
							if(collection == null)
							throw new XMLDBException(0, "Cannot find collection named " + cid);
					
							updateManager.setNamespaceMap(Helper.namespaceMap); 
							updateManager.replace(qstring, pstring, xmlFrag.getText().trim(), collection); 
					
							/* avoid resource leaks especially in Xindice */ 
							collection.close(); 
					
						
				}
				catch (XMLDBException xe) {
					//error obtaining collection or resource
							results.append("Error - LINE[" + dline +"] COLUMN[" + dcolumn	+ "]: " 
							    + xe.getMessage()); 
							results.append("\n"); throw xe;
						
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (NonWellFormedXMLException nwfe) {
			
				    results.append("Error - LINE[" + xmlFrag.getLine() +"] COLUMN[" 
					+ xmlFrag.getColumn() + "]: " + xmlFrag.getText() + " failed to be parsed as "
					+ "a well formed XML file with the following error(s)\n\n" + nwfe);  
				    results.append("\n"); throw nwfe;  
				
		}
		catch (InvalidQueryException iqe) {
			//incorrect query syntax
				    results.append("Error - LINE[" + qline +"] COLUMN[" + qcolumn	+ "]: The following " 
					+ "error occured while processing " + qstring + "\n\n" + iqe.getMessage()); 
				    results.append("\n"); throw iqe;
				
		}
		catch (UpdateTypeMismatchException utme) {
			
				    results.append("Error - " + utme.getMessage()); 
				    results.append("\n"); throw utme;	
				
		}
	}
	
	public final void renameStatement(
		SixdmlDatabase database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		Token  ns = null;
		
		
		Vector queryVec = null, docVec = null, colVec = null, nsVec = null, predVec = null; 
		String qstring ="", pstring = null, did, cid; //, nid = null; 
		Integer qcolumn = null,qline = null, dcolumn = null, dline = null;
		Integer  ccolumn = null, cline = null, ncolumn = null, nline = null; 	
		String newName = ""; 
		
		
		try {      // for error handling
			match(RENAME);
			queryVec=xpathQuery();
			
				    qstring     = (String)  queryVec.remove(0); 
				    qcolumn = (Integer) queryVec.remove(0); 
				    qline   = (Integer) queryVec.remove(0); 
				    queryVec = null; 
				
			match(TO);
			newName=qnameOrID();
			{
			switch ( LA(1)) {
			case WITH:
			{
				match(WITH);
				match(NSURI);
				match(EQUAL);
				ns = LT(1);
				match(QUOTED_VALUE);
				break;
			}
			case IN:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(IN);
			{
			switch ( LA(1)) {
			case DOCNAME_N_FILEEXT:
			case XPATHEXPR1:
			case DOC_OR_COL_PATH:
			{
				try {      // for error handling
					docVec=docPath();
					
					
							did     = (String)  docVec.remove(0); 
							dcolumn = (Integer) docVec.remove(0); 
							dline   = (Integer) docVec.remove(0); 
							docVec = null;
					
							SixdmlUpdateService updateManager = 
							(SixdmlUpdateService) database.getService("SixdmlUpdateService", SixdmlConstants.SIXDML_VERSION); 
					
							SixdmlResource document = (SixdmlResource) database.getResource(did, "", ""); 		
						
							if(document == null)
							throw new XMLDBException(0, "Cannot find document named " + did); 
							
							//URI nsuri = (ns == null? null :  new URI(ns.getText().trim())); Java 1.4
							String nsuri = (ns == null? null :  ns.getText().trim());
					
							updateManager.setNamespaceMap(Helper.namespaceMap); 
							updateManager.rename(qstring, newName, nsuri, document); 
					
							/* avoid resource leaks especially in Xindice */ 
							document.getParentCollection().close(); 
					
						
				}
				catch (XMLDBException xe) {
					//error obtaining collection or resource
							results.append("Error - LINE[" + dline +"] COLUMN[" + dcolumn	+ "]: " 
							    + xe.getMessage()); 
							results.append("\n"); throw xe;
						
				}
				break;
			}
			case COLLECTION:
			{
				try {      // for error handling
					match(COLLECTION);
					colVec=colPath();
					{
					switch ( LA(1)) {
					case WHERE:
					{
						match(WHERE);
						predVec=xpathQuery();
						pstring = ((String)predVec.remove(0)).trim() ;
						break;
					}
					case SEMI:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					
					
							cid     = (String)  colVec.remove(0); 
							ccolumn = (Integer) colVec.remove(0); 
							cline   = (Integer) colVec.remove(0); 
							colVec = null;
					
							SixdmlUpdateService updateManager = 
							(SixdmlUpdateService) database.getService("SixdmlUpdateService", SixdmlConstants.SIXDML_VERSION); 
					
							SixdmlCollection collection = 
							(SixdmlCollection) database.getCollection(cid, "", ""); 
					
							if(collection == null)
							throw new XMLDBException(0, "Cannot find collection named " + cid);
					
							//URI nsuri = (ns == null? null :  new URI(ns.getText().trim())); Java 1.4
							String nsuri = (ns == null? null :  ns.getText().trim()); 
					
							updateManager.setNamespaceMap(Helper.namespaceMap); 
							updateManager.rename(qstring, pstring, newName, nsuri, collection); 
					
							/* avoid resource leaks especially in Xindice */ 
							collection.close(); 
					
						
				}
				catch (XMLDBException xe) {
					//error obtaining collection or resource
							results.append("Error - LINE[" + dline +"] COLUMN[" + dcolumn	+ "]: " 
							    + xe.getMessage()); 
							results.append("\n"); throw xe;
						
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (InvalidQueryException iqe) {
			//incorrect query syntax
				    results.append("Error - LINE[" + qline +"] COLUMN[" + qcolumn	+ "]: The following " 
					+ "error occured while processing " + qstring + "\n\n" + iqe.getMessage()); 
				    results.append("\n"); throw iqe;
				
		}
		catch (UpdateTypeMismatchException utme) {
			
				    results.append("Error - " + utme.getMessage()); 
				    results.append("\n"); throw utme;	
				/* }catch[URISyntaxException use]{ //bad URI
				    results.append("Error - LINE[" + ns.getLine() +"] COLUMN[" + ns.getColumn()	+ "]: " 
					+ use); 
				    results.append("\n"); throw use; Java 1.4 */				
				
		}
	}
	
	public final void namespaceDecl(
		SixdmlDatabase database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		Token  prfx = null;
		Token  ns = null;
		
		
		try {      // for error handling
			match(NAMESPACE);
			prfx = LT(1);
			match(ID);
			match(EQUAL);
			ns = LT(1);
			match(QUOTED_VALUE);
			
				Helper.namespaceMap.put(prfx.getText(), ns.getText()); 
			
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_2);
		}
	}
	
	public final void createCollectionStmt(
		SixdmlDatabase database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		Token  url = null;
		
		Vector v; 
		String id; 
		Integer column = null, line = null; 
		
		
		try {      // for error handling
			match(COLLECTION);
			v=colPath();
			
				    
				    id     = (String) v.remove(0); 
				    column = (Integer) v.remove(0); 
				    line   = (Integer) v.remove(0); 
				    SixdmlCollectionManagementService colManager = 
				    (SixdmlCollectionManagementService) database.getService("SixdmlCollectionManagementService", SixdmlConstants.SIXDML_VERSION); 
				    System.out.println("Collection management service created");
				    System.out.flush(); 
				    SixdmlCollection collection = (SixdmlCollection) colManager.createCollection(id); 
				    System.out.println("Collection created");
				    System.out.flush(); 
			
				    
			
				
			{
			switch ( LA(1)) {
			case CONSTRAINED:
			{
				match(CONSTRAINED);
				match(BY);
				url = LT(1);
				match(URL);
				collection.setSchema(new URL(url.getText()));
				break;
			}
			case SEMI:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			collection.close();
		}
		catch (XMLDBException xe) {
			//error creating collection 
				    results.append("Error - LINE[" + line +"] COLUMN[" + column	+ "]: " 
					+ xe.getMessage()); 
				    results.append("\n"); throw xe;
				
		}
		catch (InvalidSchemaException ise) {
			
				    results.append("Error - LINE[" + url.getLine() +"] COLUMN[" 
					+ url.getColumn() + ": The schema at " + url.getText() + " is invalid "
					+ "due to the following error(s)\n\n" + ise.getCause()); 
				    results.append("\n"); throw ise; 
				
		}
		catch (InvalidCollectionDocumentException icde) {
			
				    results.append("Error - LINE[" + url.getLine() +"] COLUMN[" 
					+ url.getColumn() + ": " + icde.getMessage() + " failed to validate against "
					+ "the new schema with the following error(s)\n\n" + icde.getCause()); 			
				    results.append("\n"); throw icde; 
				
		}
		catch (Exception e) {
			//IO error, schema validation error or malformed URL
				    
				    results.append("Error - LINE[" + line +"] COLUMN[" + column + "]: " + e); 
				    results.append("\n"); throw e;
				
		}
	}
	
	public final void createIndexStmt(
		SixdmlDatabase database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		Token  idxName = null;
		Token  idxType = null;
		Token  idxKey = null;
		Token  idxElement = null;
		
		
		Vector v;
		String id = "";
		Integer column = null, line = null; 	
		
		
		
		try {      // for error handling
			match(INDEX);
			idxName = LT(1);
			match(ID);
			match(OF);
			match(TYPE);
			idxType = LT(1);
			match(ID);
			match(WITH);
			match(KEY);
			match(EQUAL);
			idxKey = LT(1);
			match(QUOTED_VALUE);
			
				    //what kind of index are we creating? 
				    SixdmlIndexType indexType = SixdmlIndexType.createIndexType(idxType.getText()); 
			
				    /* create hashtable of index fields */
				    HashMap fields = new HashMap(); 
				    fields.put("pattern", idxKey.getText()); 
				    fields.put("type", indexType.toString()); 
				  
			
				
			{
			switch ( LA(1)) {
			case COMMA:
			{
				match(COMMA);
				match(ELEMENT);
				match(EQUAL);
				idxElement = LT(1);
				match(QUOTED_VALUE);
				
						fields.put("indexElement", idxElement.getText());
					
				break;
			}
			case ON:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(ON);
			match(COLLECTION);
			v=colPath();
			
			
				    id     = (String) v.remove(0); 
				    column = (Integer) v.remove(0); 
				    line   = (Integer) v.remove(0); 
			
				    /* get collection */
				    SixdmlCollection collection = 
				    (SixdmlCollection) database.getCollection(id, "", "");
			
				    if(collection == null)
				    throw new XMLDBException(0, "Cannot find collection named " + id); ; 
				    
				     SixdmlCollectionManagementService colManager = 
				    (SixdmlCollectionManagementService) database.getService("SixdmlCollectionManagementService", SixdmlConstants.SIXDML_VERSION); 
				    
				    SixdmlIndex index = colManager.createIndex(idxName.getText(), fields);
				    collection.addIndex(index);
			
				    /* avoid resource leaks especially in Xindice */ 
				    collection.close(); 
				    
				
		}
		catch (XMLDBException xe) {
			//error obtaining collection 
				    results.append("Error - LINE[" + line +"] COLUMN[" + column	
					+ "]: " + xe.getMessage()); 
				    results.append("\n"); throw xe;
				
		}
		catch (UnsupportedIndexTypeException uite) {
			//unknown index type
				    results.append("Error - LINE[" + idxType.getLine() +"] COLUMN[" + idxType.getColumn() 
					+ "]: " + idxType.getText() + " is an unsupported index type"); 
				    results.append("\n"); throw uite;
				
		}
		catch (IndexAlreadyExistsException iaee) {
			//index already exists
				    results.append("Error - LINE[" + idxType.getLine() +"] COLUMN[" + idxName.getColumn() 
					+ "]: An index named " + idxName.getText() + " already exists in the database"); 
				    results.append("\n"); throw iaee;
				
		}
	}
	
	public final void dropConstraintsStmt(
		SixdmlDatabase database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		
		
		Vector v; 
		String id = ""; 
		Integer column = null, line = null; 
		
		
		
		try {      // for error handling
			match(CONSTRAINTS);
			match(ON);
			match(COLLECTION);
			v=colPath();
			
			
				    id     = (String) v.remove(0); 
				    column = (Integer) v.remove(0); 
				    line   = (Integer) v.remove(0); 
				    
				    /* get collection */
				    SixdmlCollection collection = 
				    (SixdmlCollection) database.getCollection(id, "", "");
				    
				    if(collection == null)
				    throw new XMLDBException( 0, "Cannot find collection named " + id); 
				    
				    collection.unsetSchema(); 
			
				    /* avoid resource leaks especially in Xindice */ 
				    collection.close(); 
			
				
		}
		catch (XMLDBException xe) {
			//error obtaining collection 
				    results.append("Error - LINE[" + line +"] COLUMN[" + column	
					+ "]: " + xe.getMessage()); 
				    results.append("\n"); throw xe;
				
		}
	}
	
	public final void dropCollectionStmt(
		SixdmlDatabase database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		
		
		Vector v; 
		String id = ""; 
		Integer column = null, line = null; 
		
		
		
		try {      // for error handling
			match(COLLECTION);
			v=colPath();
			
			
				    id     = (String) v.remove(0); 
				    column = (Integer) v.remove(0); 
				    line   = (Integer) v.remove(0); 
				    
				    /* get collection manager */
				    SixdmlCollectionManagementService colManager = 
				    (SixdmlCollectionManagementService) database.getService("SixdmlCollectionManagementService", SixdmlConstants.SIXDML_VERSION);
				    
				    colManager.removeCollection(id);
			
				
		}
		catch (XMLDBException xe) {
			//error obtaining collection 
				    results.append("Error - LINE[" + line +"] COLUMN[" + column	
					+ "]: " + xe.getMessage()); 
				    results.append("\n"); throw xe;
				
		}
	}
	
	public final void dropIndexStmt(
		SixdmlDatabase database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		Token  idxName2 = null;
		
		
		Vector v; 
		String id = ""; 
		Integer column = null, line = null; 
		
		
		
		try {      // for error handling
			match(INDEX);
			idxName2 = LT(1);
			match(ID);
			match(FROM);
			match(COLLECTION);
			v=colPath();
			
			
				    id     = (String) v.remove(0); 
				    column = (Integer) v.remove(0); 
				    line   = (Integer) v.remove(0); 
			
				    /* get collection */
				    SixdmlCollection collection = 
				    (SixdmlCollection) database.getCollection(id, "", "");
			
				    if(collection == null)
				    throw new XMLDBException(0,"Cannot find collection named " + id); 
				    
				    collection.removeIndex(idxName2.getText());
			
				    /* avoid resource leaks especially in Xindice */ 
				    collection.close(); 
			
				
		}
		catch (XMLDBException xe) {
			//error obtaining collection 
				    results.append("Error - LINE[" + line +"] COLUMN[" + column	
					+ "]: " + xe.getMessage()); 
				    results.append("\n"); throw xe;
				
		}
		catch (NonExistentIndexException neie) {
			//bogus index name 
				    results.append("Error - LINE[" + idxName2.getLine() +"] COLUMN[" 
					+ idxName2.getColumn() + "]: " + idxName2.getText() + " is a non-existent index");
				    results.append("\n"); throw neie; 
				
		}
	}
	
	public final void dropDocumentStmt(
		SixdmlDatabase database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		Token  docName = null;
		
		
		Vector v; 
		String id = ""; 
		Integer column = null, line = null; 
		
		
		
		try {      // for error handling
			docName = LT(1);
			match(DOCNAME_N_FILEEXT);
			match(FROM);
			match(COLLECTION);
			v=colPath();
			
			
				    id     = (String) v.remove(0); 
				    column = (Integer) v.remove(0); 
				    line   = (Integer) v.remove(0); 
			
				    /* get collection */
				    SixdmlCollection collection = 
				    (SixdmlCollection) database.getCollection(id, "", "");
			
				    if(collection == null)
				    throw new XMLDBException(0,"Cannot find collection named " + id); 
				    
				    collection.removeDocument(docName.getText()); 
			
				    /* avoid resource leaks especially in Xindice */ 
				    collection.close(); 
			
				
		}
		catch (XMLDBException xe) {
			//error obtaining collection 
				    results.append("Error - LINE[" + line +"] COLUMN[" + column	
					+ "]: " + xe.getMessage()); 
				    results.append("\n"); throw xe;
				
		}
		catch (NonExistentDocumentException nede) {
			//bogus document name 
				    results.append("Error - LINE[" + docName.getLine() +"] COLUMN[" 
					+ docName.getColumn() + "]: " + docName.getText() + " is a non-existent document");
				    results.append("\n"); throw nede; 
				
		}
	}
	
	public final void showSchemaStmt(
		Database database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		
		
		Vector v; 
		String id = "", docname=""; 
		Integer column = null, line = null; 
		
		
		
		
		try {      // for error handling
			match(CONSTRAINTS);
			match(ON);
			match(COLLECTION);
			v=colPath();
			
			
				    id     = (String) v.remove(0); 
				    column = (Integer) v.remove(0); 
				    line   = (Integer) v.remove(0); 
				    
				    /* get collection */
				    SixdmlCollection collection = 
				    (SixdmlCollection) database.getCollection(id, "", "");
			
				    if(collection == null)
				    throw new XMLDBException(0, "Cannot find collection named " + id); 
				    
				    String schemaStr = collection.showSchema(); 
			
				    if(schemaStr == null) 
				    results.append("No schema exists for " + id); 
				    else
				    results.append(schemaStr); 
			
				    results.append("\n"); 
			
				    /* avoid resource leaks especially in Xindice */ 
				    collection.close(); 
			
				
		}
		catch (XMLDBException xe) {
			//error obtaining collection 
				    results.append("Error - LINE[" + line +"] COLUMN[" + column	
					+ "]: " + xe.getMessage()); 
				    results.append("\n"); throw xe;
				
		}
	}
	
	public final void showIndicesStmt(
		Database database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		
		
		Vector v; 
		String id = "", docname=""; 
		Integer column = null, line = null; 
		
		
		
		
		try {      // for error handling
			match(INDICES);
			match(ON);
			match(COLLECTION);
			v=colPath();
			
			
				    id     = (String) v.remove(0); 
				    column = (Integer) v.remove(0); 
				    line   = (Integer) v.remove(0); 
				    
				    /* get collection */
				    SixdmlCollection collection = 
				    (SixdmlCollection) database.getCollection(id, "", "");
			
				    if(collection == null)
				    throw new XMLDBException(0, "Cannot find collection named " + id); 
				    
				    SixdmlIndex[] indices = collection.getIndices(); 
			
				    if(indices.length == 0){
					results.append("No indices in effect on " + id + "\n");
				    }else{ 
					results.append("Indices in effect on " + id + " are: \n");
					for(int i=0; i < indices.length; i++){
					    results.append("name = " + indices[i].getName() + "\ntype = " + indices[i].getType()
						+ "\nfields = " + indices[i].getIndexFields() + "\n\n"); 
					}//for
				    }//else
			
			
				    /* avoid resource leaks especially in Xindice */ 
				    collection.close(); 
			
				
		}
		catch (XMLDBException xe) {
			//error obtaining collection 
				    results.append("Error - LINE[" + line +"] COLUMN[" + column	
					+ "]: " + xe.getMessage()); 
				    results.append("\n"); throw xe;
				
		}
	}
	
	public final void showCollectionStmt(
		Database database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		
		
		Vector v; 
		String id = "", docname=""; 
		Integer column = null, line = null; 
		
		
		
		
		try {      // for error handling
			match(COLLECTION);
			v=colPath();
			
			
				    id     = (String) v.remove(0); 
				    column = (Integer) v.remove(0); 
				    line   = (Integer) v.remove(0); 
				    
				    /* get collection */
				    SixdmlCollection collection = 
				    (SixdmlCollection) database.getCollection(id, "", "");
			
				    if(collection == null)
				    throw new XMLDBException(0, "Cannot find collection named " + id); 
				    
				    String[] resources = collection.listResources(); 
			
				    if(resources.length == 0){
					results.append("No XML documents in " + id);
				    }else{ 
					results.append("XML documents stored in " + id + " are: \n");
					for(int i=0; i < resources.length; i++){
					    results.append(resources[i] + "\n"); 
					}//for
				    }//else
			
				    results.append("\n"); 
			
				    String[] collections = collection.listChildCollections(); 
			
				    if(collections.length == 0){
					results.append("No child collections located in " + id);
				    }else{ 
					results.append("Child collections of " + id + " are: \n");
					for(int i=0; i < collections.length; i++){
					    results.append(collections[i] + "\n"); 
					}//for
				    }//else
			
				    results.append("\n\n"); 
			
				    /* avoid resource leaks especially in Xindice */ 
				    collection.close(); 
			
				
		}
		catch (XMLDBException xe) {
			//error obtaining collection 
				    results.append("Error - LINE[" + line +"] COLUMN[" + column	
					+ "]: " + xe.getMessage()); 
				    results.append("\n"); throw xe;
				
		}
	}
	
	public final void insrtDocumentStmt(
		Database database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		Token  docURL = null;
		
		
		Vector v; 
		String id = "", docname=""; 
		Integer column = null, line = null; 
		
		
		
		
		try {      // for error handling
			docURL = LT(1);
			match(URL);
			match(INTO);
			match(COLLECTION);
			v=colPath();
			
			
				    id     = (String) v.remove(0); 
				    column = (Integer) v.remove(0); 
				    line   = (Integer) v.remove(0); 
				    
				    /* get collection */
				    SixdmlCollection collection = 
				    (SixdmlCollection) database.getCollection(id, "", "");
			
				    if(collection == null)
				    throw new XMLDBException(0, "Cannot find collection named " + id); 
				    
				    /* do insert */
				    URL url = new URL(docURL.getText()); 
				    int fileIndx = url.getFile().lastIndexOf('/') + 1; 
				    docname = url.getFile().substring(fileIndx);
				    collection.insertDocument(docname, url); 
			
				    /* avoid resource leaks especially in Xindice */ 
				    collection.close(); 
			
				
		}
		catch (XMLDBException xe) {
			//error obtaining collection 
				    results.append("Error - LINE[" + line +"] COLUMN[" + column	
					+ "]: " + xe.getMessage()); 
				    results.append("\n"); throw xe;
				
		}
		catch (InvalidCollectionDocumentException icde) {
			
				    results.append("Error - LINE[" + docURL.getLine() +"] COLUMN[" 
					+ docURL.getColumn() + "]: " + icde.getMessage() + " failed to validate against "
					+ "the new schema with the following error(s)\n\n" + icde.getCause()); 			
				    results.append("\n"); throw icde; 
				
		}
		catch (NonWellFormedXMLException nwfe) {
			
				    results.append("Error - LINE[" + docURL.getLine() +"] COLUMN[" 
					+ docURL.getColumn() + "]: " + docURL.getText() + " failed to be parsed as "
					+ "a well formed XML file with the following error(s)\n\n" + nwfe); 
				    results.append("\n"); throw nwfe; 
				
		}
		catch (DocumentAlreadyExistsException daee) {
			
				    results.append("Error - LINE[" + docURL.getLine() +"] COLUMN[" + docURL.getColumn() 
					+ "]: A document named " + docname + " already exists in the database" ); 
				    results.append("\n"); throw daee; 
				
		}
		catch (Exception e) {
			//IO error or malformed URL
				    results.append("Error - LINE[" + docURL.getLine() +"] COLUMN[" + docURL.getColumn() 
					+ "]: " + e); 
				    results.append("\n"); throw e;
				
		}
	}
	
	public final void insrtInlineDocumentStmt(
		Database database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		Token  xml = null;
		Token  docName = null;
		
		
		Vector v; 
		String id = ""; 
		Integer column = null, line = null; 
		
		
		
		
		try {      // for error handling
			xml = LT(1);
			match(INLINE_XML);
			match(NAMED);
			docName = LT(1);
			match(DOCNAME_N_FILEEXT);
			match(INTO);
			match(COLLECTION);
			v=colPath();
			
			
				    id     = (String) v.remove(0); 
				    column = (Integer) v.remove(0); 
				    line   = (Integer) v.remove(0); 
				    
				    /* get collection */
				    SixdmlCollection collection = 
				    (SixdmlCollection) database.getCollection(id, "", "");
			
				    if(collection == null)
				    throw new XMLDBException(0, "Cannot find collection named " + id); 
				    
				    /* do insert */
				    collection.insertDocument(docName.getText().trim(), xml.getText()); 
			
				    /* avoid resource leaks especially in Xindice */ 
				    collection.close(); 
			
				
		}
		catch (XMLDBException xe) {
			//error obtaining collection 
				    results.append("Error - LINE[" + line +"] COLUMN[" + column	
					+ "]: " + xe.getMessage()); 
				    results.append("\n"); throw xe;
				
		}
		catch (InvalidCollectionDocumentException icde) {
			
				    results.append("Error - LINE[" + xml.getLine() +"] COLUMN[" 
					+ xml.getColumn() + "]: " + icde.getMessage() + " failed to validate against "
					+ "the new schema with the following error(s)\n\n" + icde.getCause()); 			
				    results.append("\n"); throw icde; 
				
		}
		catch (NonWellFormedXMLException nwfe) {
			
				    results.append("Error - LINE[" + xml.getLine() +"] COLUMN[" 
					+ xml.getColumn() + "]: " + xml.getText() + " failed to be parsed as "
					+ "a well formed XML file with the following error(s)\n\n" + nwfe); 
				    results.append("\n"); throw nwfe; 
				
		}
		catch (DocumentAlreadyExistsException daee) {
			
				    results.append("Error - LINE[" + xml.getLine() +"] COLUMN[" + xml.getColumn() 
					+ "]: A document named " + docName.getText() + " already exists in the database" ); 
				    results.append("\n"); throw daee; 
				
		}
		catch (Exception e) {
			//IO error or malformed URL
				    results.append("Error - LINE[" + xml.getLine() +"] COLUMN[" + xml.getColumn() 
					+ "]: " + e); 
				    results.append("\n"); throw e;
				
		}
	}
	
	public final void insrtFragmentStmt(
		SixdmlDatabase database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		Token  xmlToInsert = null;
		
		
		final int before = 1, at = 2, after = 3; 
		int insertPosn = 0; 
		Vector queryVec = null, docVec = null, colVec = null, predVec = null; 
		String qstring ="", did, cid, pstring = null; 
		Integer qcolumn = null,qline = null, dcolumn = null, dline = null;
		Integer  ccolumn = null, cline = null; 
		
		
		try {      // for error handling
			xmlToInsert = LT(1);
			match(INLINE_XML);
			{
			switch ( LA(1)) {
			case BEFORE:
			{
				match(BEFORE);
				insertPosn = before;
				break;
			}
			case AT:
			{
				match(AT);
				insertPosn = at;
				break;
			}
			case AFTER:
			{
				match(AFTER);
				insertPosn = after;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			queryVec=xpathQuery();
			
				    qstring     = (String)  queryVec.remove(0); 
				    qcolumn = (Integer) queryVec.remove(0); 
				    qline   = (Integer) queryVec.remove(0); 
				    queryVec = null; 
				
			match(IN);
			{
			switch ( LA(1)) {
			case DOCNAME_N_FILEEXT:
			case XPATHEXPR1:
			case DOC_OR_COL_PATH:
			{
				try {      // for error handling
					docVec=docPath();
					
							did     = (String)  docVec.remove(0); 
							dcolumn = (Integer) docVec.remove(0); 
							dline   = (Integer) docVec.remove(0); 
							docVec = null;
					
							SixdmlUpdateService updateManager = 
							(SixdmlUpdateService) database.getService("SixdmlUpdateService", SixdmlConstants.SIXDML_VERSION); 
							updateManager.setNamespaceMap(Helper.namespaceMap); 
					
							SixdmlResource document = (SixdmlResource) database.getResource(did, "", ""); 
					
							if(document == null)
							throw new XMLDBException(0, "Cannot find document named " + did); 
					
							if(insertPosn == before)
							updateManager.insertSibling(qstring, xmlToInsert.getText().trim(),document, true);
							else if(insertPosn == after)
							updateManager.insertSibling(qstring, xmlToInsert.getText().trim(),document, false);
							else if(insertPosn == at)
							updateManager.insertChild(qstring, xmlToInsert.getText().trim(),document);
							
							/* avoid resource leaks especially in Xindice */ 
							document.getParentCollection().close(); 
					
						
				}
				catch (XMLDBException xe) {
					//error obtaining collection or resource
							results.append("Error - LINE[" + dline +"] COLUMN[" + dcolumn	+ "]: " 
							    + xe.getMessage()); 
							results.append("\n"); throw xe;
						
				}
				break;
			}
			case COLLECTION:
			{
				try {      // for error handling
					match(COLLECTION);
					colVec=colPath();
					{
					switch ( LA(1)) {
					case WHERE:
					{
						match(WHERE);
						predVec=xpathQuery();
						pstring = ((String)predVec.remove(0)).trim() ;
						break;
					}
					case SEMI:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					
							cid     = (String)  colVec.remove(0); 
							ccolumn = (Integer) colVec.remove(0); 
							cline   = (Integer) colVec.remove(0); 
					
							
							SixdmlUpdateService updateManager = 
							(SixdmlUpdateService) database.getService("SixdmlUpdateService", SixdmlConstants.SIXDML_VERSION); 
							updateManager.setNamespaceMap(Helper.namespaceMap); 
					
							SixdmlCollection collection = 
							(SixdmlCollection) database.getCollection(cid, "", ""); 
					
							if(collection == null)
							throw new XMLDBException(0, "Cannot find collection named " + cid);
					
					
							if(insertPosn == before)
							updateManager.insertSibling(qstring, pstring, xmlToInsert.getText().trim(),collection, true);
							else if(insertPosn == after)
							updateManager.insertSibling(qstring, pstring, xmlToInsert.getText().trim(),collection, false);
							else if (insertPosn == at)
							updateManager.insertChild(qstring, pstring, xmlToInsert.getText().trim(),collection);
					
					
							/* avoid resource leaks especially in Xindice */ 
							collection.close(); 
							
						
				}
				catch (XMLDBException xe) {
					//error obtaining collection or resource
							results.append("Error - LINE[" + dline +"] COLUMN[" + dcolumn	+ "]: " 
							    + xe.getMessage()); 
							results.append("\n"); throw xe;
						
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (InvalidQueryException iqe) {
			//incorrect query syntax
				    results.append("Error - LINE[" + qline +"] COLUMN[" + qcolumn	+ "]: The following " 
					+ "error occured while processing " + qstring + "\n\n" + iqe.getMessage()); 
				    results.append("\n"); throw iqe;
				
		}
		catch (NonWellFormedXMLException nwfe) {
			
				    results.append("Error - LINE[" + xmlToInsert.getLine() +"] COLUMN[" 
					+ xmlToInsert.getColumn() + "]: " + xmlToInsert.getText() + " failed to be parsed as "
					+ "a well formed XML file with the following error(s)\n\n" + nwfe); 
				    results.append("\n"); throw nwfe; 
				
		}
		catch (UpdateTypeMismatchException utme) {
			
				    results.append("Error - " + utme.getMessage()); 
				    results.append("\n"); throw utme;
				
		}
	}
	
	public final void insrtAttributeStmt(
		SixdmlDatabase database, StringBuffer results
	) throws RecognitionException, TokenStreamException, Exception {
		
		Token  attrName = null;
		Token  attrValue = null;
		Token  attrNS = null;
		
		
		Vector queryVec = null, docVec = null, colVec = null, nsVec = null, predVec = null; 
		String qstring ="", did, cid, nid = null, pstring = null; 
		Integer qcolumn = null,qline = null, dcolumn = null, dline = null;
		Integer  ccolumn = null, cline = null, ncolumn = null, nline = null; 		
		
		
		try {      // for error handling
			match(ATTRIBUTE);
			match(WITH);
			match(NAME);
			match(EQUAL);
			attrName = LT(1);
			match(QUOTED_VALUE);
			match(COMMA);
			match(VALUE);
			match(EQUAL);
			attrValue = LT(1);
			match(QUOTED_VALUE);
			{
			switch ( LA(1)) {
			case COMMA:
			{
				match(COMMA);
				match(NSURI);
				match(EQUAL);
				attrNS = LT(1);
				match(QUOTED_VALUE);
				break;
			}
			case INTO:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			match(INTO);
			queryVec=xpathQuery();
			
				    qstring     = (String)  queryVec.remove(0); 
				    qcolumn = (Integer) queryVec.remove(0); 
				    qline   = (Integer) queryVec.remove(0); 
				    queryVec = null; 
				
			match(IN);
			{
			switch ( LA(1)) {
			case DOCNAME_N_FILEEXT:
			case XPATHEXPR1:
			case DOC_OR_COL_PATH:
			{
				try {      // for error handling
					docVec=docPath();
					
					
							did     = (String)  docVec.remove(0); 
							dcolumn = (Integer) docVec.remove(0); 
							dline   = (Integer) docVec.remove(0); 
							docVec = null;
					
							SixdmlUpdateService updateManager = 
							(SixdmlUpdateService) database.getService("SixdmlUpdateService", SixdmlConstants.SIXDML_VERSION); 
							updateManager.setNamespaceMap(Helper.namespaceMap); 
					
							SixdmlResource document = (SixdmlResource) database.getResource(did, "", ""); 
					
							if(document == null)
							throw new XMLDBException(0, "Cannot find document named " + did); 
					
							if(attrNS == null){
							    updateManager.insertAttribute(qstring, document, attrName.getText(), 
								attrValue.getText()); 
							}else{
							    updateManager.insertAttribute(qstring, document, attrName.getText(), 
								attrValue.getText(), attrNS.getText().trim());  // new URI(attrNS.getText().trim())); Java 1.4
					
							    /* avoid resource leaks especially in Xindice */ 
							    document.getParentCollection().close(); 
					
							}
						
				}
				catch (XMLDBException xe) {
					//error obtaining collection or resource
							results.append("Error - LINE[" + dline +"] COLUMN[" + dcolumn	+ "]: " 
							    + xe.getMessage()); 
							results.append("\n"); throw xe;
						    /* }catch[URISyntaxException use]{ //bad URI
							results.append("Error - LINE[" + attrNS.getLine() +"] COLUMN[" + attrNS.getColumn()
							    + use); 
							results.append("\n"); throw use; Java 1.4 */					
						
				}
				break;
			}
			case COLLECTION:
			{
				try {      // for error handling
					match(COLLECTION);
					colVec=colPath();
					{
					switch ( LA(1)) {
					case WHERE:
					{
						match(WHERE);
						predVec=xpathQuery();
						pstring = ((String)predVec.remove(0)).trim() ;
						break;
					}
					case SEMI:
					{
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					
					
							cid     = (String)  colVec.remove(0); 
							ccolumn = (Integer) colVec.remove(0); 
							cline   = (Integer) colVec.remove(0); 
							colVec = null;
					
							SixdmlUpdateService updateManager = 
							(SixdmlUpdateService) database.getService("SixdmlUpdateService", SixdmlConstants.SIXDML_VERSION); 
							updateManager.setNamespaceMap(Helper.namespaceMap); 
					
							SixdmlCollection collection = 
							(SixdmlCollection) database.getCollection(cid, "", ""); 
					
							if(collection == null)
							throw new XMLDBException(0, "Cannot find collection named " + cid);
					
							if(attrNS == null){
							    updateManager.insertAttribute(qstring, pstring, collection, attrName.getText(), 
								attrValue.getText()); 
							}else{
							    updateManager.insertAttribute(qstring, pstring, collection, attrName.getText(), 
								attrValue.getText(), attrNS.getText().trim()); // new URI(attrNS.getText().trim())); Java 1.4
							}
					
							/* avoid resource leaks especially in Xindice */ 
							collection.close(); 
					
						
				}
				catch (XMLDBException xe) {
					//error obtaining collection or resource
							results.append("Error - LINE[" + dline +"] COLUMN[" + dcolumn	+ "]: " 
							    + xe.getMessage()); 
							results.append("\n"); throw xe;
						    /* }catch[URISyntaxException use]{ //bad URI
							results.append("Error - LINE[" + attrNS.getLine() +"] COLUMN[" + attrNS.getColumn()	
							    + "]: " + use); 
							results.append("\n"); throw use; Java 1.4 */
						
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		catch (InvalidQueryException iqe) {
			//incorrect query syntax
				    results.append("Error - LINE[" + qline +"] COLUMN[" + qcolumn	+ "]: The following " 
					+ "error occured while processing " + qstring + "\n\n" + iqe.getMessage()); 
				    results.append("\n"); throw iqe;
				
		}
		catch (UpdateTypeMismatchException utme) {
			
				    results.append("Error - " + utme.getMessage()); 
				    results.append("\n"); throw utme;	
				
		}
	}
	
	public final Vector  xpathQuery() throws RecognitionException, TokenStreamException {
		Vector info;
		
		Token  xpq1 = null;
		Token  xpq2 = null;
		info = new Vector();
		
		try {      // for error handling
			switch ( LA(1)) {
			case XPATHEXPR1:
			{
				xpq1 = LT(1);
				match(XPATHEXPR1);
				
					    info.add(xpq1.getText().trim()); 
					    info.add(new Integer(xpq1.getColumn())); 
					    info.add(new Integer(xpq1.getLine())); 
					
				break;
			}
			case XPATHEXPR2:
			{
				xpq2 = LT(1);
				match(XPATHEXPR2);
				
					    info.add(xpq2.getText().trim()); 
					    info.add(new Integer(xpq2.getColumn())); 
					    info.add(new Integer(xpq2.getLine())); 
					
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_3);
		}
		return info;
	}
	
	public final String  qnameOrID() throws RecognitionException, TokenStreamException {
		String name;
		
		Token  cname = null;
		Token  id = null;
		name="";
		
		try {      // for error handling
			switch ( LA(1)) {
			case URN_OR_COLON_NAME:
			{
				cname = LT(1);
				match(URN_OR_COLON_NAME);
				
					    name = cname.getText(); 
					
				break;
			}
			case ID:
			{
				id = LT(1);
				match(ID);
				
					    name = id.getText(); 
					
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_4);
		}
		return name;
	}
	
	public final Vector  docPath() throws RecognitionException, TokenStreamException {
		Vector info;
		
		Token  dp = null;
		Token  df = null;
		Token  dxp = null;
		info = new Vector();
		
		try {      // for error handling
			switch ( LA(1)) {
			case DOC_OR_COL_PATH:
			{
				dp = LT(1);
				match(DOC_OR_COL_PATH);
				
					    info.add(dp.getText().trim()); 
					    info.add(new Integer(dp.getColumn())); 
					    info.add(new Integer(dp.getLine())); 
					
				break;
			}
			case DOCNAME_N_FILEEXT:
			{
				df = LT(1);
				match(DOCNAME_N_FILEEXT);
				
					    info.add(df.getText().trim()); 
					    info.add(new Integer(df.getColumn())); 
					    info.add(new Integer(df.getLine())); 
					
				break;
			}
			case XPATHEXPR1:
			{
				dxp = LT(1);
				match(XPATHEXPR1);
				
					    info.add(dxp.getText().trim()); 
					    info.add(new Integer(dxp.getColumn())); 
					    info.add(new Integer(dxp.getLine())); 
					
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_5);
		}
		return info;
	}
	
	public final Vector  colPath() throws RecognitionException, TokenStreamException {
		Vector info;
		
		Token  cp = null;
		Token  cxp = null;
		Token  cid = null;
		info = new Vector();
		
		try {      // for error handling
			switch ( LA(1)) {
			case DOC_OR_COL_PATH:
			{
				cp = LT(1);
				match(DOC_OR_COL_PATH);
				
					    info.add(cp.getText().trim()); 
					    info.add(new Integer(cp.getColumn())); 
					    info.add(new Integer(cp.getLine())); 
					
				break;
			}
			case XPATHEXPR1:
			{
				cxp = LT(1);
				match(XPATHEXPR1);
				
					    info.add(cxp.getText().trim()); 
					    info.add(new Integer(cxp.getColumn())); 
					    info.add(new Integer(cxp.getLine())); 
					
				break;
			}
			case ID:
			{
				cid = LT(1);
				match(ID);
				
					    info.add(cid.getText().trim()); 
					    info.add(new Integer(cid.getColumn())); 
					    info.add(new Integer(cid.getLine())); 
					
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_6);
		}
		return info;
	}
	
	public final Vector  nsURI() throws RecognitionException, TokenStreamException {
		Vector info;
		
		Token  nsurn = null;
		Token  nsurl = null;
		info = new Vector();
		
		try {      // for error handling
			switch ( LA(1)) {
			case URN:
			{
				nsurn = LT(1);
				match(URN);
				
					    info.add(nsurn.getText().trim()); 
					    info.add(new Integer(nsurn.getColumn())); 
					    info.add(new Integer(nsurn.getLine())); 
					
				break;
			}
			case URL:
			{
				nsurl = LT(1);
				match(URL);
				
					    info.add(nsurl.getText().trim()); 
					    info.add(new Integer(nsurl.getColumn())); 
					    info.add(new Integer(nsurl.getLine())); 
					
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_7);
		}
		return info;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"a semicolon",
		"\"CREATE\"",
		"\"DROP\"",
		"\"SHOW\"",
		"\"INSERT\"",
		"\"RENAME\"",
		"\"TO\"",
		"\"WITH\"",
		"\"NSURI\"",
		"an equal sign",
		"a value in quotes",
		"\"IN\"",
		"\"COLLECTION\"",
		"\"WHERE\"",
		"\"REPLACE\"",
		"INLINE_XML",
		"\"DELETE\"",
		"\"FROM\"",
		"\"ATTRIBUTE\"",
		"\"NAME\"",
		"a comma",
		"\"VALUE\"",
		"\"INTO\"",
		"\"BEFORE\"",
		"\"AT\"",
		"\"AFTER\"",
		"\"SELECT\"",
		"\"USING\"",
		"\"ROOT\"",
		"\"AND\"",
		"\"TRANSFORM\"",
		"\"XSLT\"",
		"URL",
		"\"CONSTRAINED\"",
		"\"BY\"",
		"\"INDEX\"",
		"an identifier",
		"\"OF\"",
		"\"TYPE\"",
		"\"KEY\"",
		"\"ELEMENT\"",
		"\"ON\"",
		"\"CONSTRAINTS\"",
		"the name of an XML document which includes the file extension",
		"\"CONSTRAIN\"",
		"\"NAMED\"",
		"\"INDICES\"",
		"\"NAMESPACE\"",
		"an XPath expression or hierarchical path",
		"an XPath expression",
		"DOC_OR_COL_PATH",
		"URN",
		"URN_OR_COLON_NAME",
		"\"CONSTRAINS\"",
		"COMMENT",
		"WS",
		"HIERARCHICAL_PATH_FRAG",
		"COL_PATH",
		"DOC_PATH",
		"XPATH_START_LETTER",
		"XPATH_AXIS_OR_FUNC_NAME",
		"LCASE_STRING",
		"XPATH_OR_ID_OR_URL",
		"ID_LETTER_OR_SLASH",
		"COLON_NAME",
		"ID_START_LETTER",
		"ID_LETTER",
		"a left parenthesis",
		"a right parenthesis",
		"an XPath axis connector",
		"a division sign or path seperator",
		"a period",
		"a quotation mark"
	};
	
	private static final long[] mk_tokenSet_0() {
		long[] data = { 2533275865449440L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
	private static final long[] mk_tokenSet_1() {
		long[] data = { 2533275865449442L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
	private static final long[] mk_tokenSet_2() {
		long[] data = { 16L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
	private static final long[] mk_tokenSet_3() {
		long[] data = { 10739551248L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
	private static final long[] mk_tokenSet_4() {
		long[] data = { 34816L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
	private static final long[] mk_tokenSet_5() {
		long[] data = { 10737418256L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
	private static final long[] mk_tokenSet_6() {
		long[] data = { 148176504848L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
	private static final long[] mk_tokenSet_7() {
		long[] data = { 2L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
	
	}
