// $ANTLR 2.7.4: "Sixdml.g" -> "SixdmlLexer.java"$
 
    package org.sixdml.parser;
    import java.io.*;
    import org.sixdml.exceptions.*;
    import org.sixdml.query.*;
    import org.sixdml.update.*;
    import org.sixdml.dbmanagement.*;
    import org.sixdml.*;
    import org.sixdml.transform.*;
    import java.util.Vector;
    import java.util.HashMap;
    import org.xmldb.api.*; 
    import org.xmldb.api.base.*; 
    import java.net.*; 
    

import java.io.InputStream;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.TokenStreamRecognitionException;
import antlr.CharStreamException;
import antlr.CharStreamIOException;
import antlr.ANTLRException;
import java.io.Reader;
import java.util.Hashtable;
import antlr.CharScanner;
import antlr.InputBuffer;
import antlr.ByteBuffer;
import antlr.CharBuffer;
import antlr.Token;
import antlr.CommonToken;
import antlr.RecognitionException;
import antlr.NoViableAltForCharException;
import antlr.MismatchedCharException;
import antlr.TokenStream;
import antlr.ANTLRHashString;
import antlr.LexerSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.SemanticException;

public class SixdmlLexer extends antlr.CharScanner implements SixdmlTokenTypes, TokenStream
 {
public SixdmlLexer(InputStream in) {
	this(new ByteBuffer(in));
}
public SixdmlLexer(Reader in) {
	this(new CharBuffer(in));
}
public SixdmlLexer(InputBuffer ib) {
	this(new LexerSharedInputState(ib));
}
public SixdmlLexer(LexerSharedInputState state) {
	super(state);
	caseSensitiveLiterals = true;
	setCaseSensitive(true);
	literals = new Hashtable();
	literals.put(new ANTLRHashString("CONSTRAINS", this), new Integer(57));
	literals.put(new ANTLRHashString("VALUE", this), new Integer(25));
	literals.put(new ANTLRHashString("DROP", this), new Integer(6));
	literals.put(new ANTLRHashString("CONSTRAINED", this), new Integer(37));
	literals.put(new ANTLRHashString("AT", this), new Integer(28));
	literals.put(new ANTLRHashString("NSURI", this), new Integer(12));
	literals.put(new ANTLRHashString("CONSTRAINTS", this), new Integer(46));
	literals.put(new ANTLRHashString("FROM", this), new Integer(21));
	literals.put(new ANTLRHashString("BY", this), new Integer(38));
	literals.put(new ANTLRHashString("RENAME", this), new Integer(9));
	literals.put(new ANTLRHashString("TO", this), new Integer(10));
	literals.put(new ANTLRHashString("USING", this), new Integer(31));
	literals.put(new ANTLRHashString("REPLACE", this), new Integer(18));
	literals.put(new ANTLRHashString("TRANSFORM", this), new Integer(34));
	literals.put(new ANTLRHashString("WITH", this), new Integer(11));
	literals.put(new ANTLRHashString("CREATE", this), new Integer(5));
	literals.put(new ANTLRHashString("ELEMENT", this), new Integer(44));
	literals.put(new ANTLRHashString("COLLECTION", this), new Integer(16));
	literals.put(new ANTLRHashString("SELECT", this), new Integer(30));
	literals.put(new ANTLRHashString("NAMED", this), new Integer(49));
	literals.put(new ANTLRHashString("AFTER", this), new Integer(29));
	literals.put(new ANTLRHashString("NAME", this), new Integer(23));
	literals.put(new ANTLRHashString("ON", this), new Integer(45));
	literals.put(new ANTLRHashString("AND", this), new Integer(33));
	literals.put(new ANTLRHashString("ROOT", this), new Integer(32));
	literals.put(new ANTLRHashString("XSLT", this), new Integer(35));
	literals.put(new ANTLRHashString("CONSTRAIN", this), new Integer(48));
	literals.put(new ANTLRHashString("INDEX", this), new Integer(39));
	literals.put(new ANTLRHashString("IN", this), new Integer(15));
	literals.put(new ANTLRHashString("KEY", this), new Integer(43));
	literals.put(new ANTLRHashString("WHERE", this), new Integer(17));
	literals.put(new ANTLRHashString("SHOW", this), new Integer(7));
	literals.put(new ANTLRHashString("BEFORE", this), new Integer(27));
	literals.put(new ANTLRHashString("INSERT", this), new Integer(8));
	literals.put(new ANTLRHashString("OF", this), new Integer(41));
	literals.put(new ANTLRHashString("NAMESPACE", this), new Integer(51));
	literals.put(new ANTLRHashString("INDICES", this), new Integer(50));
	literals.put(new ANTLRHashString("TYPE", this), new Integer(42));
	literals.put(new ANTLRHashString("ATTRIBUTE", this), new Integer(22));
	literals.put(new ANTLRHashString("INTO", this), new Integer(26));
	literals.put(new ANTLRHashString("DELETE", this), new Integer(20));
}

public Token nextToken() throws TokenStreamException {
	Token theRetToken=null;
tryAgain:
	for (;;) {
		Token _token = null;
		int _ttype = Token.INVALID_TYPE;
		resetText();
		try {   // for char stream error handling
			try {   // for lexical error handling
				switch ( LA(1)) {
				case '#':
				{
					mCOMMENT(true);
					theRetToken=_returnToken;
					break;
				}
				case '%':
				{
					mINLINE_XML(true);
					theRetToken=_returnToken;
					break;
				}
				case '\t':  case '\n':  case '\r':  case ' ':
				{
					mWS(true);
					theRetToken=_returnToken;
					break;
				}
				case '-':  case '.':  case '/':  case '0':
				case '1':  case '2':  case '3':  case '4':
				case '5':  case '6':  case '7':  case '8':
				case '9':  case ':':  case '@':  case 'A':
				case 'B':  case 'C':  case 'D':  case 'E':
				case 'F':  case 'G':  case 'H':  case 'I':
				case 'J':  case 'K':  case 'L':  case 'M':
				case 'N':  case 'O':  case 'P':  case 'Q':
				case 'R':  case 'S':  case 'T':  case 'U':
				case 'V':  case 'W':  case 'X':  case 'Y':
				case 'Z':  case '_':  case 'a':  case 'b':
				case 'c':  case 'd':  case 'e':  case 'f':
				case 'g':  case 'h':  case 'i':  case 'j':
				case 'k':  case 'l':  case 'm':  case 'n':
				case 'o':  case 'p':  case 'q':  case 'r':
				case 's':  case 't':  case 'u':  case 'v':
				case 'w':  case 'x':  case 'y':  case 'z':
				{
					mXPATH_OR_ID_OR_URL(true);
					theRetToken=_returnToken;
					break;
				}
				case '(':
				{
					mLPAREN(true);
					theRetToken=_returnToken;
					break;
				}
				case '"':
				{
					mQUOTED_VALUE(true);
					theRetToken=_returnToken;
					break;
				}
				case ';':
				{
					mSEMI(true);
					theRetToken=_returnToken;
					break;
				}
				case '=':
				{
					mEQUAL(true);
					theRetToken=_returnToken;
					break;
				}
				case ',':
				{
					mCOMMA(true);
					theRetToken=_returnToken;
					break;
				}
				case ')':
				{
					mRPAREN(true);
					theRetToken=_returnToken;
					break;
				}
				default:
				{
					if (LA(1)==EOF_CHAR) {uponEOF(); _returnToken = makeToken(Token.EOF_TYPE);}
				else {throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());}
				}
				}
				if ( _returnToken==null ) continue tryAgain; // found SKIP token
				_ttype = _returnToken.getType();
				_returnToken.setType(_ttype);
				return _returnToken;
			}
			catch (RecognitionException e) {
				throw new TokenStreamRecognitionException(e);
			}
		}
		catch (CharStreamException cse) {
			if ( cse instanceof CharStreamIOException ) {
				throw new TokenStreamIOException(((CharStreamIOException)cse).io);
			}
			else {
				throw new TokenStreamException(cse.getMessage());
			}
		}
	}
}

	public final void mCOMMENT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = COMMENT;
		int _saveIndex;
		
		match("#");
		{
		_loop61:
		do {
			if ((_tokenSet_0.member(LA(1)))) {
				{
				match(_tokenSet_0);
				}
			}
			else {
				break _loop61;
			}
			
		} while (true);
		}
		{
		switch ( LA(1)) {
		case '\n':
		{
			match('\n');
			break;
		}
		case '\r':
		{
			match('\r');
			{
			if ((LA(1)=='\n')) {
				match('\n');
			}
			else {
			}
			
			}
			break;
		}
		default:
		{
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		}
		}
		if ( inputState.guessing==0 ) {
			_ttype = Token.SKIP; newline();
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mINLINE_XML(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = INLINE_XML;
		int _saveIndex;
		
		_saveIndex=text.length();
		match("%<%");
		text.setLength(_saveIndex);
		{
		_loop66:
		do {
			// nongreedy exit test
			if ((LA(1)=='%') && (LA(2)=='>') && (LA(3)=='%') && (true)) break _loop66;
			if (((LA(1) >= '\u0003' && LA(1) <= '\uffff')) && ((LA(2) >= '\u0003' && LA(2) <= '\uffff')) && ((LA(3) >= '\u0003' && LA(3) <= '\uffff')) && ((LA(4) >= '\u0003' && LA(4) <= '\uffff'))) {
				matchNot(EOF_CHAR);
			}
			else {
				break _loop66;
			}
			
		} while (true);
		}
		_saveIndex=text.length();
		match("%>%");
		text.setLength(_saveIndex);
		if ( inputState.guessing==0 ) {
			/* System.out.println("Matched INLINE_XML"); */
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mWS(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = WS;
		int _saveIndex;
		
		{
		switch ( LA(1)) {
		case ' ':
		{
			match(' ');
			break;
		}
		case '\t':
		{
			match('\t');
			break;
		}
		case '\r':
		{
			match('\r');
			match('\n');
			if ( inputState.guessing==0 ) {
				newline();
			}
			break;
		}
		case '\n':
		{
			match('\n');
			if ( inputState.guessing==0 ) {
				newline();
			}
			break;
		}
		default:
		{
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		}
		}
		if ( inputState.guessing==0 ) {
			_ttype = Token.SKIP;
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mHIERARCHICAL_PATH_FRAG(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = HIERARCHICAL_PATH_FRAG;
		int _saveIndex;
		
		mSLASH(false);
		mID(false);
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mSLASH(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = SLASH;
		int _saveIndex;
		
		match('/');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mID(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = ID;
		int _saveIndex;
		
		mID_START_LETTER(false);
		{
		_loop138:
		do {
			if ((_tokenSet_1.member(LA(1)))) {
				mID_LETTER(false);
			}
			else {
				break _loop138;
			}
			
		} while (true);
		}
		if ( inputState.guessing==0 ) {
			/* System.out.println("Matched ID:" + $getText); */
		}
		_ttype = testLiteralsTable(new String(text.getBuffer(),_begin,text.length()-_begin),_ttype);
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mCOL_PATH(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = COL_PATH;
		int _saveIndex;
		
		mID(false);
		{
		_loop72:
		do {
			if ((LA(1)=='/')) {
				mHIERARCHICAL_PATH_FRAG(false);
			}
			else {
				break _loop72;
			}
			
		} while (true);
		}
		if ( inputState.guessing==0 ) {
			/* System.out.println("Matched COL_PATH:" + $getText); */
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mDOC_PATH(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = DOC_PATH;
		int _saveIndex;
		
		mCOL_PATH(false);
		mPERIOD(false);
		{
		int _cnt75=0;
		_loop75:
		do {
			if ((_tokenSet_1.member(LA(1)))) {
				mID_LETTER(false);
			}
			else {
				if ( _cnt75>=1 ) { break _loop75; } else {throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());}
			}
			
			_cnt75++;
		} while (true);
		}
		if ( inputState.guessing==0 ) {
			/* System.out.println("Matched DOC_PATH:" + $getText); */
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mPERIOD(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = PERIOD;
		int _saveIndex;
		
		match('.');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mID_LETTER(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = ID_LETTER;
		int _saveIndex;
		
		switch ( LA(1)) {
		case 'A':  case 'B':  case 'C':  case 'D':
		case 'E':  case 'F':  case 'G':  case 'H':
		case 'I':  case 'J':  case 'K':  case 'L':
		case 'M':  case 'N':  case 'O':  case 'P':
		case 'Q':  case 'R':  case 'S':  case 'T':
		case 'U':  case 'V':  case 'W':  case 'X':
		case 'Y':  case 'Z':  case '_':  case 'a':
		case 'b':  case 'c':  case 'd':  case 'e':
		case 'f':  case 'g':  case 'h':  case 'i':
		case 'j':  case 'k':  case 'l':  case 'm':
		case 'n':  case 'o':  case 'p':  case 'q':
		case 'r':  case 's':  case 't':  case 'u':
		case 'v':  case 'w':  case 'x':  case 'y':
		case 'z':
		{
			mID_START_LETTER(false);
			break;
		}
		case '0':  case '1':  case '2':  case '3':
		case '4':  case '5':  case '6':  case '7':
		case '8':  case '9':
		{
			matchRange('0','9');
			break;
		}
		case '-':
		{
			match('-');
			break;
		}
		default:
		{
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mXPATH_START_LETTER(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = XPATH_START_LETTER;
		int _saveIndex;
		
		switch ( LA(1)) {
		case '.':
		{
			mPERIOD(false);
			break;
		}
		case '@':
		{
			match('@');
			break;
		}
		case '/':
		{
			mSLASH(false);
			break;
		}
		default:
		{
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mXPATH_AXIS_OR_FUNC_NAME(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = XPATH_AXIS_OR_FUNC_NAME;
		int _saveIndex;
		
		mLCASE_STRING(false);
		{
		_loop79:
		do {
			if ((LA(1)=='-')) {
				match('-');
				mLCASE_STRING(false);
			}
			else {
				break _loop79;
			}
			
		} while (true);
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mLCASE_STRING(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = LCASE_STRING;
		int _saveIndex;
		
		{
		int _cnt87=0;
		_loop87:
		do {
			if (((LA(1) >= 'a' && LA(1) <= 'z'))) {
				matchRange('a','z');
			}
			else {
				if ( _cnt87>=1 ) { break _loop87; } else {throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());}
			}
			
			_cnt87++;
		} while (true);
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mDOCNAME_N_FILEEXT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = DOCNAME_N_FILEEXT;
		int _saveIndex;
		
		{
		int _cnt82=0;
		_loop82:
		do {
			if ((_tokenSet_1.member(LA(1)))) {
				mID_LETTER(false);
			}
			else {
				if ( _cnt82>=1 ) { break _loop82; } else {throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());}
			}
			
			_cnt82++;
		} while (true);
		}
		mPERIOD(false);
		{
		int _cnt84=0;
		_loop84:
		do {
			if ((_tokenSet_1.member(LA(1)))) {
				mID_LETTER(false);
			}
			else {
				if ( _cnt84>=1 ) { break _loop84; } else {throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());}
			}
			
			_cnt84++;
		} while (true);
		}
		if ( inputState.guessing==0 ) {
			/* System.out.println("Matched DOCNAME_N_FILEEXT:" + $getText); */
		}
		_ttype = testLiteralsTable(new String(text.getBuffer(),_begin,text.length()-_begin),_ttype);
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mXPATH_OR_ID_OR_URL(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = XPATH_OR_ID_OR_URL;
		int _saveIndex;
		
		boolean synPredMatched100 = false;
		if (((LA(1)=='f'||LA(1)=='h') && (LA(2)=='i'||LA(2)=='t') && (LA(3)=='l'||LA(3)=='t') && (LA(4)=='e'||LA(4)=='p') && (LA(5)==':'))) {
			int _m100 = mark();
			synPredMatched100 = true;
			inputState.guessing++;
			try {
				{
				mID(false);
				match("://");
				}
			}
			catch (RecognitionException pe) {
				synPredMatched100 = false;
			}
			rewind(_m100);
			inputState.guessing--;
		}
		if ( synPredMatched100 ) {
			mURL(false);
			if ( inputState.guessing==0 ) {
				_ttype = URL;
			}
		}
		else {
			boolean synPredMatched90 = false;
			if (((LA(1)=='.'||LA(1)=='/'||LA(1)=='@') && ((LA(2) >= '\u0003' && LA(2) <= '\uffff')) && ((LA(3) >= '\u0003' && LA(3) <= '\uffff')) && (true) && (true))) {
				int _m90 = mark();
				synPredMatched90 = true;
				inputState.guessing++;
				try {
					{
					mSLASH(false);
					}
				}
				catch (RecognitionException pe) {
					synPredMatched90 = false;
				}
				rewind(_m90);
				inputState.guessing--;
			}
			if ( synPredMatched90 ) {
				mXPATHEXPR1(false);
				if ( inputState.guessing==0 ) {
					_ttype = XPATHEXPR1;
				}
			}
			else {
				boolean synPredMatched92 = false;
				if (((LA(1)=='.'||LA(1)=='/'||LA(1)=='@') && ((LA(2) >= '\u0003' && LA(2) <= '\uffff')) && ((LA(3) >= '\u0003' && LA(3) <= '\uffff')) && (true) && (true))) {
					int _m92 = mark();
					synPredMatched92 = true;
					inputState.guessing++;
					try {
						{
						mPERIOD(false);
						}
					}
					catch (RecognitionException pe) {
						synPredMatched92 = false;
					}
					rewind(_m92);
					inputState.guessing--;
				}
				if ( synPredMatched92 ) {
					mXPATHEXPR1(false);
					if ( inputState.guessing==0 ) {
						_ttype = XPATHEXPR1;
					}
				}
				else {
					boolean synPredMatched94 = false;
					if (((LA(1)=='.'||LA(1)=='/'||LA(1)=='@') && ((LA(2) >= '\u0003' && LA(2) <= '\uffff')) && ((LA(3) >= '\u0003' && LA(3) <= '\uffff')) && (true) && (true))) {
						int _m94 = mark();
						synPredMatched94 = true;
						inputState.guessing++;
						try {
							{
							match('@');
							}
						}
						catch (RecognitionException pe) {
							synPredMatched94 = false;
						}
						rewind(_m94);
						inputState.guessing--;
					}
					if ( synPredMatched94 ) {
						mXPATHEXPR1(false);
						if ( inputState.guessing==0 ) {
							_ttype = XPATHEXPR1;
						}
					}
					else {
						boolean synPredMatched96 = false;
						if ((((LA(1) >= 'a' && LA(1) <= 'z')) && (_tokenSet_2.member(LA(2))) && ((LA(3) >= '\u0003' && LA(3) <= '\uffff')) && (true) && (true))) {
							int _m96 = mark();
							synPredMatched96 = true;
							inputState.guessing++;
							try {
								{
								mID(false);
								match("::");
								}
							}
							catch (RecognitionException pe) {
								synPredMatched96 = false;
							}
							rewind(_m96);
							inputState.guessing--;
						}
						if ( synPredMatched96 ) {
							mXPATHEXPR2(false);
							if ( inputState.guessing==0 ) {
								_ttype = XPATHEXPR2;
							}
						}
						else {
							boolean synPredMatched98 = false;
							if ((((LA(1) >= 'a' && LA(1) <= 'z')) && (_tokenSet_2.member(LA(2))) && ((LA(3) >= '\u0003' && LA(3) <= '\uffff')) && (true) && (true))) {
								int _m98 = mark();
								synPredMatched98 = true;
								inputState.guessing++;
								try {
									{
									mID(false);
									match("(");
									}
								}
								catch (RecognitionException pe) {
									synPredMatched98 = false;
								}
								rewind(_m98);
								inputState.guessing--;
							}
							if ( synPredMatched98 ) {
								mXPATHEXPR2(false);
								if ( inputState.guessing==0 ) {
									_ttype = XPATHEXPR2;
								}
							}
							else {
								boolean synPredMatched104 = false;
								if (((_tokenSet_1.member(LA(1))) && (_tokenSet_3.member(LA(2))) && (_tokenSet_3.member(LA(3))) && (true) && (true))) {
									int _m104 = mark();
									synPredMatched104 = true;
									inputState.guessing++;
									try {
										{
										mID(false);
										match(".");
										}
									}
									catch (RecognitionException pe) {
										synPredMatched104 = false;
									}
									rewind(_m104);
									inputState.guessing--;
								}
								if ( synPredMatched104 ) {
									mDOCNAME_N_FILEEXT(false);
									if ( inputState.guessing==0 ) {
										_ttype = DOCNAME_N_FILEEXT;
									}
								}
								else {
									boolean synPredMatched102 = false;
									if (((_tokenSet_4.member(LA(1))) && (true) && (true) && (true) && (true))) {
										int _m102 = mark();
										synPredMatched102 = true;
										inputState.guessing++;
										try {
											{
											mID(false);
											match("/");
											}
										}
										catch (RecognitionException pe) {
											synPredMatched102 = false;
										}
										rewind(_m102);
										inputState.guessing--;
									}
									if ( synPredMatched102 ) {
										mDOC_OR_COL_PATH(false);
										if ( inputState.guessing==0 ) {
											_ttype = DOC_OR_COL_PATH;
										}
									}
									else {
										boolean synPredMatched106 = false;
										if (((_tokenSet_5.member(LA(1))) && (true) && (true) && (true) && (true))) {
											int _m106 = mark();
											synPredMatched106 = true;
											inputState.guessing++;
											try {
												{
												mID(false);
												match(":");
												}
											}
											catch (RecognitionException pe) {
												synPredMatched106 = false;
											}
											rewind(_m106);
											inputState.guessing--;
										}
										if ( synPredMatched106 ) {
											mURN_OR_COLON_NAME(false);
											if ( inputState.guessing==0 ) {
												_ttype = URN_OR_COLON_NAME;
											}
										}
										else if ((_tokenSet_4.member(LA(1))) && (true) && (true) && (true) && (true)) {
											mID(false);
											if ( inputState.guessing==0 ) {
												_ttype = ID;
											}
										}
										else {
											throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
										}
										}}}}}}}}
										_ttype = testLiteralsTable(_ttype);
										if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
											_token = makeToken(_ttype);
											_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
										}
										_returnToken = _token;
									}
									
	protected final void mXPATHEXPR1(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = XPATHEXPR1;
		int _saveIndex;
		
		{
		mXPATH_START_LETTER(false);
		}
		{
		int _cnt126=0;
		_loop126:
		do {
			// nongreedy exit test
			if ( _cnt126>=1 && (LA(1)=='\t'||LA(1)=='\n'||LA(1)=='\r'||LA(1)==' ') && (true)) break _loop126;
			if (((LA(1) >= '\u0003' && LA(1) <= '\uffff')) && ((LA(2) >= '\u0003' && LA(2) <= '\uffff'))) {
				matchNot(EOF_CHAR);
			}
			else {
				if ( _cnt126>=1 ) { break _loop126; } else {throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());}
			}
			
			_cnt126++;
		} while (true);
		}
		{
		switch ( LA(1)) {
		case ' ':
		{
			match(' ');
			break;
		}
		case '\t':
		{
			match('\t');
			break;
		}
		case '\r':
		{
			match('\r');
			break;
		}
		case '\n':
		{
			match('\n');
			if ( inputState.guessing==0 ) {
				newline();
			}
			break;
		}
		default:
		{
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		}
		}
		if ( inputState.guessing==0 ) {
			/* System.out.println("Matched XPATHEXPR1:" + $getText);*/
		}
		_ttype = testLiteralsTable(new String(text.getBuffer(),_begin,text.length()-_begin),_ttype);
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mXPATHEXPR2(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = XPATHEXPR2;
		int _saveIndex;
		
		{
		mXPATH_AXIS_OR_FUNC_NAME(false);
		{
		switch ( LA(1)) {
		case ':':
		{
			mXPATH_AXIS_CONNECTOR(false);
			break;
		}
		case '(':
		{
			mLPAREN(false);
			break;
		}
		default:
		{
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		}
		}
		}
		{
		_loop132:
		do {
			// nongreedy exit test
			if ((LA(1)=='\t'||LA(1)=='\n'||LA(1)=='\r'||LA(1)==' ') && (true)) break _loop132;
			if (((LA(1) >= '\u0003' && LA(1) <= '\uffff')) && ((LA(2) >= '\u0003' && LA(2) <= '\uffff'))) {
				matchNot(EOF_CHAR);
			}
			else {
				break _loop132;
			}
			
		} while (true);
		}
		{
		switch ( LA(1)) {
		case ' ':
		{
			match(' ');
			break;
		}
		case '\t':
		{
			match('\t');
			break;
		}
		case '\r':
		{
			match('\r');
			break;
		}
		case '\n':
		{
			match('\n');
			if ( inputState.guessing==0 ) {
				newline();
			}
			break;
		}
		default:
		{
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		}
		}
		if ( inputState.guessing==0 ) {
			/* System.out.println("Matched XPATHEXPR2:" + $getText); */
		}
		_ttype = testLiteralsTable(new String(text.getBuffer(),_begin,text.length()-_begin),_ttype);
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mURL(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = URL;
		int _saveIndex;
		
		{
		switch ( LA(1)) {
		case 'f':
		{
			match("file");
			break;
		}
		case 'h':
		{
			match("http");
			break;
		}
		default:
		{
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		}
		}
		match("://");
		{
		int _cnt145=0;
		_loop145:
		do {
			// nongreedy exit test
			if ( _cnt145>=1 && (LA(1)=='\t'||LA(1)=='\n'||LA(1)=='\r'||LA(1)==' ') && (true)) break _loop145;
			if (((LA(1) >= '\u0003' && LA(1) <= '\uffff')) && ((LA(2) >= '\u0003' && LA(2) <= '\uffff'))) {
				matchNot(EOF_CHAR);
			}
			else {
				if ( _cnt145>=1 ) { break _loop145; } else {throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());}
			}
			
			_cnt145++;
		} while (true);
		}
		{
		switch ( LA(1)) {
		case ' ':
		{
			match(' ');
			break;
		}
		case '\t':
		{
			match('\t');
			break;
		}
		case '\r':
		{
			match('\r');
			break;
		}
		case '\n':
		{
			match('\n');
			if ( inputState.guessing==0 ) {
				newline();
			}
			break;
		}
		default:
		{
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		}
		}
		if ( inputState.guessing==0 ) {
			/* System.out.println("Matched URL:"  + $getText); */
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mDOC_OR_COL_PATH(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = DOC_OR_COL_PATH;
		int _saveIndex;
		
		boolean synPredMatched122 = false;
		if (((_tokenSet_4.member(LA(1))) && (_tokenSet_6.member(LA(2))) && (_tokenSet_6.member(LA(3))) && (true) && (true))) {
			int _m122 = mark();
			synPredMatched122 = true;
			inputState.guessing++;
			try {
				{
				mID_LETTER_OR_SLASH(false);
				match(".");
				}
			}
			catch (RecognitionException pe) {
				synPredMatched122 = false;
			}
			rewind(_m122);
			inputState.guessing--;
		}
		if ( synPredMatched122 ) {
			mDOC_PATH(false);
			if ( inputState.guessing==0 ) {
				_ttype = DOC_PATH;
			}
		}
		else if ((_tokenSet_4.member(LA(1))) && (true) && (true) && (true) && (true)) {
			mCOL_PATH(false);
			if ( inputState.guessing==0 ) {
				_ttype = COL_PATH;
			}
		}
		else {
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mURN_OR_COLON_NAME(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = URN_OR_COLON_NAME;
		int _saveIndex;
		
		boolean synPredMatched112 = false;
		if (((LA(1)=='u') && (LA(2)=='r') && (LA(3)=='n') && (LA(4)==':') && ((LA(5) >= '\u0003' && LA(5) <= '\uffff')))) {
			int _m112 = mark();
			synPredMatched112 = true;
			inputState.guessing++;
			try {
				{
				match("urn:");
				}
			}
			catch (RecognitionException pe) {
				synPredMatched112 = false;
			}
			rewind(_m112);
			inputState.guessing--;
		}
		if ( synPredMatched112 ) {
			mURN(false);
		}
		else {
			boolean synPredMatched114 = false;
			if (((_tokenSet_5.member(LA(1))) && (true) && (true) && (true) && (true))) {
				int _m114 = mark();
				synPredMatched114 = true;
				inputState.guessing++;
				try {
					{
					mID(false);
					match(':');
					}
				}
				catch (RecognitionException pe) {
					synPredMatched114 = false;
				}
				rewind(_m114);
				inputState.guessing--;
			}
			if ( synPredMatched114 ) {
				mCOLON_NAME(false);
			}
			else {
				throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
			}
			}
			_ttype = testLiteralsTable(new String(text.getBuffer(),_begin,text.length()-_begin),_ttype);
			if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
				_token = makeToken(_ttype);
				_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
			}
			_returnToken = _token;
		}
		
	protected final void mID_LETTER_OR_SLASH(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = ID_LETTER_OR_SLASH;
		int _saveIndex;
		
		{
		_loop109:
		do {
			switch ( LA(1)) {
			case '-':  case '0':  case '1':  case '2':
			case '3':  case '4':  case '5':  case '6':
			case '7':  case '8':  case '9':  case 'A':
			case 'B':  case 'C':  case 'D':  case 'E':
			case 'F':  case 'G':  case 'H':  case 'I':
			case 'J':  case 'K':  case 'L':  case 'M':
			case 'N':  case 'O':  case 'P':  case 'Q':
			case 'R':  case 'S':  case 'T':  case 'U':
			case 'V':  case 'W':  case 'X':  case 'Y':
			case 'Z':  case '_':  case 'a':  case 'b':
			case 'c':  case 'd':  case 'e':  case 'f':
			case 'g':  case 'h':  case 'i':  case 'j':
			case 'k':  case 'l':  case 'm':  case 'n':
			case 'o':  case 'p':  case 'q':  case 'r':
			case 's':  case 't':  case 'u':  case 'v':
			case 'w':  case 'x':  case 'y':  case 'z':
			{
				mID_LETTER(false);
				break;
			}
			case '/':
			{
				mSLASH(false);
				break;
			}
			default:
			{
				break _loop109;
			}
			}
		} while (true);
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mURN(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = URN;
		int _saveIndex;
		
		match("urn:");
		{
		int _cnt149=0;
		_loop149:
		do {
			// nongreedy exit test
			if ( _cnt149>=1 && (LA(1)=='\t'||LA(1)=='\n'||LA(1)=='\r'||LA(1)==' ') && (true)) break _loop149;
			if (((LA(1) >= '\u0003' && LA(1) <= '\uffff')) && ((LA(2) >= '\u0003' && LA(2) <= '\uffff'))) {
				matchNot(EOF_CHAR);
			}
			else {
				if ( _cnt149>=1 ) { break _loop149; } else {throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());}
			}
			
			_cnt149++;
		} while (true);
		}
		{
		switch ( LA(1)) {
		case ' ':
		{
			match(' ');
			break;
		}
		case '\t':
		{
			match('\t');
			break;
		}
		case '\r':
		{
			match('\r');
			break;
		}
		case '\n':
		{
			match('\n');
			if ( inputState.guessing==0 ) {
				newline();
			}
			break;
		}
		default:
		{
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		}
		}
		if ( inputState.guessing==0 ) {
			/* System.out.println("Matched URN:" +  $getText); */
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mCOLON_NAME(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = COLON_NAME;
		int _saveIndex;
		
		{
		_loop117:
		do {
			if ((_tokenSet_1.member(LA(1)))) {
				mID_LETTER(false);
			}
			else {
				break _loop117;
			}
			
		} while (true);
		}
		match(':');
		{
		_loop119:
		do {
			if ((_tokenSet_1.member(LA(1)))) {
				mID_LETTER(false);
			}
			else {
				break _loop119;
			}
			
		} while (true);
		}
		if ( inputState.guessing==0 ) {
			/* System.out.println("Matched COLON_NAME:" + $getText); */
		}
		_ttype = testLiteralsTable(new String(text.getBuffer(),_begin,text.length()-_begin),_ttype);
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mXPATH_AXIS_CONNECTOR(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = XPATH_AXIS_CONNECTOR;
		int _saveIndex;
		
		match("::");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mLPAREN(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = LPAREN;
		int _saveIndex;
		
		match("(");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mID_START_LETTER(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = ID_START_LETTER;
		int _saveIndex;
		
		switch ( LA(1)) {
		case '_':
		{
			match('_');
			break;
		}
		case 'a':  case 'b':  case 'c':  case 'd':
		case 'e':  case 'f':  case 'g':  case 'h':
		case 'i':  case 'j':  case 'k':  case 'l':
		case 'm':  case 'n':  case 'o':  case 'p':
		case 'q':  case 'r':  case 's':  case 't':
		case 'u':  case 'v':  case 'w':  case 'x':
		case 'y':  case 'z':
		{
			matchRange('a','z');
			break;
		}
		case 'A':  case 'B':  case 'C':  case 'D':
		case 'E':  case 'F':  case 'G':  case 'H':
		case 'I':  case 'J':  case 'K':  case 'L':
		case 'M':  case 'N':  case 'O':  case 'P':
		case 'Q':  case 'R':  case 'S':  case 'T':
		case 'U':  case 'V':  case 'W':  case 'X':
		case 'Y':  case 'Z':
		{
			matchRange('A','Z');
			break;
		}
		default:
		{
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine(), getColumn());
		}
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mQUOTED_VALUE(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = QUOTED_VALUE;
		int _saveIndex;
		
		_saveIndex=text.length();
		mQUOTE(false);
		text.setLength(_saveIndex);
		{
		_loop141:
		do {
			// nongreedy exit test
			if ((LA(1)=='"') && (true)) break _loop141;
			if (((LA(1) >= '\u0003' && LA(1) <= '\uffff')) && ((LA(2) >= '\u0003' && LA(2) <= '\uffff'))) {
				matchNot(EOF_CHAR);
			}
			else {
				break _loop141;
			}
			
		} while (true);
		}
		_saveIndex=text.length();
		mQUOTE(false);
		text.setLength(_saveIndex);
		if ( inputState.guessing==0 ) {
			/* System.out.println("Matched QUOTED_VALUE"); */
		}
		_ttype = testLiteralsTable(_ttype);
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	protected final void mQUOTE(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = QUOTE;
		int _saveIndex;
		
		match('"');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mSEMI(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = SEMI;
		int _saveIndex;
		
		match(";");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mEQUAL(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = EQUAL;
		int _saveIndex;
		
		match("=");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mCOMMA(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = COMMA;
		int _saveIndex;
		
		match(",");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mRPAREN(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = RPAREN;
		int _saveIndex;
		
		match(")");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	
	private static final long[] mk_tokenSet_0() {
		long[] data = new long[2048];
		data[0]=-9224L;
		for (int i = 1; i<=1023; i++) { data[i]=-1L; }
		return data;
	}
	public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
	private static final long[] mk_tokenSet_1() {
		long[] data = new long[1025];
		data[0]=287984085547089920L;
		data[1]=576460745995190270L;
		return data;
	}
	public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
	private static final long[] mk_tokenSet_2() {
		long[] data = new long[1025];
		data[0]=288266660035428352L;
		data[1]=576460743713488896L;
		return data;
	}
	public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
	private static final long[] mk_tokenSet_3() {
		long[] data = new long[1025];
		data[0]=288054454291267584L;
		data[1]=576460745995190270L;
		return data;
	}
	public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
	private static final long[] mk_tokenSet_4() {
		long[] data = new long[1025];
		data[1]=576460745995190270L;
		return data;
	}
	public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
	private static final long[] mk_tokenSet_5() {
		long[] data = new long[1025];
		data[0]=576214461698801664L;
		data[1]=576460745995190270L;
		return data;
	}
	public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
	private static final long[] mk_tokenSet_6() {
		long[] data = new long[1025];
		data[0]=288195191779622912L;
		data[1]=576460745995190270L;
		return data;
	}
	public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
	
	}
