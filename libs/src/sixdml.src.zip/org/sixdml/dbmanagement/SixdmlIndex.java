package org.sixdml.dbmanagement;
import java.util.HashMap;

/**
 * <PRE>
 * SixdmlIndex.java
 *
 * This interface should be implemented by classes that represent indexes 
 * into the XML documents be they structural, text, or value indexes.
 *
 * Created: Thu Jan 10 06:27:40 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0
 */


public interface SixdmlIndex  {
            
        
    /**
     * Get the name of the index.
     * @return Value of name.
     */
    public String getName();
    

    /**
     * Returns the type of the index. 
      * @see SixdmlIndexType#VALUE_INDEX
      * @see SixdmlIndexType#TEXT_INDEX
      * @see SixdmlIndexType#STRUCTURE_INDEX
     * @return type of the index. 
     */
    public SixdmlIndexType getType(); 
    
    /**
     * Returns a hash table containing various characteristics of the index depending on
     * its type. If the index is of type STRUCTURE_INDEX then the hash table could contain 
     * the following pairs {"key", &lt;XPath-expression&gt;} and 
     * {"index", &gt;XPath-expression&lt;}. The actual contents of the hash table will
     * vary from database to database depending on what is standardized on.
     * @return a hash table containing the relevant data about the index. 
     */
    public HashMap getIndexFields(); 

   
} // SixdmlIndex

