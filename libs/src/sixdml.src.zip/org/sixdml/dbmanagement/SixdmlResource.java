package org.sixdml.dbmanagement;
import org.xmldb.api.modules.XMLResource;
import org.xmldb.api.base.XMLDBException;
import org.w3c.dom.Document;

/**
 * <PRE>
 * SixdmlResource.java
 *
 * Representation of a resource in the database which should typically be an XML 
 * document. 
 *
 * Created: Thu Jan 10 19:10:54 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 */


public interface SixdmlResource extends XMLResource {

    /**
     * Gets the name of the resource.
     *
     * @return The name of the resource
     */
    public String getName();


} // SixdmlResource
