package org.sixdml.dbmanagement;
import org.sixdml.exceptions.UnsupportedIndexTypeException;

/**
 * <PRE>
 * Class is used by SixdmlIndex to represent types of indexes. 
 * </PRE>
 */

public final class SixdmlIndexType{

    /*=================================================================*/
    /*                        C O N S T A N T S                        */
    /*=================================================================*/
     

    /**
     * Represents a value index. 
     */
    public static SixdmlIndexType VALUE_INDEX = new SixdmlIndexType("VALUE_INDEX"); 
     
    /**
     * Represents a text index. 
     */
    public static SixdmlIndexType TEXT_INDEX = new SixdmlIndexType("TEXT_INDEX"); 

    /**
     * Represents a structure index. 
     */
    public static SixdmlIndexType STRUCTURE_INDEX = new SixdmlIndexType("STRUCTURE_INDEX"); 
    
   

     
    /*=================================================================*/
    /*                I N S T A N C E    V A R I A B L E S             */
    /*=================================================================*/
    
    /**
     * This is the name of the index type.
     */
    private String type;
    
    
    /*=================================================================*/
    /*                        C O N S T U C T O R S                    */
    /*=================================================================*/

     /**
     * Constructor private, so cannot be instantiated by other objects. 
     */
    private SixdmlIndexType(){;}

    /**
     * Constructor private, so cannot be instantiated by other objects. 
     * @param type the type of index. 
     */
    private SixdmlIndexType(String type){this.type = type;} 

    
    /*=================================================================*/
    /*                I N S T A N C E       M E T H O D S              */
    /*=================================================================*/

    /**
     * Returns the type of the index as a string.
     * @return the type of the index as a string.
     */
    public String toString(){ return type;}

    /*=================================================================*/
    /*                S T A T I C          M E T H O D S               */
    /*=================================================================*/

    /**
     * Factory method creates instances of this class. 
     * @param indexType the type of index to create. 
     * @return a SixdmlIndexType instance
     * @exception UnsupportedIndexTypeException if the index type is unknown. 
     */
    public static SixdmlIndexType createIndexType(String indexType) 
	throws UnsupportedIndexTypeException{

	if(indexType.equals("VALUE_INDEX"))
	    return VALUE_INDEX; 
	else if(indexType.equals("TEXT_INDEX"))
	    return TEXT_INDEX;
	else if(indexType.equals("STRUCTURE_INDEX"))
	    return STRUCTURE_INDEX;
	else
	    throw new UnsupportedIndexTypeException(); 

    }/* createIndexType(String) */
     
}





