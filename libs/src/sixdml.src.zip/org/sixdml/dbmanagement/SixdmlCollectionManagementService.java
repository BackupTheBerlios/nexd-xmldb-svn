package org.sixdml.dbmanagement;
import org.xmldb.api.modules.CollectionManagementService;
import org.xmldb.api.base.Collection;
import java.net.URL; 
import org.xmldb.api.base.XMLDBException;
import java.io.IOException;
import org.sixdml.exceptions.InvalidSchemaException;
import org.sixdml.exceptions.UnsupportedIndexTypeException;
import java.util.HashMap; 

/**
 * <PRE>
 * SixdmlCollectionManagementService.java
 *
 * This is a Service that enables the basic management of collections within a 
 * database. 
 *
 * Created: Fri Jan 11 01:07:58 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 */


public interface SixdmlCollectionManagementService extends CollectionManagementService {

    /**
     * Creates a collection that is constrained by a particular schema. 
     * @param name The name of the collection to create. 
     * @param schemaFile the location of the schema file either on the local file 
     * system or over the internet. 
     * @exception XMLDBException if a database error occurs. 
     * @exception IOException if an error occurs while trying to retrieve the file.
     * @exception InvalidSchemaException if the schema is invalid.      
     */ 
    Collection createCollection(String name, URL schemaFile) 
	throws XMLDBException, IOException, InvalidSchemaException; 


     /**
     * Creates an index with a name, an indexFields table and an underlying DXE database. <BR>
     * <B>NOTE</b>: Runtime error may occur if table not properly populated. 
     * @param name the name of the index. 
     * @param indexFields the index fields for the class. 
     * @exception XMLDBException if an error occurs. 
     * @exception UnsupportedIndexTypeException if the type of index requested is unsupported by the 
     * database. 
     */
    SixdmlIndex createIndex(String name, HashMap indexFields) throws XMLDBException, UnsupportedIndexTypeException; 
    
    
    /**
     * Gets the types of index that are supported by the this database. 
     * @return an array of SixdmlIndexTypes which the database supports.
     * @exception XMLDBException if an error occurs. 
     */
    SixdmlIndexType[] getSupportedIndexTypes() throws XMLDBException; 
 
    
} // SixdmlCollectionManagementService
