package org.sixdml.dbmanagement;
import org.xmldb.api.modules.TransactionService;

/**
 * <PRE>
 * SixdmlTransaction.java
 * 
 * This service is used to mark transaction boundaries during operations on the 
 * database. 
 * 
 * Created: Fri Jan 11 10:48:36 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 */


public interface SixdmlTransactionService extends TransactionService {
    

    /**
     * Returns true if there is currently a transaction open that is neither 
     * committed nor aborted; returns false otherwise.
     * @return true if there is currently a transaction open that is neither 
     * committed nor aborted; returns false otherwise.
     */
    boolean isActive(); 
     
    
} // SixdmlTransaction
