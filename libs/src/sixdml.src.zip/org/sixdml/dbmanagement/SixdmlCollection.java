package org.sixdml.dbmanagement; 
import org.xmldb.api.base.Collection;
import org.xmldb.api.base.XMLDBException;
import java.net.URL; 
import java.io.IOException; 
import java.util.HashMap;
import java.util.Enumeration;
import org.sixdml.dbmanagement.SixdmlIndex; 
import org.sixdml.exceptions.*; 


/**
 * <PRE>
 * SixdmlCollection.java
 *
 * This is collection represents a group of XML resources that can be queried or 
 * updated collectively similarly to how rows in a relational table can be queried 
 * and updated collectively. 
 *
 * Created: Thu Jan 10 04:23:49 2002
 * </PRE>
 * @author <a href="mailto:kpako@yahoo.com">Dare Obasanjo</a>
 * @version 1.0 
 */


public interface SixdmlCollection extends Collection {
    
    /**
     * Sets the XML schema or DTD that will be used to constrain the documents in 
     * this collection. For this operation to succeed, all documents in the collection 
     * <b>must</b> pass schema validation. If a schema already exists for the collection 
     * then it is replaced by the new one if all documents pass validation. 
     * @param schemaFile the location of the schema file either on the local file 
     * system or over the internet. 
     * @exception InvalidCollectionDocumentException if an XML document in the 
     * collection fails to be validated by the schema.
     * @exception IOException if an error occurs while trying to retrieve the file.
     * @exception InvalidSchemaException if the schema is invalid. 
     * @exception XMLDBException if a database error occurs. 
     */ 
    public void setSchema(URL schemaFile) 
	throws InvalidCollectionDocumentException,IOException, InvalidSchemaException, XMLDBException; 

    /**
     * Returns the contents of the schema for the collection as a string. 
     * @return the schema for the collection or NULL if none exists. 
     * @exception XMLDBException if a database error occurs. 
     */
    public String showSchema() throws XMLDBException; 

    /**
     * Unsets the schema for this collection. Does nothing if no schema exists for the 
     * collection. 
     * @exception XMLDBException if a database error occurs. 
     */
    public void unsetSchema() throws XMLDBException; 

    /**
     * Adds an XML document created from the string argument to the collection. 
     * @param name the name of the document.
     * @param xmlString the string representation of a well-formed XML document 
     * @exception DocumentAlreadyExistsException if there already exists a document with 
     * the specified name in the database. 
     * @exception InvalidCollectionDocumentException if the document fails to validate against 
     * the collection's schema. 
     * @exception NonWellFormedXMLException if the XML is not well formed. 
     * @exception XMLDBException if a database error occurs. 
     */
    public void insertDocument(String name, String xmlString) 
	throws DocumentAlreadyExistsException, InvalidCollectionDocumentException, NonWellFormedXMLException, XMLDBException; 

    /**
     * Adds an XML document loaded from the specified URL to the collection. 
     * @param name the name of the document.
     * @param xmlString the string representation of a well-formed XML document 
     * @exception DocumentAlreadyExistsException if there already exists a document with 
     * the specified name in the database. 
     * @exception IOException if an error occurs while trying to retrieve the file. 
     * @exception InvalidCollectionDocumentException if the document fails to validate against 
     * the collection's schema. 
     * @exception NonWellFormedXMLException if the XML is not well formed. 
     * @exception XMLDBException if a database error occurs. 
     */
    public void insertDocument(String name, URL documentSource) 
	throws DocumentAlreadyExistsException, IOException, InvalidCollectionDocumentException, NonWellFormedXMLException, XMLDBException; 
    
    
    /**
     * Removes an XML document from the collection. 
     * @param name the name of the document. 
     * @exception NonExistentDocumentException if the document does not exist 
     * in the collection. 
     * @exception XMLDBException if a database error occurs. 
     */
    public void removeDocument(String name)
	throws NonExistentDocumentException, XMLDBException; 

    /**
     * Adds an index to apply to the collection. 
     * @param index the index to add
     * @exception UnsupportedIndexTypeException if the index is of a type unsupported 
     * by the database.
     * @exception IndexAlreadyExistsException if an index with the same name already exists 
     * for the collection. 
     * @exception XMLDBException if a database error occurs. 
     */
    public void addIndex(SixdmlIndex index) 
	throws UnsupportedIndexTypeException, IndexAlreadyExistsException, XMLDBException; 


    /**
     * Removes a particular index from the collection.
     * @param index the index to add
     * @exception XMLDBException if a database error occurs. 
     */
    public void removeIndex(String name)
	throws NonExistentIndexException, XMLDBException; 

    /**
     * Returns an array of SixdmlIndex objects that apply to this collection. If no indexes 
     * exist in the collection then an empty array is returned.
     * @return an array of SixdmlIndex objects.
     * @exception XMLDBException if a database error occurs. 
     */
    public SixdmlIndex[] getIndices() throws XMLDBException; 

} // SixdmlCollection
